var __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__module_namespace_1 = /*#__PURE__*/Object.freeze({
    __proto__: null,
    get isCEPolyfill () { return isCEPolyfill; },
    get reparentNodes () { return reparentNodes; },
    get removeNodes () { return removeNodes; }
});
var __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__module_namespace_6 = /*#__PURE__*/Object.freeze({
    __proto__: null,
    get marker () { return marker; },
    get nodeMarker () { return nodeMarker; },
    get markerRegex () { return markerRegex; },
    get boundAttributeSuffix () { return boundAttributeSuffix; },
    get Template () { return Template; },
    get isTemplatePartActive () { return isTemplatePartActive; },
    get createMarker () { return createMarker; },
    get lastAttributeNameRegex () { return lastAttributeNameRegex; }
});
var __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__module_namespace_2 = /*#__PURE__*/Object.freeze({
    __proto__: null,
    get removeNodesFromTemplate () { return removeNodesFromTemplate; },
    get insertNodeIntoTemplate () { return insertNodeIntoTemplate; }
});
var __045213766b0e56a0c3f2db9279bb9770e31ccd73fa3bc118b7423459ba0ec60e__module_namespace_3 = /*#__PURE__*/Object.freeze({
    __proto__: null,
    get directive () { return directive; },
    get isDirective () { return isDirective; }
});
var __045213766b0e56a0c3f2db9279bb9770e31ccd73fa3bc118b7423459ba0ec60e__module_namespace_5 = /*#__PURE__*/Object.freeze({
    __proto__: null,
    get noChange () { return noChange; },
    get nothing () { return nothing; }
});
var __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__module_namespace_5 = /*#__PURE__*/Object.freeze({
    __proto__: null,
    get TemplateInstance () { return TemplateInstance; }
});
var __045213766b0e56a0c3f2db9279bb9770e31ccd73fa3bc118b7423459ba0ec60e__module_namespace_2 = /*#__PURE__*/Object.freeze({
    __proto__: null,
    get TemplateResult () { return TemplateResult; },
    get SVGTemplateResult () { return SVGTemplateResult; }
});
var __045213766b0e56a0c3f2db9279bb9770e31ccd73fa3bc118b7423459ba0ec60e__module_namespace_6 = /*#__PURE__*/Object.freeze({
    __proto__: null,
    get isPrimitive () { return isPrimitive; },
    get isIterable () { return isIterable; },
    get AttributeCommitter () { return AttributeCommitter; },
    get AttributePart () { return AttributePart; },
    get NodePart () { return NodePart; },
    get BooleanAttributePart () { return BooleanAttributePart; },
    get PropertyCommitter () { return PropertyCommitter; },
    get PropertyPart () { return PropertyPart; },
    get EventPart () { return EventPart; }
});
var __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__module_namespace_4 = /*#__PURE__*/Object.freeze({
    __proto__: null,
    get templateFactory () { return templateFactory; },
    get templateCaches () { return templateCaches; }
});
var __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__module_namespace_3 = /*#__PURE__*/Object.freeze({
    __proto__: null,
    get parts () { return parts; },
    get render () { return render; }
});
var __045213766b0e56a0c3f2db9279bb9770e31ccd73fa3bc118b7423459ba0ec60e__module_namespace_1 = /*#__PURE__*/Object.freeze({
    __proto__: null,
    get DefaultTemplateProcessor () { return DefaultTemplateProcessor; },
    get defaultTemplateProcessor () { return defaultTemplateProcessor; }
});
var litHtmlNamespace = /*#__PURE__*/Object.freeze({
    __proto__: null,
    get html () { return html; },
    get svg () { return svg; },
    get DefaultTemplateProcessor () { return DefaultTemplateProcessor; },
    get defaultTemplateProcessor () { return defaultTemplateProcessor; },
    get directive () { return directive; },
    get isDirective () { return isDirective; },
    get removeNodes () { return removeNodes; },
    get reparentNodes () { return reparentNodes; },
    get noChange () { return noChange; },
    get nothing () { return nothing; },
    get AttributeCommitter () { return AttributeCommitter; },
    get AttributePart () { return AttributePart; },
    get BooleanAttributePart () { return BooleanAttributePart; },
    get EventPart () { return EventPart; },
    get isIterable () { return isIterable; },
    get isPrimitive () { return isPrimitive; },
    get NodePart () { return NodePart; },
    get PropertyCommitter () { return PropertyCommitter; },
    get PropertyPart () { return PropertyPart; },
    get parts () { return parts; },
    get render () { return render; },
    get templateCaches () { return templateCaches; },
    get templateFactory () { return templateFactory; },
    get TemplateInstance () { return TemplateInstance; },
    get SVGTemplateResult () { return SVGTemplateResult; },
    get TemplateResult () { return TemplateResult; },
    get createMarker () { return createMarker; },
    get isTemplatePartActive () { return isTemplatePartActive; },
    get Template () { return Template; }
});
var __90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__module_namespace_1 = /*#__PURE__*/Object.freeze({
    __proto__: null,
    get render () { return render$1; },
    get html () { return html; },
    get svg () { return svg; },
    get TemplateResult () { return TemplateResult; }
});
var __90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__module_namespace_2 = /*#__PURE__*/Object.freeze({
    __proto__: null,
    get defaultConverter () { return defaultConverter; },
    get notEqual () { return notEqual; },
    get UpdatingElement () { return UpdatingElement; }
});
var __90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__module_namespace_3 = /*#__PURE__*/Object.freeze({
    __proto__: null,
    get customElement () { return customElement; },
    get property () { return property; },
    get internalProperty () { return internalProperty; },
    get query () { return query; },
    get queryAsync () { return queryAsync; },
    get queryAll () { return queryAll; },
    get eventOptions () { return eventOptions; },
    get queryAssignedNodes () { return queryAssignedNodes; }
});
var __90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__module_namespace_5 = /*#__PURE__*/Object.freeze({
    __proto__: null,
    get supportsAdoptingStyleSheets () { return supportsAdoptingStyleSheets; },
    get CSSResult () { return CSSResult; },
    get unsafeCSS () { return unsafeCSS; },
    get css () { return css; }
});
var __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__module_namespace_1 = /*#__PURE__*/Object.freeze({
    __proto__: null,
    get LitElement () { return LitElement; },
    get html () { return html; },
    get svg () { return svg; },
    get TemplateResult () { return TemplateResult; },
    get SVGTemplateResult () { return SVGTemplateResult; },
    get defaultConverter () { return defaultConverter; },
    get notEqual () { return notEqual; },
    get UpdatingElement () { return UpdatingElement; },
    get customElement () { return customElement; },
    get property () { return property; },
    get internalProperty () { return internalProperty; },
    get query () { return query; },
    get queryAsync () { return queryAsync; },
    get queryAll () { return queryAll; },
    get eventOptions () { return eventOptions; },
    get queryAssignedNodes () { return queryAssignedNodes; },
    get supportsAdoptingStyleSheets () { return supportsAdoptingStyleSheets; },
    get CSSResult () { return CSSResult; },
    get unsafeCSS () { return unsafeCSS; },
    get css () { return css; }
});
var __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__module_namespace_2 = /*#__PURE__*/Object.freeze({
    __proto__: null,
    get repeat () { return repeat; }
});
var __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__module_namespace_4 = /*#__PURE__*/Object.freeze({
    __proto__: null,
    get exportedName () { return exportedName; },
    get exportedName2 () { return exportedName2; },
    get inaccessibleString () { return inaccessibleString; },
    get inaccessibleNumber () { return inaccessibleNumber; },
    get inaccessibleBoolean () { return inaccessibleBoolean; },
    get inaccessibleSymbol () { return inaccessibleSymbol; },
    get inaccessibleNull () { return inaccessibleNull; },
    get inaccessibleUndefined () { return inaccessibleUndefined; },
    get inaccessibleBigInt () { return inaccessibleBigInt; },
    get inaccessibleFunction () { return inaccessibleFunction; },
    get inaccessibleObject () { return inaccessibleObject; },
    get ExportedClass () { return ExportedClass; }
});
var __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__module_namespace_5 = /*#__PURE__*/Object.freeze({
    __proto__: null,
    get UnspecifiedExport () { return UnspecifiedExport; }
});
var __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__module_namespace_0 = /*#__PURE__*/Object.freeze({
    __proto__: null,
    get HelloWorld () { return HelloWorld; }
});

/**
 * @license
 * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
 * This code may only be used under the BSD style license found at
 * http://polymer.github.io/LICENSE.txt
 * The complete set of authors may be found at
 * http://polymer.github.io/AUTHORS.txt
 * The complete set of contributors may be found at
 * http://polymer.github.io/CONTRIBUTORS.txt
 * Code distributed by Google as part of the polymer project is also
 * subject to an additional IP rights grant found at
 * http://polymer.github.io/PATENTS.txt
 */
/**
 * True if the custom elements polyfill is in use.
 */
const __adc2859c9f4d7c75776df14f8f5d266c827c030059ff30576c2023173c883e8d__ = $hook$.$(__hook__, [
  '/components/thin-hook/demo/node_modules/lit-html/lib/dom.js',
  '/components/thin-hook/demo/node_modules/lit-html/lib/dom.js,isCEPolyfill',
  'S_uNpREdiC4aB1e_window;/components/thin-hook/demo/node_modules/lit-html/lib/dom.js,isCEPolyfill',
  'S_uNpREdiC4aB1e_undefined;/components/thin-hook/demo/node_modules/lit-html/lib/dom.js,isCEPolyfill',
  '/components/thin-hook/demo/node_modules/lit-html/lib/dom.js,reparentNodes',
  '/components/thin-hook/demo/node_modules/lit-html/lib/dom.js,reparentNodes,n',
  '/components/thin-hook/demo/node_modules/lit-html/lib/dom.js,removeNodes',
  '/components/thin-hook/demo/node_modules/lit-html/lib/dom.js,removeNodes,n'
]);
const isCEPolyfill = typeof $hook$.global(__hook__, __adc2859c9f4d7c75776df14f8f5d266c827c030059ff30576c2023173c883e8d__[1], 'window', '#typeof')[__adc2859c9f4d7c75776df14f8f5d266c827c030059ff30576c2023173c883e8d__[2]] !== 'undefined' && __hook__('#.', $hook$.global(__hook__, __adc2859c9f4d7c75776df14f8f5d266c827c030059ff30576c2023173c883e8d__[1], 'window', '#get')[__adc2859c9f4d7c75776df14f8f5d266c827c030059ff30576c2023173c883e8d__[2]], ['customElements'], __adc2859c9f4d7c75776df14f8f5d266c827c030059ff30576c2023173c883e8d__[1]) != null && __hook__('#.', __hook__('#.', $hook$.global(__hook__, __adc2859c9f4d7c75776df14f8f5d266c827c030059ff30576c2023173c883e8d__[1], 'window', '#get')[__adc2859c9f4d7c75776df14f8f5d266c827c030059ff30576c2023173c883e8d__[2]], ['customElements'], __adc2859c9f4d7c75776df14f8f5d266c827c030059ff30576c2023173c883e8d__[1]), ['polyfillWrapFlushCallback'], __adc2859c9f4d7c75776df14f8f5d266c827c030059ff30576c2023173c883e8d__[1]) !== $hook$.global(__hook__, __adc2859c9f4d7c75776df14f8f5d266c827c030059ff30576c2023173c883e8d__[1], 'undefined', '#get')[__adc2859c9f4d7c75776df14f8f5d266c827c030059ff30576c2023173c883e8d__[3]];
/**
 * Reparents nodes, starting from `start` (inclusive) to `end` (exclusive),
 * into another container (could be the same container), before `before`. If
 * `before` is null, it appends the nodes to the container.
 */
const reparentNodes = (...args) =>
  (__hook__((container, start, end = null, before = null) => {
    while (start !== end) {
      const n = __hook__('#.', start, ['nextSibling'], __adc2859c9f4d7c75776df14f8f5d266c827c030059ff30576c2023173c883e8d__[5]);
      __hook__('#()', container, [
        'insertBefore',
        [
          start,
          before
        ]
      ], __adc2859c9f4d7c75776df14f8f5d266c827c030059ff30576c2023173c883e8d__[4]);
      start = n;
    }
  }, null, args, __adc2859c9f4d7c75776df14f8f5d266c827c030059ff30576c2023173c883e8d__[4]));
/**
 * Removes nodes, starting from `start` (inclusive) to `end` (exclusive), from
 * `container`.
 */
const removeNodes = (...args) =>
  (__hook__((container, start, end = null) => {
    while (start !== end) {
      const n = __hook__('#.', start, ['nextSibling'], __adc2859c9f4d7c75776df14f8f5d266c827c030059ff30576c2023173c883e8d__[7]);
      __hook__('#()', container, [
        'removeChild',
        [start]
      ], __adc2859c9f4d7c75776df14f8f5d266c827c030059ff30576c2023173c883e8d__[6]);
      start = n;
    }
  }, null, args, __adc2859c9f4d7c75776df14f8f5d266c827c030059ff30576c2023173c883e8d__[6]));  __hook__(() => {
}, null, [
  'export',
  __adc2859c9f4d7c75776df14f8f5d266c827c030059ff30576c2023173c883e8d__[0],
  __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__module_namespace_1
], __adc2859c9f4d7c75776df14f8f5d266c827c030059ff30576c2023173c883e8d__[0], NaN);

/**
 * @license
 * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
 * This code may only be used under the BSD style license found at
 * http://polymer.github.io/LICENSE.txt
 * The complete set of authors may be found at
 * http://polymer.github.io/AUTHORS.txt
 * The complete set of contributors may be found at
 * http://polymer.github.io/CONTRIBUTORS.txt
 * Code distributed by Google as part of the polymer project is also
 * subject to an additional IP rights grant found at
 * http://polymer.github.io/PATENTS.txt
 */
/**
 * An expression marker with embedded unique key to avoid collision with
 * possible text in templates.
 */
const __4fd4b53fa5d16ed9d37939b816e6233d5b7ad42253264e0412b80c143ec4a4c9__ = $hook$.$(__hook__, [
  '/components/thin-hook/demo/node_modules/lit-html/lib/template.js',
  '/components/thin-hook/demo/node_modules/lit-html/lib/template.js,marker',
  'S_uNpREdiC4aB1e_String;/components/thin-hook/demo/node_modules/lit-html/lib/template.js,marker',
  'S_uNpREdiC4aB1e_Math;/components/thin-hook/demo/node_modules/lit-html/lib/template.js,marker',
  '/components/thin-hook/demo/node_modules/lit-html/lib/template.js,nodeMarker',
  '/components/thin-hook/demo/node_modules/lit-html/lib/template.js,markerRegex',
  'S_uNpREdiC4aB1e_RegExp;/components/thin-hook/demo/node_modules/lit-html/lib/template.js,markerRegex',
  '/components/thin-hook/demo/node_modules/lit-html/lib/template.js,Template,constructor',
  '/components/thin-hook/demo/node_modules/lit-html/lib/template.js,Template,constructor,walker',
  'S_uNpREdiC4aB1e_document;/components/thin-hook/demo/node_modules/lit-html/lib/template.js,Template,constructor,walker',
  '/components/thin-hook/demo/node_modules/lit-html/lib/template.js,Template,constructor,node',
  '/components/thin-hook/demo/node_modules/lit-html/lib/template.js,Template,constructor,attributes',
  '/components/thin-hook/demo/node_modules/lit-html/lib/template.js,boundAttributeSuffix',
  '/components/thin-hook/demo/node_modules/lit-html/lib/template.js,Template,constructor,stringForPart',
  '/components/thin-hook/demo/node_modules/lit-html/lib/template.js,Template,constructor,name',
  '/components/thin-hook/demo/node_modules/lit-html/lib/template.js,lastAttributeNameRegex',
  '/components/thin-hook/demo/node_modules/lit-html/lib/template.js,Template,constructor,attributeLookupName',
  '/components/thin-hook/demo/node_modules/lit-html/lib/template.js,Template,constructor,attributeValue',
  '/components/thin-hook/demo/node_modules/lit-html/lib/template.js,Template,constructor,statics',
  '/components/thin-hook/demo/node_modules/lit-html/lib/template.js,Template,constructor,data',
  '/components/thin-hook/demo/node_modules/lit-html/lib/template.js,Template,constructor,parent',
  '/components/thin-hook/demo/node_modules/lit-html/lib/template.js,Template,constructor,strings',
  '/components/thin-hook/demo/node_modules/lit-html/lib/template.js,Template,constructor,lastIndex',
  '/components/thin-hook/demo/node_modules/lit-html/lib/template.js,Template,constructor,s',
  '/components/thin-hook/demo/node_modules/lit-html/lib/template.js,createMarker',
  '/components/thin-hook/demo/node_modules/lit-html/lib/template.js,Template,constructor,match',
  'S_uNpREdiC4aB1e_document;/components/thin-hook/demo/node_modules/lit-html/lib/template.js,Template,constructor',
  '/components/thin-hook/demo/node_modules/lit-html/lib/template.js,endsWith',
  '/components/thin-hook/demo/node_modules/lit-html/lib/template.js,endsWith,index',
  '/components/thin-hook/demo/node_modules/lit-html/lib/template.js,isTemplatePartActive',
  'S_uNpREdiC4aB1e_document;/components/thin-hook/demo/node_modules/lit-html/lib/template.js,createMarker'
]);
const marker = `{{lit-${ __hook__('#()', __hook__($hook$.global(__hook__, __4fd4b53fa5d16ed9d37939b816e6233d5b7ad42253264e0412b80c143ec4a4c9__[1], 'String', '#get')[__4fd4b53fa5d16ed9d37939b816e6233d5b7ad42253264e0412b80c143ec4a4c9__[2]], null, [__hook__('#()', $hook$.global(__hook__, __4fd4b53fa5d16ed9d37939b816e6233d5b7ad42253264e0412b80c143ec4a4c9__[1], 'Math', '#get')[__4fd4b53fa5d16ed9d37939b816e6233d5b7ad42253264e0412b80c143ec4a4c9__[3]], [
    'random',
    []
  ], __4fd4b53fa5d16ed9d37939b816e6233d5b7ad42253264e0412b80c143ec4a4c9__[1])], __4fd4b53fa5d16ed9d37939b816e6233d5b7ad42253264e0412b80c143ec4a4c9__[1], 0), [
  'slice',
  [2]
], __4fd4b53fa5d16ed9d37939b816e6233d5b7ad42253264e0412b80c143ec4a4c9__[1]) }}}`;
/**
 * An expression marker used text-positions, multi-binding attributes, and
 * attributes with markup-like text values.
 */
const nodeMarker = `<!--${ __hook__('m', marker, [__4fd4b53fa5d16ed9d37939b816e6233d5b7ad42253264e0412b80c143ec4a4c9__[1]], __4fd4b53fa5d16ed9d37939b816e6233d5b7ad42253264e0412b80c143ec4a4c9__[4], null) }-->`;
const markerRegex = __hook__($hook$.global(__hook__, __4fd4b53fa5d16ed9d37939b816e6233d5b7ad42253264e0412b80c143ec4a4c9__[5], 'RegExp', '#get')[__4fd4b53fa5d16ed9d37939b816e6233d5b7ad42253264e0412b80c143ec4a4c9__[6]], null, [`${ __hook__('m', marker, [__4fd4b53fa5d16ed9d37939b816e6233d5b7ad42253264e0412b80c143ec4a4c9__[1]], __4fd4b53fa5d16ed9d37939b816e6233d5b7ad42253264e0412b80c143ec4a4c9__[5], null) }|${ __hook__('m', nodeMarker, [__4fd4b53fa5d16ed9d37939b816e6233d5b7ad42253264e0412b80c143ec4a4c9__[4]], __4fd4b53fa5d16ed9d37939b816e6233d5b7ad42253264e0412b80c143ec4a4c9__[5], null) }`], __4fd4b53fa5d16ed9d37939b816e6233d5b7ad42253264e0412b80c143ec4a4c9__[5], true);
/**
 * Suffix appended to all bound attribute names.
 */
const boundAttributeSuffix = '$lit$';
/**
 * An updatable Template that tracks the location of dynamic parts.
 */
class Template {
  constructor(result, element) {
    return __hook__((result, element) => {
      __hook__('#=', this, [
        'parts',
        []
      ], __4fd4b53fa5d16ed9d37939b816e6233d5b7ad42253264e0412b80c143ec4a4c9__[7]);
      __hook__('#=', this, [
        'element',
        element
      ], __4fd4b53fa5d16ed9d37939b816e6233d5b7ad42253264e0412b80c143ec4a4c9__[7]);
      const nodesToRemove = [];
      const stack = [];
      // Edge needs all 4 parameters present; IE11 needs 3rd parameter to be null
      const walker = __hook__('#()', $hook$.global(__hook__, __4fd4b53fa5d16ed9d37939b816e6233d5b7ad42253264e0412b80c143ec4a4c9__[8], 'document', '#get')[__4fd4b53fa5d16ed9d37939b816e6233d5b7ad42253264e0412b80c143ec4a4c9__[9]], [
        'createTreeWalker',
        [
          __hook__('#.', element, ['content'], __4fd4b53fa5d16ed9d37939b816e6233d5b7ad42253264e0412b80c143ec4a4c9__[8]),
          133  /* NodeFilter.SHOW_{ELEMENT|COMMENT|TEXT} */,
          null,
          false
        ]
      ], __4fd4b53fa5d16ed9d37939b816e6233d5b7ad42253264e0412b80c143ec4a4c9__[8]);
      // Keeps track of the last index associated with a part. We try to delete
      // unnecessary nodes, but we never want to associate two different parts
      // to the same index. They must have a constant node between.
      let lastPartIndex = 0;
      let index = -1;
      let partIndex = 0;
      const {
        strings,
        values: {length}
      } = __hook__('#*', result, [], __4fd4b53fa5d16ed9d37939b816e6233d5b7ad42253264e0412b80c143ec4a4c9__[7]);
      while (partIndex < length) {
        const node = __hook__('#()', walker, [
          'nextNode',
          []
        ], __4fd4b53fa5d16ed9d37939b816e6233d5b7ad42253264e0412b80c143ec4a4c9__[10]);
        if (node === null) {
          // We've exhausted the content inside a nested template element.
          // Because we still have parts (the outer for-loop), we know:
          // - There is a template in the stack
          // - The walker will find a nextNode outside the template
          __hook__('#=', walker, [
            'currentNode',
            __hook__('#()', stack, [
              'pop',
              []
            ], __4fd4b53fa5d16ed9d37939b816e6233d5b7ad42253264e0412b80c143ec4a4c9__[7])
          ], __4fd4b53fa5d16ed9d37939b816e6233d5b7ad42253264e0412b80c143ec4a4c9__[7]);
          continue;
        }
        index++;
        if (__hook__('#.', node, ['nodeType'], __4fd4b53fa5d16ed9d37939b816e6233d5b7ad42253264e0412b80c143ec4a4c9__[7]) === 1  /* Node.ELEMENT_NODE */) {
          if (__hook__('#()', node, [
              'hasAttributes',
              []
            ], __4fd4b53fa5d16ed9d37939b816e6233d5b7ad42253264e0412b80c143ec4a4c9__[7])) {
            const attributes = __hook__('#.', node, ['attributes'], __4fd4b53fa5d16ed9d37939b816e6233d5b7ad42253264e0412b80c143ec4a4c9__[11]);
            const {length} = __hook__('#*', attributes, [], __4fd4b53fa5d16ed9d37939b816e6233d5b7ad42253264e0412b80c143ec4a4c9__[7]);
            // Per
            // https://developer.mozilla.org/en-US/docs/Web/API/NamedNodeMap,
            // attributes are not guaranteed to be returned in document order.
            // In particular, Edge/IE can return them out of order, so we cannot
            // assume a correspondence between part index and attribute index.
            let count = 0;
            for (let i = 0; i < length; i++) {
              if (__hook__(endsWith, null, [
                  __hook__('#.', __hook__('#.', attributes, [i], __4fd4b53fa5d16ed9d37939b816e6233d5b7ad42253264e0412b80c143ec4a4c9__[7]), ['name'], __4fd4b53fa5d16ed9d37939b816e6233d5b7ad42253264e0412b80c143ec4a4c9__[7]),
                  __hook__('m', boundAttributeSuffix, [__4fd4b53fa5d16ed9d37939b816e6233d5b7ad42253264e0412b80c143ec4a4c9__[12]], __4fd4b53fa5d16ed9d37939b816e6233d5b7ad42253264e0412b80c143ec4a4c9__[7], null)
                ], __4fd4b53fa5d16ed9d37939b816e6233d5b7ad42253264e0412b80c143ec4a4c9__[7], 0)) {
                count++;
              }
            }
            while (count-- > 0) {
              // Get the template literal section leading up to the first
              // expression in this attribute
              const stringForPart = __hook__('#.', strings, [partIndex], __4fd4b53fa5d16ed9d37939b816e6233d5b7ad42253264e0412b80c143ec4a4c9__[13]);
              // Find the attribute name
              const name = __hook__('#.', __hook__('#()', __hook__('m', lastAttributeNameRegex, [__4fd4b53fa5d16ed9d37939b816e6233d5b7ad42253264e0412b80c143ec4a4c9__[15]], __4fd4b53fa5d16ed9d37939b816e6233d5b7ad42253264e0412b80c143ec4a4c9__[14], null), [
                'exec',
                [stringForPart]
              ], __4fd4b53fa5d16ed9d37939b816e6233d5b7ad42253264e0412b80c143ec4a4c9__[14]), [2], __4fd4b53fa5d16ed9d37939b816e6233d5b7ad42253264e0412b80c143ec4a4c9__[14]);
              // Find the corresponding attribute
              // All bound attributes have had a suffix added in
              // TemplateResult#getHTML to opt out of special attribute
              // handling. To look up the attribute value we also need to add
              // the suffix.
              const attributeLookupName = __hook__('#()', name, [
                'toLowerCase',
                []
              ], __4fd4b53fa5d16ed9d37939b816e6233d5b7ad42253264e0412b80c143ec4a4c9__[16]) + __hook__('m', boundAttributeSuffix, [__4fd4b53fa5d16ed9d37939b816e6233d5b7ad42253264e0412b80c143ec4a4c9__[12]], __4fd4b53fa5d16ed9d37939b816e6233d5b7ad42253264e0412b80c143ec4a4c9__[16], null);
              const attributeValue = __hook__('#()', node, [
                'getAttribute',
                [attributeLookupName]
              ], __4fd4b53fa5d16ed9d37939b816e6233d5b7ad42253264e0412b80c143ec4a4c9__[17]);
              __hook__('#()', node, [
                'removeAttribute',
                [attributeLookupName]
              ], __4fd4b53fa5d16ed9d37939b816e6233d5b7ad42253264e0412b80c143ec4a4c9__[7]);
              const statics = __hook__('#()', attributeValue, [
                'split',
                [__hook__('m', markerRegex, [__4fd4b53fa5d16ed9d37939b816e6233d5b7ad42253264e0412b80c143ec4a4c9__[5]], __4fd4b53fa5d16ed9d37939b816e6233d5b7ad42253264e0412b80c143ec4a4c9__[18], null)]
              ], __4fd4b53fa5d16ed9d37939b816e6233d5b7ad42253264e0412b80c143ec4a4c9__[18]);
              __hook__('#()', __hook__('#.', this, ['parts'], __4fd4b53fa5d16ed9d37939b816e6233d5b7ad42253264e0412b80c143ec4a4c9__[7]), [
                'push',
                [{
                    type: 'attribute',
                    index,
                    name,
                    strings: statics
                  }]
              ], __4fd4b53fa5d16ed9d37939b816e6233d5b7ad42253264e0412b80c143ec4a4c9__[7]);
              partIndex += __hook__('#.', statics, ['length'], __4fd4b53fa5d16ed9d37939b816e6233d5b7ad42253264e0412b80c143ec4a4c9__[7]) - 1;
            }
          }
          if (__hook__('#.', node, ['tagName'], __4fd4b53fa5d16ed9d37939b816e6233d5b7ad42253264e0412b80c143ec4a4c9__[7]) === 'TEMPLATE') {
            __hook__('#()', stack, [
              'push',
              [node]
            ], __4fd4b53fa5d16ed9d37939b816e6233d5b7ad42253264e0412b80c143ec4a4c9__[7]);
            __hook__('#=', walker, [
              'currentNode',
              __hook__('#.', node, ['content'], __4fd4b53fa5d16ed9d37939b816e6233d5b7ad42253264e0412b80c143ec4a4c9__[7])
            ], __4fd4b53fa5d16ed9d37939b816e6233d5b7ad42253264e0412b80c143ec4a4c9__[7]);
          }
        } else if (__hook__('#.', node, ['nodeType'], __4fd4b53fa5d16ed9d37939b816e6233d5b7ad42253264e0412b80c143ec4a4c9__[7]) === 3  /* Node.TEXT_NODE */) {
          const data = __hook__('#.', node, ['data'], __4fd4b53fa5d16ed9d37939b816e6233d5b7ad42253264e0412b80c143ec4a4c9__[19]);
          if (__hook__('#()', data, [
              'indexOf',
              [__hook__('m', marker, [__4fd4b53fa5d16ed9d37939b816e6233d5b7ad42253264e0412b80c143ec4a4c9__[1]], __4fd4b53fa5d16ed9d37939b816e6233d5b7ad42253264e0412b80c143ec4a4c9__[7], null)]
            ], __4fd4b53fa5d16ed9d37939b816e6233d5b7ad42253264e0412b80c143ec4a4c9__[7]) >= 0) {
            const parent = __hook__('#.', node, ['parentNode'], __4fd4b53fa5d16ed9d37939b816e6233d5b7ad42253264e0412b80c143ec4a4c9__[20]);
            const strings = __hook__('#()', data, [
              'split',
              [__hook__('m', markerRegex, [__4fd4b53fa5d16ed9d37939b816e6233d5b7ad42253264e0412b80c143ec4a4c9__[5]], __4fd4b53fa5d16ed9d37939b816e6233d5b7ad42253264e0412b80c143ec4a4c9__[21], null)]
            ], __4fd4b53fa5d16ed9d37939b816e6233d5b7ad42253264e0412b80c143ec4a4c9__[21]);
            const lastIndex = __hook__('#.', strings, ['length'], __4fd4b53fa5d16ed9d37939b816e6233d5b7ad42253264e0412b80c143ec4a4c9__[22]) - 1;
            // Generate a new text node for each literal section
            // These nodes are also used as the markers for node parts
            for (let i = 0; i < lastIndex; i++) {
              let insert;
              let s = __hook__('#.', strings, [i], __4fd4b53fa5d16ed9d37939b816e6233d5b7ad42253264e0412b80c143ec4a4c9__[23]);
              if (s === '') {
                insert = __hook__('m()', createMarker, [
                  __4fd4b53fa5d16ed9d37939b816e6233d5b7ad42253264e0412b80c143ec4a4c9__[24],
                  [],
                  (...args) => createMarker(...args)
                ], __4fd4b53fa5d16ed9d37939b816e6233d5b7ad42253264e0412b80c143ec4a4c9__[7], null);
              } else {
                const match = __hook__('#()', __hook__('m', lastAttributeNameRegex, [__4fd4b53fa5d16ed9d37939b816e6233d5b7ad42253264e0412b80c143ec4a4c9__[15]], __4fd4b53fa5d16ed9d37939b816e6233d5b7ad42253264e0412b80c143ec4a4c9__[25], null), [
                  'exec',
                  [s]
                ], __4fd4b53fa5d16ed9d37939b816e6233d5b7ad42253264e0412b80c143ec4a4c9__[25]);
                if (match !== null && __hook__(endsWith, null, [
                    __hook__('#.', match, [2], __4fd4b53fa5d16ed9d37939b816e6233d5b7ad42253264e0412b80c143ec4a4c9__[7]),
                    __hook__('m', boundAttributeSuffix, [__4fd4b53fa5d16ed9d37939b816e6233d5b7ad42253264e0412b80c143ec4a4c9__[12]], __4fd4b53fa5d16ed9d37939b816e6233d5b7ad42253264e0412b80c143ec4a4c9__[7], null)
                  ], __4fd4b53fa5d16ed9d37939b816e6233d5b7ad42253264e0412b80c143ec4a4c9__[7], 0)) {
                  s = __hook__('#()', s, [
                    'slice',
                    [
                      0,
                      __hook__('#.', match, ['index'], __4fd4b53fa5d16ed9d37939b816e6233d5b7ad42253264e0412b80c143ec4a4c9__[7])
                    ]
                  ], __4fd4b53fa5d16ed9d37939b816e6233d5b7ad42253264e0412b80c143ec4a4c9__[7]) + __hook__('#.', match, [1], __4fd4b53fa5d16ed9d37939b816e6233d5b7ad42253264e0412b80c143ec4a4c9__[7]) + __hook__('#()', __hook__('#.', match, [2], __4fd4b53fa5d16ed9d37939b816e6233d5b7ad42253264e0412b80c143ec4a4c9__[7]), [
                    'slice',
                    [
                      0,
                      -__hook__('#.', __hook__('m', boundAttributeSuffix, [__4fd4b53fa5d16ed9d37939b816e6233d5b7ad42253264e0412b80c143ec4a4c9__[12]], __4fd4b53fa5d16ed9d37939b816e6233d5b7ad42253264e0412b80c143ec4a4c9__[7], null), ['length'], __4fd4b53fa5d16ed9d37939b816e6233d5b7ad42253264e0412b80c143ec4a4c9__[7])
                    ]
                  ], __4fd4b53fa5d16ed9d37939b816e6233d5b7ad42253264e0412b80c143ec4a4c9__[7]) + __hook__('#.', match, [3], __4fd4b53fa5d16ed9d37939b816e6233d5b7ad42253264e0412b80c143ec4a4c9__[7]);
                }
                insert = __hook__('#()', $hook$.global(__hook__, __4fd4b53fa5d16ed9d37939b816e6233d5b7ad42253264e0412b80c143ec4a4c9__[7], 'document', '#get')[__4fd4b53fa5d16ed9d37939b816e6233d5b7ad42253264e0412b80c143ec4a4c9__[26]], [
                  'createTextNode',
                  [s]
                ], __4fd4b53fa5d16ed9d37939b816e6233d5b7ad42253264e0412b80c143ec4a4c9__[7]);
              }
              __hook__('#()', parent, [
                'insertBefore',
                [
                  insert,
                  node
                ]
              ], __4fd4b53fa5d16ed9d37939b816e6233d5b7ad42253264e0412b80c143ec4a4c9__[7]);
              __hook__('#()', __hook__('#.', this, ['parts'], __4fd4b53fa5d16ed9d37939b816e6233d5b7ad42253264e0412b80c143ec4a4c9__[7]), [
                'push',
                [{
                    type: 'node',
                    index: ++index
                  }]
              ], __4fd4b53fa5d16ed9d37939b816e6233d5b7ad42253264e0412b80c143ec4a4c9__[7]);
            }
            // If there's no text, we must insert a comment to mark our place.
            // Else, we can trust it will stick around after cloning.
            if (__hook__('#.', strings, [lastIndex], __4fd4b53fa5d16ed9d37939b816e6233d5b7ad42253264e0412b80c143ec4a4c9__[7]) === '') {
              __hook__('#()', parent, [
                'insertBefore',
                [
                  __hook__('m()', createMarker, [
                    __4fd4b53fa5d16ed9d37939b816e6233d5b7ad42253264e0412b80c143ec4a4c9__[24],
                    [],
                    (...args) => createMarker(...args)
                  ], __4fd4b53fa5d16ed9d37939b816e6233d5b7ad42253264e0412b80c143ec4a4c9__[7], null),
                  node
                ]
              ], __4fd4b53fa5d16ed9d37939b816e6233d5b7ad42253264e0412b80c143ec4a4c9__[7]);
              __hook__('#()', nodesToRemove, [
                'push',
                [node]
              ], __4fd4b53fa5d16ed9d37939b816e6233d5b7ad42253264e0412b80c143ec4a4c9__[7]);
            } else {
              __hook__('#=', node, [
                'data',
                __hook__('#.', strings, [lastIndex], __4fd4b53fa5d16ed9d37939b816e6233d5b7ad42253264e0412b80c143ec4a4c9__[7])
              ], __4fd4b53fa5d16ed9d37939b816e6233d5b7ad42253264e0412b80c143ec4a4c9__[7]);
            }
            // We have a part for each match found
            partIndex += lastIndex;
          }
        } else if (__hook__('#.', node, ['nodeType'], __4fd4b53fa5d16ed9d37939b816e6233d5b7ad42253264e0412b80c143ec4a4c9__[7]) === 8  /* Node.COMMENT_NODE */) {
          if (__hook__('#.', node, ['data'], __4fd4b53fa5d16ed9d37939b816e6233d5b7ad42253264e0412b80c143ec4a4c9__[7]) === __hook__('m', marker, [__4fd4b53fa5d16ed9d37939b816e6233d5b7ad42253264e0412b80c143ec4a4c9__[1]], __4fd4b53fa5d16ed9d37939b816e6233d5b7ad42253264e0412b80c143ec4a4c9__[7], null)) {
            const parent = __hook__('#.', node, ['parentNode'], __4fd4b53fa5d16ed9d37939b816e6233d5b7ad42253264e0412b80c143ec4a4c9__[20]);
            // Add a new marker node to be the startNode of the Part if any of
            // the following are true:
            //  * We don't have a previousSibling
            //  * The previousSibling is already the start of a previous part
            if (__hook__('#.', node, ['previousSibling'], __4fd4b53fa5d16ed9d37939b816e6233d5b7ad42253264e0412b80c143ec4a4c9__[7]) === null || index === lastPartIndex) {
              index++;
              __hook__('#()', parent, [
                'insertBefore',
                [
                  __hook__('m()', createMarker, [
                    __4fd4b53fa5d16ed9d37939b816e6233d5b7ad42253264e0412b80c143ec4a4c9__[24],
                    [],
                    (...args) => createMarker(...args)
                  ], __4fd4b53fa5d16ed9d37939b816e6233d5b7ad42253264e0412b80c143ec4a4c9__[7], null),
                  node
                ]
              ], __4fd4b53fa5d16ed9d37939b816e6233d5b7ad42253264e0412b80c143ec4a4c9__[7]);
            }
            lastPartIndex = index;
            __hook__('#()', __hook__('#.', this, ['parts'], __4fd4b53fa5d16ed9d37939b816e6233d5b7ad42253264e0412b80c143ec4a4c9__[7]), [
              'push',
              [{
                  type: 'node',
                  index
                }]
            ], __4fd4b53fa5d16ed9d37939b816e6233d5b7ad42253264e0412b80c143ec4a4c9__[7]);
            // If we don't have a nextSibling, keep this node so we have an end.
            // Else, we can remove it to save future costs.
            if (__hook__('#.', node, ['nextSibling'], __4fd4b53fa5d16ed9d37939b816e6233d5b7ad42253264e0412b80c143ec4a4c9__[7]) === null) {
              __hook__('#=', node, [
                'data',
                ''
              ], __4fd4b53fa5d16ed9d37939b816e6233d5b7ad42253264e0412b80c143ec4a4c9__[7]);
            } else {
              __hook__('#()', nodesToRemove, [
                'push',
                [node]
              ], __4fd4b53fa5d16ed9d37939b816e6233d5b7ad42253264e0412b80c143ec4a4c9__[7]);
              index--;
            }
            partIndex++;
          } else {
            let i = -1;
            while ((i = __hook__('#()', __hook__('#.', node, ['data'], __4fd4b53fa5d16ed9d37939b816e6233d5b7ad42253264e0412b80c143ec4a4c9__[7]), [
                'indexOf',
                [
                  __hook__('m', marker, [__4fd4b53fa5d16ed9d37939b816e6233d5b7ad42253264e0412b80c143ec4a4c9__[1]], __4fd4b53fa5d16ed9d37939b816e6233d5b7ad42253264e0412b80c143ec4a4c9__[7], null),
                  i + 1
                ]
              ], __4fd4b53fa5d16ed9d37939b816e6233d5b7ad42253264e0412b80c143ec4a4c9__[7])) !== -1) {
              // Comment node has a binding marker inside, make an inactive part
              // The binding won't work, but subsequent bindings will
              // TODO (justinfagnani): consider whether it's even worth it to
              // make bindings in comments work
              __hook__('#()', __hook__('#.', this, ['parts'], __4fd4b53fa5d16ed9d37939b816e6233d5b7ad42253264e0412b80c143ec4a4c9__[7]), [
                'push',
                [{
                    type: 'node',
                    index: -1
                  }]
              ], __4fd4b53fa5d16ed9d37939b816e6233d5b7ad42253264e0412b80c143ec4a4c9__[7]);
              partIndex++;
            }
          }
        }
      }
      // Remove text binding nodes after the walk to not disturb the TreeWalker
      for (const n of __hook__('#*', nodesToRemove, [], __4fd4b53fa5d16ed9d37939b816e6233d5b7ad42253264e0412b80c143ec4a4c9__[7])) {
        __hook__('#()', __hook__('#.', n, ['parentNode'], __4fd4b53fa5d16ed9d37939b816e6233d5b7ad42253264e0412b80c143ec4a4c9__[7]), [
          'removeChild',
          [n]
        ], __4fd4b53fa5d16ed9d37939b816e6233d5b7ad42253264e0412b80c143ec4a4c9__[7]);
      }
    }, null, arguments, __4fd4b53fa5d16ed9d37939b816e6233d5b7ad42253264e0412b80c143ec4a4c9__[7]);
  }
}
const endsWith = (...args) =>
  (__hook__((str, suffix) => {
    const index = __hook__('#.', str, ['length'], __4fd4b53fa5d16ed9d37939b816e6233d5b7ad42253264e0412b80c143ec4a4c9__[28]) - __hook__('#.', suffix, ['length'], __4fd4b53fa5d16ed9d37939b816e6233d5b7ad42253264e0412b80c143ec4a4c9__[28]);
    return index >= 0 && __hook__('#()', str, [
      'slice',
      [index]
    ], __4fd4b53fa5d16ed9d37939b816e6233d5b7ad42253264e0412b80c143ec4a4c9__[27]) === suffix;
  }, null, args, __4fd4b53fa5d16ed9d37939b816e6233d5b7ad42253264e0412b80c143ec4a4c9__[27]));
const isTemplatePartActive = (...args) => __hook__(part => __hook__('#.', part, ['index'], __4fd4b53fa5d16ed9d37939b816e6233d5b7ad42253264e0412b80c143ec4a4c9__[29]) !== -1, null, args, __4fd4b53fa5d16ed9d37939b816e6233d5b7ad42253264e0412b80c143ec4a4c9__[29]);
// Allows `document.createComment('')` to be renamed for a
// small manual size-savings.
const createMarker = (...args) => __hook__(() => __hook__('#()', $hook$.global(__hook__, __4fd4b53fa5d16ed9d37939b816e6233d5b7ad42253264e0412b80c143ec4a4c9__[24], 'document', '#get')[__4fd4b53fa5d16ed9d37939b816e6233d5b7ad42253264e0412b80c143ec4a4c9__[30]], [
  'createComment',
  ['']
], __4fd4b53fa5d16ed9d37939b816e6233d5b7ad42253264e0412b80c143ec4a4c9__[24]), null, args, __4fd4b53fa5d16ed9d37939b816e6233d5b7ad42253264e0412b80c143ec4a4c9__[24]);
/**
 * This regex extracts the attribute name preceding an attribute-position
 * expression. It does this by matching the syntax allowed for attributes
 * against the string literal directly preceding the expression, assuming that
 * the expression is in an attribute-value position.
 *
 * See attributes in the HTML spec:
 * https://www.w3.org/TR/html5/syntax.html#elements-attributes
 *
 * " \x09\x0a\x0c\x0d" are HTML space characters:
 * https://www.w3.org/TR/html5/infrastructure.html#space-characters
 *
 * "\0-\x1F\x7F-\x9F" are Unicode control characters, which includes every
 * space character except " ".
 *
 * So an attribute is:
 *  * The name: any character except a control character, space character, ('),
 *    ("), ">", "=", or "/"
 *  * Followed by zero or more space characters
 *  * Followed by "="
 *  * Followed by zero or more space characters
 *  * Followed by:
 *    * Any character except space, ('), ("), "<", ">", "=", (`), or
 *    * (") then any non-("), or
 *    * (') then any non-(')
 */
const lastAttributeNameRegex = // eslint-disable-next-line no-control-regex
/([ \x09\x0a\x0c\x0d])([^\0-\x1F\x7F-\x9F "'>=/]+)([ \x09\x0a\x0c\x0d]*=[ \x09\x0a\x0c\x0d]*(?:[^ \x09\x0a\x0c\x0d"'`<>=]*|"[^"]*|'[^']*))$/;  __hook__(() => {
}, null, [
  'export',
  __4fd4b53fa5d16ed9d37939b816e6233d5b7ad42253264e0412b80c143ec4a4c9__[0],
  __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__module_namespace_6
], __4fd4b53fa5d16ed9d37939b816e6233d5b7ad42253264e0412b80c143ec4a4c9__[0], NaN);

/**
 * @license
 * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
 * This code may only be used under the BSD style license found at
 * http://polymer.github.io/LICENSE.txt
 * The complete set of authors may be found at
 * http://polymer.github.io/AUTHORS.txt
 * The complete set of contributors may be found at
 * http://polymer.github.io/CONTRIBUTORS.txt
 * Code distributed by Google as part of the polymer project is also
 * subject to an additional IP rights grant found at
 * http://polymer.github.io/PATENTS.txt
 */
/**
 * @module shady-render
 */
const __8f82a98aac99b1875fb5078520b682363a66a6272a90f29f287db756ef6e6d29__ = $hook$.$(__hook__, [
  '/components/thin-hook/demo/node_modules/lit-html/lib/modify-template.js',
  '/components/thin-hook/demo/node_modules/lit-html/lib/template.js',
  '/components/thin-hook/demo/node_modules/lit-html/lib/modify-template.js,removeNodesFromTemplate',
  '/components/thin-hook/demo/node_modules/lit-html/lib/modify-template.js,removeNodesFromTemplate,walker',
  'S_uNpREdiC4aB1e_document;/components/thin-hook/demo/node_modules/lit-html/lib/modify-template.js,removeNodesFromTemplate,walker',
  '/components/thin-hook/demo/node_modules/lit-html/lib/modify-template.js,removeNodesFromTemplate,partIndex',
  '/components/thin-hook/demo/node_modules/lit-html/lib/modify-template.js,removeNodesFromTemplate,part',
  '/components/thin-hook/demo/node_modules/lit-html/lib/modify-template.js,removeNodesFromTemplate,node',
  'S_uNpREdiC4aB1e_undefined;/components/thin-hook/demo/node_modules/lit-html/lib/modify-template.js,removeNodesFromTemplate',
  '/components/thin-hook/demo/node_modules/lit-html/lib/modify-template.js,countNodes',
  '/components/thin-hook/demo/node_modules/lit-html/lib/modify-template.js,countNodes,count',
  '/components/thin-hook/demo/node_modules/lit-html/lib/modify-template.js,countNodes,walker',
  'S_uNpREdiC4aB1e_document;/components/thin-hook/demo/node_modules/lit-html/lib/modify-template.js,countNodes,walker',
  '/components/thin-hook/demo/node_modules/lit-html/lib/modify-template.js,nextActiveIndexInTemplateParts',
  '/components/thin-hook/demo/node_modules/lit-html/lib/modify-template.js,nextActiveIndexInTemplateParts,part',
  '/components/thin-hook/demo/node_modules/lit-html/lib/template.js,isTemplatePartActive',
  '/components/thin-hook/demo/node_modules/lit-html/lib/modify-template.js,insertNodeIntoTemplate',
  'S_uNpREdiC4aB1e_undefined;/components/thin-hook/demo/node_modules/lit-html/lib/modify-template.js,insertNodeIntoTemplate',
  '/components/thin-hook/demo/node_modules/lit-html/lib/modify-template.js,insertNodeIntoTemplate,walker',
  'S_uNpREdiC4aB1e_document;/components/thin-hook/demo/node_modules/lit-html/lib/modify-template.js,insertNodeIntoTemplate,walker',
  '/components/thin-hook/demo/node_modules/lit-html/lib/modify-template.js,insertNodeIntoTemplate,partIndex',
  '/components/thin-hook/demo/node_modules/lit-html/lib/modify-template.js,insertNodeIntoTemplate,walkerNode'
]);
__hook__(() => {
}, null, [
  'import',
  {
    [__8f82a98aac99b1875fb5078520b682363a66a6272a90f29f287db756ef6e6d29__[1]]: [
      __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__module_namespace_6,
      'isTemplatePartActive'
    ]
  }
], __8f82a98aac99b1875fb5078520b682363a66a6272a90f29f287db756ef6e6d29__[0], NaN);
const walkerNodeFilter = 133  /* NodeFilter.SHOW_{ELEMENT|COMMENT|TEXT} */;
/**
 * Removes the list of nodes from a Template safely. In addition to removing
 * nodes from the Template, the Template part indices are updated to match
 * the mutated Template DOM.
 *
 * As the template is walked the removal state is tracked and
 * part indices are adjusted as needed.
 *
 * div
 *   div#1 (remove) <-- start removing (removing node is div#1)
 *     div
 *       div#2 (remove)  <-- continue removing (removing node is still div#1)
 *         div
 * div <-- stop removing since previous sibling is the removing node (div#1,
 * removed 4 nodes)
 */
function removeNodesFromTemplate(template, nodesToRemove) {
  return __hook__((template, nodesToRemove) => {
    const {
      element: {content},
      parts
    } = __hook__('#*', template, [], __8f82a98aac99b1875fb5078520b682363a66a6272a90f29f287db756ef6e6d29__[2]);
    const walker = __hook__('#()', $hook$.global(__hook__, __8f82a98aac99b1875fb5078520b682363a66a6272a90f29f287db756ef6e6d29__[3], 'document', '#get')[__8f82a98aac99b1875fb5078520b682363a66a6272a90f29f287db756ef6e6d29__[4]], [
      'createTreeWalker',
      [
        content,
        walkerNodeFilter,
        null,
        false
      ]
    ], __8f82a98aac99b1875fb5078520b682363a66a6272a90f29f287db756ef6e6d29__[3]);
    let partIndex = __hook__(nextActiveIndexInTemplateParts, null, [parts], __8f82a98aac99b1875fb5078520b682363a66a6272a90f29f287db756ef6e6d29__[5], 0);
    let part = __hook__('#.', parts, [partIndex], __8f82a98aac99b1875fb5078520b682363a66a6272a90f29f287db756ef6e6d29__[6]);
    let nodeIndex = -1;
    let removeCount = 0;
    const nodesToRemoveInTemplate = [];
    let currentRemovingNode = null;
    while (__hook__('#()', walker, [
        'nextNode',
        []
      ], __8f82a98aac99b1875fb5078520b682363a66a6272a90f29f287db756ef6e6d29__[2])) {
      nodeIndex++;
      const node = __hook__('#.', walker, ['currentNode'], __8f82a98aac99b1875fb5078520b682363a66a6272a90f29f287db756ef6e6d29__[7]);
      // End removal if stepped past the removing node
      if (__hook__('#.', node, ['previousSibling'], __8f82a98aac99b1875fb5078520b682363a66a6272a90f29f287db756ef6e6d29__[2]) === currentRemovingNode) {
        currentRemovingNode = null;
      }
      // A node to remove was found in the template
      if (__hook__('#()', nodesToRemove, [
          'has',
          [node]
        ], __8f82a98aac99b1875fb5078520b682363a66a6272a90f29f287db756ef6e6d29__[2])) {
        __hook__('#()', nodesToRemoveInTemplate, [
          'push',
          [node]
        ], __8f82a98aac99b1875fb5078520b682363a66a6272a90f29f287db756ef6e6d29__[2]);
        // Track node we're removing
        if (currentRemovingNode === null) {
          currentRemovingNode = node;
        }
      }
      // When removing, increment count by which to adjust subsequent part indices
      if (currentRemovingNode !== null) {
        removeCount++;
      }
      while (part !== $hook$.global(__hook__, __8f82a98aac99b1875fb5078520b682363a66a6272a90f29f287db756ef6e6d29__[2], 'undefined', '#get')[__8f82a98aac99b1875fb5078520b682363a66a6272a90f29f287db756ef6e6d29__[8]] && __hook__('#.', part, ['index'], __8f82a98aac99b1875fb5078520b682363a66a6272a90f29f287db756ef6e6d29__[2]) === nodeIndex) {
        // If part is in a removed node deactivate it by setting index to -1 or
        // adjust the index as needed.
        __hook__('#=', part, [
          'index',
          currentRemovingNode !== null ? -1 : __hook__('#.', part, ['index'], __8f82a98aac99b1875fb5078520b682363a66a6272a90f29f287db756ef6e6d29__[2]) - removeCount
        ], __8f82a98aac99b1875fb5078520b682363a66a6272a90f29f287db756ef6e6d29__[2]);
        // go to the next active part.
        partIndex = __hook__(nextActiveIndexInTemplateParts, null, [
          parts,
          partIndex
        ], __8f82a98aac99b1875fb5078520b682363a66a6272a90f29f287db756ef6e6d29__[2], 0);
        part = __hook__('#.', parts, [partIndex], __8f82a98aac99b1875fb5078520b682363a66a6272a90f29f287db756ef6e6d29__[2]);
      }
    }
    __hook__('#()', nodesToRemoveInTemplate, [
      'forEach',
      [(...args) => __hook__(n => __hook__('#()', __hook__('#.', n, ['parentNode'], __8f82a98aac99b1875fb5078520b682363a66a6272a90f29f287db756ef6e6d29__[2]), [
          'removeChild',
          [n]
        ], __8f82a98aac99b1875fb5078520b682363a66a6272a90f29f287db756ef6e6d29__[2]), null, args, __8f82a98aac99b1875fb5078520b682363a66a6272a90f29f287db756ef6e6d29__[2])]
    ], __8f82a98aac99b1875fb5078520b682363a66a6272a90f29f287db756ef6e6d29__[2]);
  }, null, arguments, __8f82a98aac99b1875fb5078520b682363a66a6272a90f29f287db756ef6e6d29__[2]);
}
const countNodes = (...args) =>
  (__hook__(node => {
    let count = __hook__('#.', node, ['nodeType'], __8f82a98aac99b1875fb5078520b682363a66a6272a90f29f287db756ef6e6d29__[10]) === 11  /* Node.DOCUMENT_FRAGMENT_NODE */ ? 0 : 1;
    const walker = __hook__('#()', $hook$.global(__hook__, __8f82a98aac99b1875fb5078520b682363a66a6272a90f29f287db756ef6e6d29__[11], 'document', '#get')[__8f82a98aac99b1875fb5078520b682363a66a6272a90f29f287db756ef6e6d29__[12]], [
      'createTreeWalker',
      [
        node,
        walkerNodeFilter,
        null,
        false
      ]
    ], __8f82a98aac99b1875fb5078520b682363a66a6272a90f29f287db756ef6e6d29__[11]);
    while (__hook__('#()', walker, [
        'nextNode',
        []
      ], __8f82a98aac99b1875fb5078520b682363a66a6272a90f29f287db756ef6e6d29__[9])) {
      count++;
    }
    return count;
  }, null, args, __8f82a98aac99b1875fb5078520b682363a66a6272a90f29f287db756ef6e6d29__[9]));
const nextActiveIndexInTemplateParts = (...args) =>
  (__hook__((parts, startIndex = -1) => {
    for (let i = startIndex + 1; i < __hook__('#.', parts, ['length'], __8f82a98aac99b1875fb5078520b682363a66a6272a90f29f287db756ef6e6d29__[13]); i++) {
      const part = __hook__('#.', parts, [i], __8f82a98aac99b1875fb5078520b682363a66a6272a90f29f287db756ef6e6d29__[14]);
      if (__hook__('m()', isTemplatePartActive, [
          __8f82a98aac99b1875fb5078520b682363a66a6272a90f29f287db756ef6e6d29__[15],
          [part],
          (...args) => isTemplatePartActive(...args)
        ], __8f82a98aac99b1875fb5078520b682363a66a6272a90f29f287db756ef6e6d29__[13], null)) {
        return i;
      }
    }
    return -1;
  }, null, args, __8f82a98aac99b1875fb5078520b682363a66a6272a90f29f287db756ef6e6d29__[13]));
/**
 * Inserts the given node into the Template, optionally before the given
 * refNode. In addition to inserting the node into the Template, the Template
 * part indices are updated to match the mutated Template DOM.
 */
function insertNodeIntoTemplate(template, node, refNode) {
  return __hook__((template, node, refNode = null) => {
    const {
      element: {content},
      parts
    } = __hook__('#*', template, [], __8f82a98aac99b1875fb5078520b682363a66a6272a90f29f287db756ef6e6d29__[16]);
    // If there's no refNode, then put node at end of template.
    // No part indices need to be shifted in this case.
    if (refNode === null || refNode === $hook$.global(__hook__, __8f82a98aac99b1875fb5078520b682363a66a6272a90f29f287db756ef6e6d29__[16], 'undefined', '#get')[__8f82a98aac99b1875fb5078520b682363a66a6272a90f29f287db756ef6e6d29__[17]]) {
      __hook__('#()', content, [
        'appendChild',
        [node]
      ], __8f82a98aac99b1875fb5078520b682363a66a6272a90f29f287db756ef6e6d29__[16]);
      return;
    }
    const walker = __hook__('#()', $hook$.global(__hook__, __8f82a98aac99b1875fb5078520b682363a66a6272a90f29f287db756ef6e6d29__[18], 'document', '#get')[__8f82a98aac99b1875fb5078520b682363a66a6272a90f29f287db756ef6e6d29__[19]], [
      'createTreeWalker',
      [
        content,
        walkerNodeFilter,
        null,
        false
      ]
    ], __8f82a98aac99b1875fb5078520b682363a66a6272a90f29f287db756ef6e6d29__[18]);
    let partIndex = __hook__(nextActiveIndexInTemplateParts, null, [parts], __8f82a98aac99b1875fb5078520b682363a66a6272a90f29f287db756ef6e6d29__[20], 0);
    let insertCount = 0;
    let walkerIndex = -1;
    while (__hook__('#()', walker, [
        'nextNode',
        []
      ], __8f82a98aac99b1875fb5078520b682363a66a6272a90f29f287db756ef6e6d29__[16])) {
      walkerIndex++;
      const walkerNode = __hook__('#.', walker, ['currentNode'], __8f82a98aac99b1875fb5078520b682363a66a6272a90f29f287db756ef6e6d29__[21]);
      if (walkerNode === refNode) {
        insertCount = __hook__(countNodes, null, [node], __8f82a98aac99b1875fb5078520b682363a66a6272a90f29f287db756ef6e6d29__[16], 0);
        __hook__('#()', __hook__('#.', refNode, ['parentNode'], __8f82a98aac99b1875fb5078520b682363a66a6272a90f29f287db756ef6e6d29__[16]), [
          'insertBefore',
          [
            node,
            refNode
          ]
        ], __8f82a98aac99b1875fb5078520b682363a66a6272a90f29f287db756ef6e6d29__[16]);
      }
      while (partIndex !== -1 && __hook__('#.', __hook__('#.', parts, [partIndex], __8f82a98aac99b1875fb5078520b682363a66a6272a90f29f287db756ef6e6d29__[16]), ['index'], __8f82a98aac99b1875fb5078520b682363a66a6272a90f29f287db756ef6e6d29__[16]) === walkerIndex) {
        // If we've inserted the node, simply adjust all subsequent parts
        if (insertCount > 0) {
          while (partIndex !== -1) {
            __hook__('#+=', __hook__('#.', parts, [partIndex], __8f82a98aac99b1875fb5078520b682363a66a6272a90f29f287db756ef6e6d29__[16]), [
              'index',
              insertCount
            ], __8f82a98aac99b1875fb5078520b682363a66a6272a90f29f287db756ef6e6d29__[16]);
            partIndex = __hook__(nextActiveIndexInTemplateParts, null, [
              parts,
              partIndex
            ], __8f82a98aac99b1875fb5078520b682363a66a6272a90f29f287db756ef6e6d29__[16], 0);
          }
          return;
        }
        partIndex = __hook__(nextActiveIndexInTemplateParts, null, [
          parts,
          partIndex
        ], __8f82a98aac99b1875fb5078520b682363a66a6272a90f29f287db756ef6e6d29__[16], 0);
      }
    }
  }, null, arguments, __8f82a98aac99b1875fb5078520b682363a66a6272a90f29f287db756ef6e6d29__[16]);
}
__hook__(() => {
}, null, [
  'export',
  __8f82a98aac99b1875fb5078520b682363a66a6272a90f29f287db756ef6e6d29__[0],
  __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__module_namespace_2
], __8f82a98aac99b1875fb5078520b682363a66a6272a90f29f287db756ef6e6d29__[0], NaN);

/**
 * @license
 * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
 * This code may only be used under the BSD style license found at
 * http://polymer.github.io/LICENSE.txt
 * The complete set of authors may be found at
 * http://polymer.github.io/AUTHORS.txt
 * The complete set of contributors may be found at
 * http://polymer.github.io/CONTRIBUTORS.txt
 * Code distributed by Google as part of the polymer project is also
 * subject to an additional IP rights grant found at
 * http://polymer.github.io/PATENTS.txt
 */
const __2cbcf67741925b557ffe2d38a844bf86d79f67d8bf85b72cd712e1396de73476__ = $hook$.$(__hook__, [
  '/components/thin-hook/demo/node_modules/lit-html/lib/directive.js',
  '/components/thin-hook/demo/node_modules/lit-html/lib/directive.js,directives',
  'S_uNpREdiC4aB1e_WeakMap;/components/thin-hook/demo/node_modules/lit-html/lib/directive.js,directives',
  '/components/thin-hook/demo/node_modules/lit-html/lib/directive.js,directive',
  '/components/thin-hook/demo/node_modules/lit-html/lib/directive.js,directive,d',
  '/components/thin-hook/demo/node_modules/lit-html/lib/directive.js,isDirective'
]);
const directives = __hook__($hook$.global(__hook__, __2cbcf67741925b557ffe2d38a844bf86d79f67d8bf85b72cd712e1396de73476__[1], 'WeakMap', '#get')[__2cbcf67741925b557ffe2d38a844bf86d79f67d8bf85b72cd712e1396de73476__[2]], null, [], __2cbcf67741925b557ffe2d38a844bf86d79f67d8bf85b72cd712e1396de73476__[1], true);
/**
 * Brands a function as a directive factory function so that lit-html will call
 * the function during template rendering, rather than passing as a value.
 *
 * A _directive_ is a function that takes a Part as an argument. It has the
 * signature: `(part: Part) => void`.
 *
 * A directive _factory_ is a function that takes arguments for data and
 * configuration and returns a directive. Users of directive usually refer to
 * the directive factory as the directive. For example, "The repeat directive".
 *
 * Usually a template author will invoke a directive factory in their template
 * with relevant arguments, which will then return a directive function.
 *
 * Here's an example of using the `repeat()` directive factory that takes an
 * array and a function to render an item:
 *
 * ```js
 * html`<ul><${repeat(items, (item) => html`<li>${item}</li>`)}</ul>`
 * ```
 *
 * When `repeat` is invoked, it returns a directive function that closes over
 * `items` and the template function. When the outer template is rendered, the
 * return directive function is called with the Part for the expression.
 * `repeat` then performs it's custom logic to render multiple items.
 *
 * @param f The directive factory function. Must be a function that returns a
 * function of the signature `(part: Part) => void`. The returned function will
 * be called with the part object.
 *
 * @example
 *
 * import {directive, html} from 'lit-html';
 *
 * const immutable = directive((v) => (part) => {
 *   if (part.value !== v) {
 *     part.setValue(v)
 *   }
 * });
 */
const directive = (...args) => __hook__(f => (...args) =>
  (__hook__((...args) => {
    const d = __hook__(f, null, [...args], __2cbcf67741925b557ffe2d38a844bf86d79f67d8bf85b72cd712e1396de73476__[4], 0);
    __hook__('#()', directives, [
      'set',
      [
        d,
        true
      ]
    ], __2cbcf67741925b557ffe2d38a844bf86d79f67d8bf85b72cd712e1396de73476__[3]);
    return d;
  }, null, args, __2cbcf67741925b557ffe2d38a844bf86d79f67d8bf85b72cd712e1396de73476__[3])), null, args, __2cbcf67741925b557ffe2d38a844bf86d79f67d8bf85b72cd712e1396de73476__[3]);
const isDirective = (...args) =>
  (__hook__(o => {
    return typeof o === 'function' && __hook__('#()', directives, [
      'has',
      [o]
    ], __2cbcf67741925b557ffe2d38a844bf86d79f67d8bf85b72cd712e1396de73476__[5]);
  }, null, args, __2cbcf67741925b557ffe2d38a844bf86d79f67d8bf85b72cd712e1396de73476__[5]));  __hook__(() => {
}, null, [
  'export',
  __2cbcf67741925b557ffe2d38a844bf86d79f67d8bf85b72cd712e1396de73476__[0],
  __045213766b0e56a0c3f2db9279bb9770e31ccd73fa3bc118b7423459ba0ec60e__module_namespace_3
], __2cbcf67741925b557ffe2d38a844bf86d79f67d8bf85b72cd712e1396de73476__[0], NaN);

/**
 * @license
 * Copyright (c) 2018 The Polymer Project Authors. All rights reserved.
 * This code may only be used under the BSD style license found at
 * http://polymer.github.io/LICENSE.txt
 * The complete set of authors may be found at
 * http://polymer.github.io/AUTHORS.txt
 * The complete set of contributors may be found at
 * http://polymer.github.io/CONTRIBUTORS.txt
 * Code distributed by Google as part of the polymer project is also
 * subject to an additional IP rights grant found at
 * http://polymer.github.io/PATENTS.txt
 */
/**
 * A sentinel value that signals that a value was handled by a directive and
 * should not be written to the DOM.
 */
const __03d0b1b53b72731763b30ef64389b3567be920e1d726a17d33240fa0d99e3cb5__ = $hook$.$(__hook__, ['/components/thin-hook/demo/node_modules/lit-html/lib/part.js']);
const noChange = {};
/**
 * A sentinel value that signals a NodePart to fully clear its content.
 */
const nothing = {};  __hook__(() => {
}, null, [
  'export',
  __03d0b1b53b72731763b30ef64389b3567be920e1d726a17d33240fa0d99e3cb5__[0],
  __045213766b0e56a0c3f2db9279bb9770e31ccd73fa3bc118b7423459ba0ec60e__module_namespace_5
], __03d0b1b53b72731763b30ef64389b3567be920e1d726a17d33240fa0d99e3cb5__[0], NaN);

/**
 * @license
 * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
 * This code may only be used under the BSD style license found at
 * http://polymer.github.io/LICENSE.txt
 * The complete set of authors may be found at
 * http://polymer.github.io/AUTHORS.txt
 * The complete set of contributors may be found at
 * http://polymer.github.io/CONTRIBUTORS.txt
 * Code distributed by Google as part of the polymer project is also
 * subject to an additional IP rights grant found at
 * http://polymer.github.io/PATENTS.txt
 */
/**
 * @module lit-html
 */
const __cfea6cad3c8fbb08f16c8c829b77b3f30f9eb9d5acf6e20a9ad78dce6f12ab13__ = $hook$.$(__hook__, [
  '/components/thin-hook/demo/node_modules/lit-html/lib/template-instance.js',
  '/components/thin-hook/demo/node_modules/lit-html/lib/dom.js',
  '/components/thin-hook/demo/node_modules/lit-html/lib/template.js',
  '/components/thin-hook/demo/node_modules/lit-html/lib/template-instance.js,TemplateInstance,constructor',
  '/components/thin-hook/demo/node_modules/lit-html/lib/template-instance.js,TemplateInstance,update',
  'S_uNpREdiC4aB1e_undefined;/components/thin-hook/demo/node_modules/lit-html/lib/template-instance.js,TemplateInstance,update',
  '/components/thin-hook/demo/node_modules/lit-html/lib/template-instance.js,TemplateInstance,_clone',
  '/components/thin-hook/demo/node_modules/lit-html/lib/template-instance.js,TemplateInstance,_clone,fragment',
  '/components/thin-hook/demo/node_modules/lit-html/lib/dom.js,isCEPolyfill',
  'S_uNpREdiC4aB1e_document;/components/thin-hook/demo/node_modules/lit-html/lib/template-instance.js,TemplateInstance,_clone,fragment',
  '/components/thin-hook/demo/node_modules/lit-html/lib/template-instance.js,TemplateInstance,_clone,parts',
  '/components/thin-hook/demo/node_modules/lit-html/lib/template-instance.js,TemplateInstance,_clone,walker',
  'S_uNpREdiC4aB1e_document;/components/thin-hook/demo/node_modules/lit-html/lib/template-instance.js,TemplateInstance,_clone,walker',
  '/components/thin-hook/demo/node_modules/lit-html/lib/template-instance.js,TemplateInstance,_clone,node',
  '/components/thin-hook/demo/node_modules/lit-html/lib/template.js,isTemplatePartActive',
  'S_uNpREdiC4aB1e_undefined;/components/thin-hook/demo/node_modules/lit-html/lib/template-instance.js,TemplateInstance,_clone',
  '/components/thin-hook/demo/node_modules/lit-html/lib/template-instance.js,TemplateInstance,_clone,part',
  'S_uNpREdiC4aB1e_document;/components/thin-hook/demo/node_modules/lit-html/lib/template-instance.js,TemplateInstance,_clone',
  'S_uNpREdiC4aB1e_customElements;/components/thin-hook/demo/node_modules/lit-html/lib/template-instance.js,TemplateInstance,_clone'
]);
__hook__(() => {
}, null, [
  'import',
  {
    [__cfea6cad3c8fbb08f16c8c829b77b3f30f9eb9d5acf6e20a9ad78dce6f12ab13__[1]]: [
      __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__module_namespace_1,
      'isCEPolyfill'
    ],
    [__cfea6cad3c8fbb08f16c8c829b77b3f30f9eb9d5acf6e20a9ad78dce6f12ab13__[2]]: [
      __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__module_namespace_6,
      'isTemplatePartActive'
    ]
  }
], __cfea6cad3c8fbb08f16c8c829b77b3f30f9eb9d5acf6e20a9ad78dce6f12ab13__[0], NaN);
/**
 * An instance of a `Template` that can be attached to the DOM and updated
 * with new values.
 */
class TemplateInstance {
  constructor(template, processor, options) {
    return __hook__((template, processor, options) => {
      __hook__('#=', this, [
        '__parts',
        []
      ], __cfea6cad3c8fbb08f16c8c829b77b3f30f9eb9d5acf6e20a9ad78dce6f12ab13__[3]);
      __hook__('#=', this, [
        'template',
        template
      ], __cfea6cad3c8fbb08f16c8c829b77b3f30f9eb9d5acf6e20a9ad78dce6f12ab13__[3]);
      __hook__('#=', this, [
        'processor',
        processor
      ], __cfea6cad3c8fbb08f16c8c829b77b3f30f9eb9d5acf6e20a9ad78dce6f12ab13__[3]);
      __hook__('#=', this, [
        'options',
        options
      ], __cfea6cad3c8fbb08f16c8c829b77b3f30f9eb9d5acf6e20a9ad78dce6f12ab13__[3]);
    }, null, arguments, __cfea6cad3c8fbb08f16c8c829b77b3f30f9eb9d5acf6e20a9ad78dce6f12ab13__[3]);
  }
  update(values) {
    return __hook__(values => {
      let i = 0;
      for (const part of __hook__('#*', __hook__('#.', this, ['__parts'], __cfea6cad3c8fbb08f16c8c829b77b3f30f9eb9d5acf6e20a9ad78dce6f12ab13__[4]), [], __cfea6cad3c8fbb08f16c8c829b77b3f30f9eb9d5acf6e20a9ad78dce6f12ab13__[4])) {
        if (part !== $hook$.global(__hook__, __cfea6cad3c8fbb08f16c8c829b77b3f30f9eb9d5acf6e20a9ad78dce6f12ab13__[4], 'undefined', '#get')[__cfea6cad3c8fbb08f16c8c829b77b3f30f9eb9d5acf6e20a9ad78dce6f12ab13__[5]]) {
          __hook__('#()', part, [
            'setValue',
            [__hook__('#.', values, [i], __cfea6cad3c8fbb08f16c8c829b77b3f30f9eb9d5acf6e20a9ad78dce6f12ab13__[4])]
          ], __cfea6cad3c8fbb08f16c8c829b77b3f30f9eb9d5acf6e20a9ad78dce6f12ab13__[4]);
        }
        i++;
      }
      for (const part of __hook__('#*', __hook__('#.', this, ['__parts'], __cfea6cad3c8fbb08f16c8c829b77b3f30f9eb9d5acf6e20a9ad78dce6f12ab13__[4]), [], __cfea6cad3c8fbb08f16c8c829b77b3f30f9eb9d5acf6e20a9ad78dce6f12ab13__[4])) {
        if (part !== $hook$.global(__hook__, __cfea6cad3c8fbb08f16c8c829b77b3f30f9eb9d5acf6e20a9ad78dce6f12ab13__[4], 'undefined', '#get')[__cfea6cad3c8fbb08f16c8c829b77b3f30f9eb9d5acf6e20a9ad78dce6f12ab13__[5]]) {
          __hook__('#()', part, [
            'commit',
            []
          ], __cfea6cad3c8fbb08f16c8c829b77b3f30f9eb9d5acf6e20a9ad78dce6f12ab13__[4]);
        }
      }
    }, null, arguments, __cfea6cad3c8fbb08f16c8c829b77b3f30f9eb9d5acf6e20a9ad78dce6f12ab13__[4]);
  }
  _clone() {
    return __hook__(() => {
      // There are a number of steps in the lifecycle of a template instance's
      // DOM fragment:
      //  1. Clone - create the instance fragment
      //  2. Adopt - adopt into the main document
      //  3. Process - find part markers and create parts
      //  4. Upgrade - upgrade custom elements
      //  5. Update - set node, attribute, property, etc., values
      //  6. Connect - connect to the document. Optional and outside of this
      //     method.
      //
      // We have a few constraints on the ordering of these steps:
      //  * We need to upgrade before updating, so that property values will pass
      //    through any property setters.
      //  * We would like to process before upgrading so that we're sure that the
      //    cloned fragment is inert and not disturbed by self-modifying DOM.
      //  * We want custom elements to upgrade even in disconnected fragments.
      //
      // Given these constraints, with full custom elements support we would
      // prefer the order: Clone, Process, Adopt, Upgrade, Update, Connect
      //
      // But Safari does not implement CustomElementRegistry#upgrade, so we
      // can not implement that order and still have upgrade-before-update and
      // upgrade disconnected fragments. So we instead sacrifice the
      // process-before-upgrade constraint, since in Custom Elements v1 elements
      // must not modify their light DOM in the constructor. We still have issues
      // when co-existing with CEv0 elements like Polymer 1, and with polyfills
      // that don't strictly adhere to the no-modification rule because shadow
      // DOM, which may be created in the constructor, is emulated by being placed
      // in the light DOM.
      //
      // The resulting order is on native is: Clone, Adopt, Upgrade, Process,
      // Update, Connect. document.importNode() performs Clone, Adopt, and Upgrade
      // in one step.
      //
      // The Custom Elements v1 polyfill supports upgrade(), so the order when
      // polyfilled is the more ideal: Clone, Process, Adopt, Upgrade, Update,
      // Connect.
      const fragment = __hook__('m', isCEPolyfill, [__cfea6cad3c8fbb08f16c8c829b77b3f30f9eb9d5acf6e20a9ad78dce6f12ab13__[8]], __cfea6cad3c8fbb08f16c8c829b77b3f30f9eb9d5acf6e20a9ad78dce6f12ab13__[7], null) ? __hook__('#()', __hook__('#.', __hook__('#.', __hook__('#.', this, ['template'], __cfea6cad3c8fbb08f16c8c829b77b3f30f9eb9d5acf6e20a9ad78dce6f12ab13__[7]), ['element'], __cfea6cad3c8fbb08f16c8c829b77b3f30f9eb9d5acf6e20a9ad78dce6f12ab13__[7]), ['content'], __cfea6cad3c8fbb08f16c8c829b77b3f30f9eb9d5acf6e20a9ad78dce6f12ab13__[7]), [
        'cloneNode',
        [true]
      ], __cfea6cad3c8fbb08f16c8c829b77b3f30f9eb9d5acf6e20a9ad78dce6f12ab13__[7]) : __hook__('#()', $hook$.global(__hook__, __cfea6cad3c8fbb08f16c8c829b77b3f30f9eb9d5acf6e20a9ad78dce6f12ab13__[7], 'document', '#get')[__cfea6cad3c8fbb08f16c8c829b77b3f30f9eb9d5acf6e20a9ad78dce6f12ab13__[9]], [
        'importNode',
        [
          __hook__('#.', __hook__('#.', __hook__('#.', this, ['template'], __cfea6cad3c8fbb08f16c8c829b77b3f30f9eb9d5acf6e20a9ad78dce6f12ab13__[7]), ['element'], __cfea6cad3c8fbb08f16c8c829b77b3f30f9eb9d5acf6e20a9ad78dce6f12ab13__[7]), ['content'], __cfea6cad3c8fbb08f16c8c829b77b3f30f9eb9d5acf6e20a9ad78dce6f12ab13__[7]),
          true
        ]
      ], __cfea6cad3c8fbb08f16c8c829b77b3f30f9eb9d5acf6e20a9ad78dce6f12ab13__[7]);
      const stack = [];
      const parts = __hook__('#.', __hook__('#.', this, ['template'], __cfea6cad3c8fbb08f16c8c829b77b3f30f9eb9d5acf6e20a9ad78dce6f12ab13__[10]), ['parts'], __cfea6cad3c8fbb08f16c8c829b77b3f30f9eb9d5acf6e20a9ad78dce6f12ab13__[10]);
      // Edge needs all 4 parameters present; IE11 needs 3rd parameter to be null
      const walker = __hook__('#()', $hook$.global(__hook__, __cfea6cad3c8fbb08f16c8c829b77b3f30f9eb9d5acf6e20a9ad78dce6f12ab13__[11], 'document', '#get')[__cfea6cad3c8fbb08f16c8c829b77b3f30f9eb9d5acf6e20a9ad78dce6f12ab13__[12]], [
        'createTreeWalker',
        [
          fragment,
          133  /* NodeFilter.SHOW_{ELEMENT|COMMENT|TEXT} */,
          null,
          false
        ]
      ], __cfea6cad3c8fbb08f16c8c829b77b3f30f9eb9d5acf6e20a9ad78dce6f12ab13__[11]);
      let partIndex = 0;
      let nodeIndex = 0;
      let part;
      let node = __hook__('#()', walker, [
        'nextNode',
        []
      ], __cfea6cad3c8fbb08f16c8c829b77b3f30f9eb9d5acf6e20a9ad78dce6f12ab13__[13]);
      // Loop through all the nodes and parts of a template
      while (partIndex < __hook__('#.', parts, ['length'], __cfea6cad3c8fbb08f16c8c829b77b3f30f9eb9d5acf6e20a9ad78dce6f12ab13__[6])) {
        part = __hook__('#.', parts, [partIndex], __cfea6cad3c8fbb08f16c8c829b77b3f30f9eb9d5acf6e20a9ad78dce6f12ab13__[6]);
        if (!__hook__('m()', isTemplatePartActive, [
            __cfea6cad3c8fbb08f16c8c829b77b3f30f9eb9d5acf6e20a9ad78dce6f12ab13__[14],
            [part],
            (...args) => isTemplatePartActive(...args)
          ], __cfea6cad3c8fbb08f16c8c829b77b3f30f9eb9d5acf6e20a9ad78dce6f12ab13__[6], null)) {
          __hook__('#()', __hook__('#.', this, ['__parts'], __cfea6cad3c8fbb08f16c8c829b77b3f30f9eb9d5acf6e20a9ad78dce6f12ab13__[6]), [
            'push',
            [$hook$.global(__hook__, __cfea6cad3c8fbb08f16c8c829b77b3f30f9eb9d5acf6e20a9ad78dce6f12ab13__[6], 'undefined', '#get')[__cfea6cad3c8fbb08f16c8c829b77b3f30f9eb9d5acf6e20a9ad78dce6f12ab13__[15]]]
          ], __cfea6cad3c8fbb08f16c8c829b77b3f30f9eb9d5acf6e20a9ad78dce6f12ab13__[6]);
          partIndex++;
          continue;
        }
        // Progress the tree walker until we find our next part's node.
        // Note that multiple parts may share the same node (attribute parts
        // on a single element), so this loop may not run at all.
        while (nodeIndex < __hook__('#.', part, ['index'], __cfea6cad3c8fbb08f16c8c829b77b3f30f9eb9d5acf6e20a9ad78dce6f12ab13__[6])) {
          nodeIndex++;
          if (__hook__('#.', node, ['nodeName'], __cfea6cad3c8fbb08f16c8c829b77b3f30f9eb9d5acf6e20a9ad78dce6f12ab13__[6]) === 'TEMPLATE') {
            __hook__('#()', stack, [
              'push',
              [node]
            ], __cfea6cad3c8fbb08f16c8c829b77b3f30f9eb9d5acf6e20a9ad78dce6f12ab13__[6]);
            __hook__('#=', walker, [
              'currentNode',
              __hook__('#.', node, ['content'], __cfea6cad3c8fbb08f16c8c829b77b3f30f9eb9d5acf6e20a9ad78dce6f12ab13__[6])
            ], __cfea6cad3c8fbb08f16c8c829b77b3f30f9eb9d5acf6e20a9ad78dce6f12ab13__[6]);
          }
          if ((node = __hook__('#()', walker, [
              'nextNode',
              []
            ], __cfea6cad3c8fbb08f16c8c829b77b3f30f9eb9d5acf6e20a9ad78dce6f12ab13__[6])) === null) {
            // We've exhausted the content inside a nested template element.
            // Because we still have parts (the outer for-loop), we know:
            // - There is a template in the stack
            // - The walker will find a nextNode outside the template
            __hook__('#=', walker, [
              'currentNode',
              __hook__('#()', stack, [
                'pop',
                []
              ], __cfea6cad3c8fbb08f16c8c829b77b3f30f9eb9d5acf6e20a9ad78dce6f12ab13__[6])
            ], __cfea6cad3c8fbb08f16c8c829b77b3f30f9eb9d5acf6e20a9ad78dce6f12ab13__[6]);
            node = __hook__('#()', walker, [
              'nextNode',
              []
            ], __cfea6cad3c8fbb08f16c8c829b77b3f30f9eb9d5acf6e20a9ad78dce6f12ab13__[6]);
          }
        }
        // We've arrived at our part's node.
        if (__hook__('#.', part, ['type'], __cfea6cad3c8fbb08f16c8c829b77b3f30f9eb9d5acf6e20a9ad78dce6f12ab13__[6]) === 'node') {
          const part = __hook__('#()', __hook__('#.', this, ['processor'], __cfea6cad3c8fbb08f16c8c829b77b3f30f9eb9d5acf6e20a9ad78dce6f12ab13__[16]), [
            'handleTextExpression',
            [__hook__('#.', this, ['options'], __cfea6cad3c8fbb08f16c8c829b77b3f30f9eb9d5acf6e20a9ad78dce6f12ab13__[16])]
          ], __cfea6cad3c8fbb08f16c8c829b77b3f30f9eb9d5acf6e20a9ad78dce6f12ab13__[16]);
          __hook__('#()', part, [
            'insertAfterNode',
            [__hook__('#.', node, ['previousSibling'], __cfea6cad3c8fbb08f16c8c829b77b3f30f9eb9d5acf6e20a9ad78dce6f12ab13__[6])]
          ], __cfea6cad3c8fbb08f16c8c829b77b3f30f9eb9d5acf6e20a9ad78dce6f12ab13__[6]);
          __hook__('#()', __hook__('#.', this, ['__parts'], __cfea6cad3c8fbb08f16c8c829b77b3f30f9eb9d5acf6e20a9ad78dce6f12ab13__[6]), [
            'push',
            [part]
          ], __cfea6cad3c8fbb08f16c8c829b77b3f30f9eb9d5acf6e20a9ad78dce6f12ab13__[6]);
        } else {
          __hook__('#()', __hook__('#.', this, ['__parts'], __cfea6cad3c8fbb08f16c8c829b77b3f30f9eb9d5acf6e20a9ad78dce6f12ab13__[6]), [
            'push',
            [...__hook__('#()', __hook__('#.', this, ['processor'], __cfea6cad3c8fbb08f16c8c829b77b3f30f9eb9d5acf6e20a9ad78dce6f12ab13__[6]), [
                'handleAttributeExpressions',
                [
                  node,
                  __hook__('#.', part, ['name'], __cfea6cad3c8fbb08f16c8c829b77b3f30f9eb9d5acf6e20a9ad78dce6f12ab13__[6]),
                  __hook__('#.', part, ['strings'], __cfea6cad3c8fbb08f16c8c829b77b3f30f9eb9d5acf6e20a9ad78dce6f12ab13__[6]),
                  __hook__('#.', this, ['options'], __cfea6cad3c8fbb08f16c8c829b77b3f30f9eb9d5acf6e20a9ad78dce6f12ab13__[6])
                ]
              ], __cfea6cad3c8fbb08f16c8c829b77b3f30f9eb9d5acf6e20a9ad78dce6f12ab13__[6])]
          ], __cfea6cad3c8fbb08f16c8c829b77b3f30f9eb9d5acf6e20a9ad78dce6f12ab13__[6]);
        }
        partIndex++;
      }
      if (__hook__('m', isCEPolyfill, [__cfea6cad3c8fbb08f16c8c829b77b3f30f9eb9d5acf6e20a9ad78dce6f12ab13__[8]], __cfea6cad3c8fbb08f16c8c829b77b3f30f9eb9d5acf6e20a9ad78dce6f12ab13__[6], null)) {
        __hook__('#()', $hook$.global(__hook__, __cfea6cad3c8fbb08f16c8c829b77b3f30f9eb9d5acf6e20a9ad78dce6f12ab13__[6], 'document', '#get')[__cfea6cad3c8fbb08f16c8c829b77b3f30f9eb9d5acf6e20a9ad78dce6f12ab13__[17]], [
          'adoptNode',
          [fragment]
        ], __cfea6cad3c8fbb08f16c8c829b77b3f30f9eb9d5acf6e20a9ad78dce6f12ab13__[6]);
        __hook__('#()', $hook$.global(__hook__, __cfea6cad3c8fbb08f16c8c829b77b3f30f9eb9d5acf6e20a9ad78dce6f12ab13__[6], 'customElements', '#get')[__cfea6cad3c8fbb08f16c8c829b77b3f30f9eb9d5acf6e20a9ad78dce6f12ab13__[18]], [
          'upgrade',
          [fragment]
        ], __cfea6cad3c8fbb08f16c8c829b77b3f30f9eb9d5acf6e20a9ad78dce6f12ab13__[6]);
      }
      return fragment;
    }, null, arguments, __cfea6cad3c8fbb08f16c8c829b77b3f30f9eb9d5acf6e20a9ad78dce6f12ab13__[6]);
  }
}  __hook__(() => {
}, null, [
  'export',
  __cfea6cad3c8fbb08f16c8c829b77b3f30f9eb9d5acf6e20a9ad78dce6f12ab13__[0],
  __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__module_namespace_5
], __cfea6cad3c8fbb08f16c8c829b77b3f30f9eb9d5acf6e20a9ad78dce6f12ab13__[0], NaN);

/**
 * @license
 * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
 * This code may only be used under the BSD style license found at
 * http://polymer.github.io/LICENSE.txt
 * The complete set of authors may be found at
 * http://polymer.github.io/AUTHORS.txt
 * The complete set of contributors may be found at
 * http://polymer.github.io/CONTRIBUTORS.txt
 * Code distributed by Google as part of the polymer project is also
 * subject to an additional IP rights grant found at
 * http://polymer.github.io/PATENTS.txt
 */
/**
 * @module lit-html
 */
const __ea3baccd0673e8fe5ce7f46de397af00dc5480b4acdde9d96cb31345192e80d3__ = $hook$.$(__hook__, [
  '/components/thin-hook/demo/node_modules/lit-html/lib/template-result.js',
  '/components/thin-hook/demo/node_modules/lit-html/lib/dom.js',
  '/components/thin-hook/demo/node_modules/lit-html/lib/template.js',
  '/components/thin-hook/demo/node_modules/lit-html/lib/template-result.js,commentMarker',
  '/components/thin-hook/demo/node_modules/lit-html/lib/template.js,marker',
  '/components/thin-hook/demo/node_modules/lit-html/lib/template-result.js,TemplateResult,constructor',
  '/components/thin-hook/demo/node_modules/lit-html/lib/template-result.js,TemplateResult,getHTML',
  '/components/thin-hook/demo/node_modules/lit-html/lib/template-result.js,TemplateResult,getHTML,l',
  '/components/thin-hook/demo/node_modules/lit-html/lib/template-result.js,TemplateResult,getHTML,s',
  '/components/thin-hook/demo/node_modules/lit-html/lib/template-result.js,TemplateResult,getHTML,commentOpen',
  '/components/thin-hook/demo/node_modules/lit-html/lib/template-result.js,TemplateResult,getHTML,attributeMatch',
  '/components/thin-hook/demo/node_modules/lit-html/lib/template.js,lastAttributeNameRegex',
  '/components/thin-hook/demo/node_modules/lit-html/lib/template.js,nodeMarker',
  '/components/thin-hook/demo/node_modules/lit-html/lib/template.js,boundAttributeSuffix',
  '/components/thin-hook/demo/node_modules/lit-html/lib/template-result.js,TemplateResult,getTemplateElement',
  '/components/thin-hook/demo/node_modules/lit-html/lib/template-result.js,TemplateResult,getTemplateElement,template',
  'S_uNpREdiC4aB1e_document;/components/thin-hook/demo/node_modules/lit-html/lib/template-result.js,TemplateResult,getTemplateElement,template',
  '/components/thin-hook/demo/node_modules/lit-html/lib/template-result.js,SVGTemplateResult',
  '/components/thin-hook/demo/node_modules/lit-html/lib/template-result.js,TemplateResult',
  '/components/thin-hook/demo/node_modules/lit-html/lib/template-result.js,SVGTemplateResult,getHTML',
  '/components/thin-hook/demo/node_modules/lit-html/lib/template-result.js,SVGTemplateResult,getTemplateElement',
  '/components/thin-hook/demo/node_modules/lit-html/lib/template-result.js,SVGTemplateResult,getTemplateElement,template',
  '/components/thin-hook/demo/node_modules/lit-html/lib/template-result.js,SVGTemplateResult,getTemplateElement,content',
  '/components/thin-hook/demo/node_modules/lit-html/lib/template-result.js,SVGTemplateResult,getTemplateElement,svgElement',
  '/components/thin-hook/demo/node_modules/lit-html/lib/dom.js,reparentNodes'
]);
__hook__(() => {
}, null, [
  'import',
  {
    [__ea3baccd0673e8fe5ce7f46de397af00dc5480b4acdde9d96cb31345192e80d3__[1]]: [
      __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__module_namespace_1,
      'reparentNodes'
    ],
    [__ea3baccd0673e8fe5ce7f46de397af00dc5480b4acdde9d96cb31345192e80d3__[2]]: [
      __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__module_namespace_6,
      'boundAttributeSuffix',
      'lastAttributeNameRegex',
      'marker',
      'nodeMarker'
    ]
  }
], __ea3baccd0673e8fe5ce7f46de397af00dc5480b4acdde9d96cb31345192e80d3__[0], NaN);
const commentMarker = ` ${ __hook__('m', marker, [__ea3baccd0673e8fe5ce7f46de397af00dc5480b4acdde9d96cb31345192e80d3__[4]], __ea3baccd0673e8fe5ce7f46de397af00dc5480b4acdde9d96cb31345192e80d3__[3], null) } `;
/**
 * The return type of `html`, which holds a Template and the values from
 * interpolated expressions.
 */
class TemplateResult {
  constructor(strings, values, type, processor) {
    return __hook__((strings, values, type, processor) => {
      __hook__('#=', this, [
        'strings',
        strings
      ], __ea3baccd0673e8fe5ce7f46de397af00dc5480b4acdde9d96cb31345192e80d3__[5]);
      __hook__('#=', this, [
        'values',
        values
      ], __ea3baccd0673e8fe5ce7f46de397af00dc5480b4acdde9d96cb31345192e80d3__[5]);
      __hook__('#=', this, [
        'type',
        type
      ], __ea3baccd0673e8fe5ce7f46de397af00dc5480b4acdde9d96cb31345192e80d3__[5]);
      __hook__('#=', this, [
        'processor',
        processor
      ], __ea3baccd0673e8fe5ce7f46de397af00dc5480b4acdde9d96cb31345192e80d3__[5]);
    }, null, arguments, __ea3baccd0673e8fe5ce7f46de397af00dc5480b4acdde9d96cb31345192e80d3__[5]);
  }
  /**
     * Returns a string of HTML used to create a `<template>` element.
     */
  getHTML() {
    return __hook__(() => {
      const l = __hook__('#.', __hook__('#.', this, ['strings'], __ea3baccd0673e8fe5ce7f46de397af00dc5480b4acdde9d96cb31345192e80d3__[7]), ['length'], __ea3baccd0673e8fe5ce7f46de397af00dc5480b4acdde9d96cb31345192e80d3__[7]) - 1;
      let html = '';
      let isCommentBinding = false;
      for (let i = 0; i < l; i++) {
        const s = __hook__('#.', __hook__('#.', this, ['strings'], __ea3baccd0673e8fe5ce7f46de397af00dc5480b4acdde9d96cb31345192e80d3__[8]), [i], __ea3baccd0673e8fe5ce7f46de397af00dc5480b4acdde9d96cb31345192e80d3__[8]);
        // For each binding we want to determine the kind of marker to insert
        // into the template source before it's parsed by the browser's HTML
        // parser. The marker type is based on whether the expression is in an
        // attribute, text, or comment position.
        //   * For node-position bindings we insert a comment with the marker
        //     sentinel as its text content, like <!--{{lit-guid}}-->.
        //   * For attribute bindings we insert just the marker sentinel for the
        //     first binding, so that we support unquoted attribute bindings.
        //     Subsequent bindings can use a comment marker because multi-binding
        //     attributes must be quoted.
        //   * For comment bindings we insert just the marker sentinel so we don't
        //     close the comment.
        //
        // The following code scans the template source, but is *not* an HTML
        // parser. We don't need to track the tree structure of the HTML, only
        // whether a binding is inside a comment, and if not, if it appears to be
        // the first binding in an attribute.
        const commentOpen = __hook__('#()', s, [
          'lastIndexOf',
          ['<!--']
        ], __ea3baccd0673e8fe5ce7f46de397af00dc5480b4acdde9d96cb31345192e80d3__[9]);
        // We're in comment position if we have a comment open with no following
        // comment close. Because <-- can appear in an attribute value there can
        // be false positives.
        isCommentBinding = (commentOpen > -1 || isCommentBinding) && __hook__('#()', s, [
          'indexOf',
          [
            '-->',
            commentOpen + 1
          ]
        ], __ea3baccd0673e8fe5ce7f46de397af00dc5480b4acdde9d96cb31345192e80d3__[6]) === -1;
        // Check to see if we have an attribute-like sequence preceding the
        // expression. This can match "name=value" like structures in text,
        // comments, and attribute values, so there can be false-positives.
        const attributeMatch = __hook__('#()', __hook__('m', lastAttributeNameRegex, [__ea3baccd0673e8fe5ce7f46de397af00dc5480b4acdde9d96cb31345192e80d3__[11]], __ea3baccd0673e8fe5ce7f46de397af00dc5480b4acdde9d96cb31345192e80d3__[10], null), [
          'exec',
          [s]
        ], __ea3baccd0673e8fe5ce7f46de397af00dc5480b4acdde9d96cb31345192e80d3__[10]);
        if (attributeMatch === null) {
          // We're only in this branch if we don't have a attribute-like
          // preceding sequence. For comments, this guards against unusual
          // attribute values like <div foo="<!--${'bar'}">. Cases like
          // <!-- foo=${'bar'}--> are handled correctly in the attribute branch
          // below.
          html += s + (isCommentBinding ? commentMarker : __hook__('m', nodeMarker, [__ea3baccd0673e8fe5ce7f46de397af00dc5480b4acdde9d96cb31345192e80d3__[12]], __ea3baccd0673e8fe5ce7f46de397af00dc5480b4acdde9d96cb31345192e80d3__[6], null));
        } else {
          // For attributes we use just a marker sentinel, and also append a
          // $lit$ suffix to the name to opt-out of attribute-specific parsing
          // that IE and Edge do for style and certain SVG attributes.
          html += __hook__('#()', s, [
            'substr',
            [
              0,
              __hook__('#.', attributeMatch, ['index'], __ea3baccd0673e8fe5ce7f46de397af00dc5480b4acdde9d96cb31345192e80d3__[6])
            ]
          ], __ea3baccd0673e8fe5ce7f46de397af00dc5480b4acdde9d96cb31345192e80d3__[6]) + __hook__('#.', attributeMatch, [1], __ea3baccd0673e8fe5ce7f46de397af00dc5480b4acdde9d96cb31345192e80d3__[6]) + __hook__('#.', attributeMatch, [2], __ea3baccd0673e8fe5ce7f46de397af00dc5480b4acdde9d96cb31345192e80d3__[6]) + __hook__('m', boundAttributeSuffix, [__ea3baccd0673e8fe5ce7f46de397af00dc5480b4acdde9d96cb31345192e80d3__[13]], __ea3baccd0673e8fe5ce7f46de397af00dc5480b4acdde9d96cb31345192e80d3__[6], null) + __hook__('#.', attributeMatch, [3], __ea3baccd0673e8fe5ce7f46de397af00dc5480b4acdde9d96cb31345192e80d3__[6]) + __hook__('m', marker, [__ea3baccd0673e8fe5ce7f46de397af00dc5480b4acdde9d96cb31345192e80d3__[4]], __ea3baccd0673e8fe5ce7f46de397af00dc5480b4acdde9d96cb31345192e80d3__[6], null);
        }
      }
      html += __hook__('#.', __hook__('#.', this, ['strings'], __ea3baccd0673e8fe5ce7f46de397af00dc5480b4acdde9d96cb31345192e80d3__[6]), [l], __ea3baccd0673e8fe5ce7f46de397af00dc5480b4acdde9d96cb31345192e80d3__[6]);
      return html;
    }, null, arguments, __ea3baccd0673e8fe5ce7f46de397af00dc5480b4acdde9d96cb31345192e80d3__[6]);
  }
  getTemplateElement() {
    return __hook__(() => {
      const template = __hook__('#()', $hook$.global(__hook__, __ea3baccd0673e8fe5ce7f46de397af00dc5480b4acdde9d96cb31345192e80d3__[15], 'document', '#get')[__ea3baccd0673e8fe5ce7f46de397af00dc5480b4acdde9d96cb31345192e80d3__[16]], [
        'createElement',
        ['template']
      ], __ea3baccd0673e8fe5ce7f46de397af00dc5480b4acdde9d96cb31345192e80d3__[15]);
      __hook__('#=', template, [
        'innerHTML',
        __hook__('#()', this, [
          'getHTML',
          []
        ], __ea3baccd0673e8fe5ce7f46de397af00dc5480b4acdde9d96cb31345192e80d3__[14])
      ], __ea3baccd0673e8fe5ce7f46de397af00dc5480b4acdde9d96cb31345192e80d3__[14]);
      return template;
    }, null, arguments, __ea3baccd0673e8fe5ce7f46de397af00dc5480b4acdde9d96cb31345192e80d3__[14]);
  }
}
/**
 * A TemplateResult for SVG fragments.
 *
 * This class wraps HTML in an `<svg>` tag in order to parse its contents in the
 * SVG namespace, then modifies the template to remove the `<svg>` tag so that
 * clones only container the original fragment.
 */
class SVGTemplateResult extends __hook__('m', TemplateResult, [__ea3baccd0673e8fe5ce7f46de397af00dc5480b4acdde9d96cb31345192e80d3__[18]], __ea3baccd0673e8fe5ce7f46de397af00dc5480b4acdde9d96cb31345192e80d3__[17], null) {
  getHTML() {
    return __hook__(() => {
      return `<svg>${ __hook__('s()', this, [
        'getHTML',
        [],
        p => super[p]
      ], __ea3baccd0673e8fe5ce7f46de397af00dc5480b4acdde9d96cb31345192e80d3__[19]) }</svg>`;
    }, null, arguments, __ea3baccd0673e8fe5ce7f46de397af00dc5480b4acdde9d96cb31345192e80d3__[19]);
  }
  getTemplateElement() {
    return __hook__(() => {
      const template = __hook__('s()', this, [
        'getTemplateElement',
        [],
        p => super[p]
      ], __ea3baccd0673e8fe5ce7f46de397af00dc5480b4acdde9d96cb31345192e80d3__[21]);
      const content = __hook__('#.', template, ['content'], __ea3baccd0673e8fe5ce7f46de397af00dc5480b4acdde9d96cb31345192e80d3__[22]);
      const svgElement = __hook__('#.', content, ['firstChild'], __ea3baccd0673e8fe5ce7f46de397af00dc5480b4acdde9d96cb31345192e80d3__[23]);
      __hook__('#()', content, [
        'removeChild',
        [svgElement]
      ], __ea3baccd0673e8fe5ce7f46de397af00dc5480b4acdde9d96cb31345192e80d3__[20]);
      __hook__('m()', reparentNodes, [
        __ea3baccd0673e8fe5ce7f46de397af00dc5480b4acdde9d96cb31345192e80d3__[24],
        [
          content,
          __hook__('#.', svgElement, ['firstChild'], __ea3baccd0673e8fe5ce7f46de397af00dc5480b4acdde9d96cb31345192e80d3__[20])
        ],
        (...args) => reparentNodes(...args)
      ], __ea3baccd0673e8fe5ce7f46de397af00dc5480b4acdde9d96cb31345192e80d3__[20], null);
      return template;
    }, null, arguments, __ea3baccd0673e8fe5ce7f46de397af00dc5480b4acdde9d96cb31345192e80d3__[20]);
  }
}  __hook__(() => {
}, null, [
  'export',
  __ea3baccd0673e8fe5ce7f46de397af00dc5480b4acdde9d96cb31345192e80d3__[0],
  __045213766b0e56a0c3f2db9279bb9770e31ccd73fa3bc118b7423459ba0ec60e__module_namespace_2
], __ea3baccd0673e8fe5ce7f46de397af00dc5480b4acdde9d96cb31345192e80d3__[0], NaN);

/**
 * @license
 * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
 * This code may only be used under the BSD style license found at
 * http://polymer.github.io/LICENSE.txt
 * The complete set of authors may be found at
 * http://polymer.github.io/AUTHORS.txt
 * The complete set of contributors may be found at
 * http://polymer.github.io/CONTRIBUTORS.txt
 * Code distributed by Google as part of the polymer project is also
 * subject to an additional IP rights grant found at
 * http://polymer.github.io/PATENTS.txt
 */
/**
 * @module lit-html
 */
const __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__ = $hook$.$(__hook__, [
  '/components/thin-hook/demo/node_modules/lit-html/lib/parts.js',
  '/components/thin-hook/demo/node_modules/lit-html/lib/directive.js',
  '/components/thin-hook/demo/node_modules/lit-html/lib/dom.js',
  '/components/thin-hook/demo/node_modules/lit-html/lib/part.js',
  '/components/thin-hook/demo/node_modules/lit-html/lib/template-instance.js',
  '/components/thin-hook/demo/node_modules/lit-html/lib/template-result.js',
  '/components/thin-hook/demo/node_modules/lit-html/lib/template.js',
  '/components/thin-hook/demo/node_modules/lit-html/lib/parts.js,isPrimitive',
  '/components/thin-hook/demo/node_modules/lit-html/lib/parts.js,isIterable',
  'S_uNpREdiC4aB1e_Array;/components/thin-hook/demo/node_modules/lit-html/lib/parts.js,isIterable',
  'S_uNpREdiC4aB1e_Symbol;/components/thin-hook/demo/node_modules/lit-html/lib/parts.js,isIterable',
  '/components/thin-hook/demo/node_modules/lit-html/lib/parts.js,AttributeCommitter,constructor',
  '/components/thin-hook/demo/node_modules/lit-html/lib/parts.js,AttributeCommitter,_createPart',
  '/components/thin-hook/demo/node_modules/lit-html/lib/parts.js,AttributePart',
  '/components/thin-hook/demo/node_modules/lit-html/lib/parts.js,AttributeCommitter,_getValue',
  '/components/thin-hook/demo/node_modules/lit-html/lib/parts.js,AttributeCommitter,_getValue,strings',
  '/components/thin-hook/demo/node_modules/lit-html/lib/parts.js,AttributeCommitter,_getValue,l',
  '/components/thin-hook/demo/node_modules/lit-html/lib/parts.js,AttributeCommitter,_getValue,part',
  'S_uNpREdiC4aB1e_undefined;/components/thin-hook/demo/node_modules/lit-html/lib/parts.js,AttributeCommitter,_getValue',
  '/components/thin-hook/demo/node_modules/lit-html/lib/parts.js,AttributeCommitter,_getValue,v',
  'S_uNpREdiC4aB1e_String;/components/thin-hook/demo/node_modules/lit-html/lib/parts.js,AttributeCommitter,_getValue',
  '/components/thin-hook/demo/node_modules/lit-html/lib/parts.js,AttributeCommitter,commit',
  '/components/thin-hook/demo/node_modules/lit-html/lib/parts.js,AttributePart,constructor',
  'S_uNpREdiC4aB1e_undefined;/components/thin-hook/demo/node_modules/lit-html/lib/parts.js,AttributePart,constructor',
  '/components/thin-hook/demo/node_modules/lit-html/lib/parts.js,AttributePart,setValue',
  '/components/thin-hook/demo/node_modules/lit-html/lib/part.js,noChange',
  '/components/thin-hook/demo/node_modules/lit-html/lib/directive.js,isDirective',
  '/components/thin-hook/demo/node_modules/lit-html/lib/parts.js,AttributePart,commit',
  '/components/thin-hook/demo/node_modules/lit-html/lib/parts.js,AttributePart,commit,directive',
  '/components/thin-hook/demo/node_modules/lit-html/lib/parts.js,NodePart,constructor',
  'S_uNpREdiC4aB1e_undefined;/components/thin-hook/demo/node_modules/lit-html/lib/parts.js,NodePart,constructor',
  '/components/thin-hook/demo/node_modules/lit-html/lib/parts.js,NodePart,appendInto',
  '/components/thin-hook/demo/node_modules/lit-html/lib/template.js,createMarker',
  '/components/thin-hook/demo/node_modules/lit-html/lib/parts.js,NodePart,insertAfterNode',
  '/components/thin-hook/demo/node_modules/lit-html/lib/parts.js,NodePart,appendIntoPart',
  '/components/thin-hook/demo/node_modules/lit-html/lib/parts.js,NodePart,insertAfterPart',
  '/components/thin-hook/demo/node_modules/lit-html/lib/parts.js,NodePart,setValue',
  '/components/thin-hook/demo/node_modules/lit-html/lib/parts.js,NodePart,commit',
  '/components/thin-hook/demo/node_modules/lit-html/lib/parts.js,NodePart,commit,directive',
  '/components/thin-hook/demo/node_modules/lit-html/lib/parts.js,NodePart,commit,value',
  '/components/thin-hook/demo/node_modules/lit-html/lib/template-result.js,TemplateResult',
  'S_uNpREdiC4aB1e_Node;/components/thin-hook/demo/node_modules/lit-html/lib/parts.js,NodePart,commit',
  '/components/thin-hook/demo/node_modules/lit-html/lib/part.js,nothing',
  '/components/thin-hook/demo/node_modules/lit-html/lib/parts.js,NodePart,__insert',
  '/components/thin-hook/demo/node_modules/lit-html/lib/parts.js,NodePart,__commitNode',
  '/components/thin-hook/demo/node_modules/lit-html/lib/parts.js,NodePart,__commitText',
  '/components/thin-hook/demo/node_modules/lit-html/lib/parts.js,NodePart,__commitText,node',
  '/components/thin-hook/demo/node_modules/lit-html/lib/parts.js,NodePart,__commitText,valueAsString',
  'S_uNpREdiC4aB1e_String;/components/thin-hook/demo/node_modules/lit-html/lib/parts.js,NodePart,__commitText,valueAsString',
  'S_uNpREdiC4aB1e_document;/components/thin-hook/demo/node_modules/lit-html/lib/parts.js,NodePart,__commitText',
  '/components/thin-hook/demo/node_modules/lit-html/lib/parts.js,NodePart,__commitTemplateResult',
  '/components/thin-hook/demo/node_modules/lit-html/lib/parts.js,NodePart,__commitTemplateResult,template',
  '/components/thin-hook/demo/node_modules/lit-html/lib/template-instance.js,TemplateInstance',
  '/components/thin-hook/demo/node_modules/lit-html/lib/parts.js,NodePart,__commitTemplateResult,instance',
  '/components/thin-hook/demo/node_modules/lit-html/lib/parts.js,NodePart,__commitTemplateResult,fragment',
  '/components/thin-hook/demo/node_modules/lit-html/lib/parts.js,NodePart,__commitIterable',
  'S_uNpREdiC4aB1e_Array;/components/thin-hook/demo/node_modules/lit-html/lib/parts.js,NodePart,__commitIterable',
  '/components/thin-hook/demo/node_modules/lit-html/lib/parts.js,NodePart,__commitIterable,itemParts',
  'S_uNpREdiC4aB1e_undefined;/components/thin-hook/demo/node_modules/lit-html/lib/parts.js,NodePart,__commitIterable',
  '/components/thin-hook/demo/node_modules/lit-html/lib/parts.js,NodePart',
  '/components/thin-hook/demo/node_modules/lit-html/lib/parts.js,NodePart,clear',
  '/components/thin-hook/demo/node_modules/lit-html/lib/dom.js,removeNodes',
  '/components/thin-hook/demo/node_modules/lit-html/lib/parts.js,BooleanAttributePart,constructor',
  'S_uNpREdiC4aB1e_undefined;/components/thin-hook/demo/node_modules/lit-html/lib/parts.js,BooleanAttributePart,constructor',
  'S_uNpREdiC4aB1e_Error;/components/thin-hook/demo/node_modules/lit-html/lib/parts.js,BooleanAttributePart,constructor',
  '/components/thin-hook/demo/node_modules/lit-html/lib/parts.js,BooleanAttributePart,setValue',
  '/components/thin-hook/demo/node_modules/lit-html/lib/parts.js,BooleanAttributePart,commit',
  '/components/thin-hook/demo/node_modules/lit-html/lib/parts.js,BooleanAttributePart,commit,directive',
  '/components/thin-hook/demo/node_modules/lit-html/lib/parts.js,BooleanAttributePart,commit,value',
  '/components/thin-hook/demo/node_modules/lit-html/lib/parts.js,PropertyCommitter',
  '/components/thin-hook/demo/node_modules/lit-html/lib/parts.js,AttributeCommitter',
  '/components/thin-hook/demo/node_modules/lit-html/lib/parts.js,PropertyCommitter,constructor',
  '/components/thin-hook/demo/node_modules/lit-html/lib/parts.js,PropertyCommitter,_createPart',
  '/components/thin-hook/demo/node_modules/lit-html/lib/parts.js,PropertyPart',
  '/components/thin-hook/demo/node_modules/lit-html/lib/parts.js,PropertyCommitter,_getValue',
  '/components/thin-hook/demo/node_modules/lit-html/lib/parts.js,PropertyCommitter,commit',
  '/components/thin-hook/demo/node_modules/lit-html/lib/parts.js,options,get capture',
  'S_uNpREdiC4aB1e_window;/components/thin-hook/demo/node_modules/lit-html/lib/parts.js',
  '/components/thin-hook/demo/node_modules/lit-html/lib/parts.js,EventPart,constructor',
  'S_uNpREdiC4aB1e_undefined;/components/thin-hook/demo/node_modules/lit-html/lib/parts.js,EventPart,constructor',
  '/components/thin-hook/demo/node_modules/lit-html/lib/parts.js,EventPart,setValue',
  '/components/thin-hook/demo/node_modules/lit-html/lib/parts.js,EventPart,commit',
  '/components/thin-hook/demo/node_modules/lit-html/lib/parts.js,EventPart,commit,directive',
  '/components/thin-hook/demo/node_modules/lit-html/lib/parts.js,EventPart,commit,newListener',
  '/components/thin-hook/demo/node_modules/lit-html/lib/parts.js,EventPart,commit,oldListener',
  '/components/thin-hook/demo/node_modules/lit-html/lib/parts.js,EventPart,commit,shouldRemoveListener',
  '/components/thin-hook/demo/node_modules/lit-html/lib/parts.js,EventPart,handleEvent',
  '/components/thin-hook/demo/node_modules/lit-html/lib/parts.js,getOptions',
  '/components/thin-hook/demo/node_modules/lit-html/lib/parts.js,getOptions,capture',
  '/components/thin-hook/demo/node_modules/lit-html/lib/parts.js,getOptions,passive',
  '/components/thin-hook/demo/node_modules/lit-html/lib/parts.js,getOptions,once'
]);
__hook__(() => {
}, null, [
  'import',
  {
    [__519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[1]]: [
      __045213766b0e56a0c3f2db9279bb9770e31ccd73fa3bc118b7423459ba0ec60e__module_namespace_3,
      'isDirective'
    ],
    [__519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[2]]: [
      __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__module_namespace_1,
      'removeNodes'
    ],
    [__519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[3]]: [
      __045213766b0e56a0c3f2db9279bb9770e31ccd73fa3bc118b7423459ba0ec60e__module_namespace_5,
      'noChange',
      'nothing'
    ],
    [__519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[4]]: [
      __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__module_namespace_5,
      'TemplateInstance'
    ],
    [__519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[5]]: [
      __045213766b0e56a0c3f2db9279bb9770e31ccd73fa3bc118b7423459ba0ec60e__module_namespace_2,
      'TemplateResult'
    ],
    [__519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[6]]: [
      __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__module_namespace_6,
      'createMarker'
    ]
  }
], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[0], NaN);
const isPrimitive = (...args) =>
  (__hook__(value => {
    return value === null || !(typeof value === 'object' || typeof value === 'function');
  }, null, args, __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[7]));
const isIterable = (...args) =>
  (__hook__(value => {
    return __hook__('#()', $hook$.global(__hook__, __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[8], 'Array', '#get')[__519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[9]], [
      'isArray',
      [value]
    ], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[8]) || // eslint-disable-next-line @typescript-eslint/no-explicit-any
    !!(value && __hook__('#.', value, [__hook__('#.', $hook$.global(__hook__, __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[8], 'Symbol', '#get')[__519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[10]], ['iterator'], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[8])], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[8]));
  }, null, args, __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[8]));
/**
 * Writes attribute values to the DOM for a group of AttributeParts bound to a
 * single attribute. The value is only set once even if there are multiple parts
 * for an attribute.
 */
class AttributeCommitter {
  constructor(element, name, strings) {
    return __hook__((element, name, strings) => {
      __hook__('#=', this, [
        'dirty',
        true
      ], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[11]);
      __hook__('#=', this, [
        'element',
        element
      ], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[11]);
      __hook__('#=', this, [
        'name',
        name
      ], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[11]);
      __hook__('#=', this, [
        'strings',
        strings
      ], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[11]);
      __hook__('#=', this, [
        'parts',
        []
      ], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[11]);
      for (let i = 0; i < __hook__('#.', strings, ['length'], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[11]) - 1; i++) {
        __hook__('#=', __hook__('#.', this, ['parts'], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[11]), [
          i,
          __hook__('#()', this, [
            '_createPart',
            []
          ], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[11])
        ], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[11]);
      }
    }, null, arguments, __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[11]);
  }
  /**
     * Creates a single part. Override this to create a differnt type of part.
     */
  _createPart() {
    return __hook__(() => {
      return __hook__('mnew', AttributePart, [
        __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[13],
        [this],
        (...args) => new AttributePart(...args)
      ], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[12], null);
    }, null, arguments, __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[12]);
  }
  _getValue() {
    return __hook__(() => {
      const strings = __hook__('#.', this, ['strings'], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[15]);
      const l = __hook__('#.', strings, ['length'], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[16]) - 1;
      let text = '';
      for (let i = 0; i < l; i++) {
        text += __hook__('#.', strings, [i], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[14]);
        const part = __hook__('#.', __hook__('#.', this, ['parts'], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[17]), [i], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[17]);
        if (part !== $hook$.global(__hook__, __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[14], 'undefined', '#get')[__519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[18]]) {
          const v = __hook__('#.', part, ['value'], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[19]);
          if (__hook__('m()', isPrimitive, [
              __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[7],
              [v],
              (...args) => isPrimitive(...args)
            ], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[14], null) || !__hook__('m()', isIterable, [
              __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[8],
              [v],
              (...args) => isIterable(...args)
            ], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[14], null)) {
            text += typeof v === 'string' ? v : __hook__($hook$.global(__hook__, __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[14], 'String', '#get')[__519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[20]], null, [v], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[14], 0);
          } else {
            for (const t of __hook__('#*', v, [], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[14])) {
              text += typeof t === 'string' ? t : __hook__($hook$.global(__hook__, __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[14], 'String', '#get')[__519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[20]], null, [t], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[14], 0);
            }
          }
        }
      }
      text += __hook__('#.', strings, [l], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[14]);
      return text;
    }, null, arguments, __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[14]);
  }
  commit() {
    return __hook__(() => {
      if (__hook__('#.', this, ['dirty'], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[21])) {
        __hook__('#=', this, [
          'dirty',
          false
        ], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[21]);
        __hook__('#()', __hook__('#.', this, ['element'], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[21]), [
          'setAttribute',
          [
            __hook__('#.', this, ['name'], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[21]),
            __hook__('#()', this, [
              '_getValue',
              []
            ], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[21])
          ]
        ], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[21]);
      }
    }, null, arguments, __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[21]);
  }
}
/**
 * A Part that controls all or part of an attribute value.
 */
class AttributePart {
  constructor(committer) {
    return __hook__(committer => {
      __hook__('#=', this, [
        'value',
        $hook$.global(__hook__, __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[22], 'undefined', '#get')[__519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[23]]
      ], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[22]);
      __hook__('#=', this, [
        'committer',
        committer
      ], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[22]);
    }, null, arguments, __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[22]);
  }
  setValue(value) {
    return __hook__(value => {
      if (value !== __hook__('m', noChange, [__519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[25]], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[24], null) && (!__hook__('m()', isPrimitive, [
          __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[7],
          [value],
          (...args) => isPrimitive(...args)
        ], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[24], null) || value !== __hook__('#.', this, ['value'], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[24]))) {
        __hook__('#=', this, [
          'value',
          value
        ], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[24]);
        // If the value is a not a directive, dirty the committer so that it'll
        // call setAttribute. If the value is a directive, it'll dirty the
        // committer if it calls setValue().
        if (!__hook__('m()', isDirective, [
            __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[26],
            [value],
            (...args) => isDirective(...args)
          ], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[24], null)) {
          __hook__('#=', __hook__('#.', this, ['committer'], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[24]), [
            'dirty',
            true
          ], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[24]);
        }
      }
    }, null, arguments, __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[24]);
  }
  commit() {
    return __hook__(() => {
      while (__hook__('m()', isDirective, [
          __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[26],
          [__hook__('#.', this, ['value'], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[27])],
          (...args) => isDirective(...args)
        ], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[27], null)) {
        const directive = __hook__('#.', this, ['value'], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[28]);
        __hook__('#=', this, [
          'value',
          __hook__('m', noChange, [__519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[25]], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[27], null)
        ], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[27]);
        __hook__(directive, null, [this], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[27], 0);
      }
      if (__hook__('#.', this, ['value'], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[27]) === __hook__('m', noChange, [__519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[25]], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[27], null)) {
        return;
      }
      __hook__('#()', __hook__('#.', this, ['committer'], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[27]), [
        'commit',
        []
      ], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[27]);
    }, null, arguments, __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[27]);
  }
}
/**
 * A Part that controls a location within a Node tree. Like a Range, NodePart
 * has start and end locations and can set and update the Nodes between those
 * locations.
 *
 * NodeParts support several value types: primitives, Nodes, TemplateResults,
 * as well as arrays and iterables of those types.
 */
class NodePart {
  constructor(options) {
    return __hook__(options => {
      __hook__('#=', this, [
        'value',
        $hook$.global(__hook__, __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[29], 'undefined', '#get')[__519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[30]]
      ], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[29]);
      __hook__('#=', this, [
        '__pendingValue',
        $hook$.global(__hook__, __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[29], 'undefined', '#get')[__519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[30]]
      ], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[29]);
      __hook__('#=', this, [
        'options',
        options
      ], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[29]);
    }, null, arguments, __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[29]);
  }
  /**
     * Appends this part into a container.
     *
     * This part must be empty, as its contents are not automatically moved.
     */
  appendInto(container) {
    return __hook__(container => {
      __hook__('#=', this, [
        'startNode',
        __hook__('#()', container, [
          'appendChild',
          [__hook__('m()', createMarker, [
              __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[32],
              [],
              (...args) => createMarker(...args)
            ], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[31], null)]
        ], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[31])
      ], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[31]);
      __hook__('#=', this, [
        'endNode',
        __hook__('#()', container, [
          'appendChild',
          [__hook__('m()', createMarker, [
              __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[32],
              [],
              (...args) => createMarker(...args)
            ], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[31], null)]
        ], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[31])
      ], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[31]);
    }, null, arguments, __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[31]);
  }
  /**
     * Inserts this part after the `ref` node (between `ref` and `ref`'s next
     * sibling). Both `ref` and its next sibling must be static, unchanging nodes
     * such as those that appear in a literal section of a template.
     *
     * This part must be empty, as its contents are not automatically moved.
     */
  insertAfterNode(ref) {
    return __hook__(ref => {
      __hook__('#=', this, [
        'startNode',
        ref
      ], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[33]);
      __hook__('#=', this, [
        'endNode',
        __hook__('#.', ref, ['nextSibling'], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[33])
      ], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[33]);
    }, null, arguments, __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[33]);
  }
  /**
     * Appends this part into a parent part.
     *
     * This part must be empty, as its contents are not automatically moved.
     */
  appendIntoPart(part) {
    return __hook__(part => {
      __hook__('#()', part, [
        '__insert',
        [__hook__('#=', this, [
            'startNode',
            __hook__('m()', createMarker, [
              __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[32],
              [],
              (...args) => createMarker(...args)
            ], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[34], null)
          ], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[34])]
      ], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[34]);
      __hook__('#()', part, [
        '__insert',
        [__hook__('#=', this, [
            'endNode',
            __hook__('m()', createMarker, [
              __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[32],
              [],
              (...args) => createMarker(...args)
            ], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[34], null)
          ], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[34])]
      ], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[34]);
    }, null, arguments, __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[34]);
  }
  /**
     * Inserts this part after the `ref` part.
     *
     * This part must be empty, as its contents are not automatically moved.
     */
  insertAfterPart(ref) {
    return __hook__(ref => {
      __hook__('#()', ref, [
        '__insert',
        [__hook__('#=', this, [
            'startNode',
            __hook__('m()', createMarker, [
              __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[32],
              [],
              (...args) => createMarker(...args)
            ], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[35], null)
          ], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[35])]
      ], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[35]);
      __hook__('#=', this, [
        'endNode',
        __hook__('#.', ref, ['endNode'], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[35])
      ], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[35]);
      __hook__('#=', ref, [
        'endNode',
        __hook__('#.', this, ['startNode'], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[35])
      ], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[35]);
    }, null, arguments, __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[35]);
  }
  setValue(value) {
    return __hook__(value => {
      __hook__('#=', this, [
        '__pendingValue',
        value
      ], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[36]);
    }, null, arguments, __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[36]);
  }
  commit() {
    return __hook__(() => {
      if (__hook__('#.', __hook__('#.', this, ['startNode'], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[37]), ['parentNode'], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[37]) === null) {
        return;
      }
      while (__hook__('m()', isDirective, [
          __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[26],
          [__hook__('#.', this, ['__pendingValue'], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[37])],
          (...args) => isDirective(...args)
        ], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[37], null)) {
        const directive = __hook__('#.', this, ['__pendingValue'], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[38]);
        __hook__('#=', this, [
          '__pendingValue',
          __hook__('m', noChange, [__519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[25]], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[37], null)
        ], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[37]);
        __hook__(directive, null, [this], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[37], 0);
      }
      const value = __hook__('#.', this, ['__pendingValue'], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[39]);
      if (value === __hook__('m', noChange, [__519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[25]], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[37], null)) {
        return;
      }
      if (__hook__('m()', isPrimitive, [
          __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[7],
          [value],
          (...args) => isPrimitive(...args)
        ], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[37], null)) {
        if (value !== __hook__('#.', this, ['value'], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[37])) {
          __hook__('#()', this, [
            '__commitText',
            [value]
          ], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[37]);
        }
      } else if (value instanceof __hook__('m', TemplateResult, [__519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[40]], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[37], null)) {
        __hook__('#()', this, [
          '__commitTemplateResult',
          [value]
        ], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[37]);
      } else if (value instanceof $hook$.global(__hook__, __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[37], 'Node', '#get')[__519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[41]]) {
        __hook__('#()', this, [
          '__commitNode',
          [value]
        ], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[37]);
      } else if (__hook__('m()', isIterable, [
          __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[8],
          [value],
          (...args) => isIterable(...args)
        ], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[37], null)) {
        __hook__('#()', this, [
          '__commitIterable',
          [value]
        ], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[37]);
      } else if (value === __hook__('m', nothing, [__519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[42]], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[37], null)) {
        __hook__('#=', this, [
          'value',
          __hook__('m', nothing, [__519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[42]], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[37], null)
        ], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[37]);
        __hook__('#()', this, [
          'clear',
          []
        ], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[37]);
      } else {
        // Fallback, will render the string representation
        __hook__('#()', this, [
          '__commitText',
          [value]
        ], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[37]);
      }
    }, null, arguments, __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[37]);
  }
  __insert(node) {
    return __hook__(node => {
      __hook__('#()', __hook__('#.', __hook__('#.', this, ['endNode'], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[43]), ['parentNode'], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[43]), [
        'insertBefore',
        [
          node,
          __hook__('#.', this, ['endNode'], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[43])
        ]
      ], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[43]);
    }, null, arguments, __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[43]);
  }
  __commitNode(value) {
    return __hook__(value => {
      if (__hook__('#.', this, ['value'], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[44]) === value) {
        return;
      }
      __hook__('#()', this, [
        'clear',
        []
      ], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[44]);
      __hook__('#()', this, [
        '__insert',
        [value]
      ], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[44]);
      __hook__('#=', this, [
        'value',
        value
      ], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[44]);
    }, null, arguments, __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[44]);
  }
  __commitText(value) {
    return __hook__(value => {
      const node = __hook__('#.', __hook__('#.', this, ['startNode'], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[46]), ['nextSibling'], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[46]);
      value = value == null ? '' : value;
      // If `value` isn't already a string, we explicitly convert it here in case
      // it can't be implicitly converted - i.e. it's a symbol.
      const valueAsString = typeof value === 'string' ? value : __hook__($hook$.global(__hook__, __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[47], 'String', '#get')[__519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[48]], null, [value], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[47], 0);
      if (node === __hook__('#.', __hook__('#.', this, ['endNode'], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[45]), ['previousSibling'], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[45]) && __hook__('#.', node, ['nodeType'], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[45]) === 3  /* Node.TEXT_NODE */) {
        // If we only have a single text node between the markers, we can just
        // set its value, rather than replacing it.
        // TODO(justinfagnani): Can we just check if this.value is primitive?
        __hook__('#=', node, [
          'data',
          valueAsString
        ], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[45]);
      } else {
        __hook__('#()', this, [
          '__commitNode',
          [__hook__('#()', $hook$.global(__hook__, __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[45], 'document', '#get')[__519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[49]], [
              'createTextNode',
              [valueAsString]
            ], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[45])]
        ], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[45]);
      }
      __hook__('#=', this, [
        'value',
        value
      ], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[45]);
    }, null, arguments, __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[45]);
  }
  __commitTemplateResult(value) {
    return __hook__(value => {
      const template = __hook__('#()', __hook__('#.', this, ['options'], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[51]), [
        'templateFactory',
        [value]
      ], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[51]);
      if (__hook__('#.', this, ['value'], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[50]) instanceof __hook__('m', TemplateInstance, [__519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[52]], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[50], null) && __hook__('#.', __hook__('#.', this, ['value'], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[50]), ['template'], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[50]) === template) {
        __hook__('#()', __hook__('#.', this, ['value'], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[50]), [
          'update',
          [__hook__('#.', value, ['values'], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[50])]
        ], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[50]);
      } else {
        // Make sure we propagate the template processor from the TemplateResult
        // so that we use its syntax extension, etc. The template factory comes
        // from the render function options so that it can control template
        // caching and preprocessing.
        const instance = __hook__('mnew', TemplateInstance, [
          __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[52],
          [
            template,
            __hook__('#.', value, ['processor'], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[53]),
            __hook__('#.', this, ['options'], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[53])
          ],
          (...args) => new TemplateInstance(...args)
        ], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[53], null);
        const fragment = __hook__('#()', instance, [
          '_clone',
          []
        ], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[54]);
        __hook__('#()', instance, [
          'update',
          [__hook__('#.', value, ['values'], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[50])]
        ], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[50]);
        __hook__('#()', this, [
          '__commitNode',
          [fragment]
        ], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[50]);
        __hook__('#=', this, [
          'value',
          instance
        ], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[50]);
      }
    }, null, arguments, __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[50]);
  }
  __commitIterable(value) {
    return __hook__(value => {
      // For an Iterable, we create a new InstancePart per item, then set its
      // value to the item. This is a little bit of overhead for every item in
      // an Iterable, but it lets us recurse easily and efficiently update Arrays
      // of TemplateResults that will be commonly returned from expressions like:
      // array.map((i) => html`${i}`), by reusing existing TemplateInstances.
      // If _value is an array, then the previous render was of an
      // iterable and _value will contain the NodeParts from the previous
      // render. If _value is not an array, clear this part and make a new
      // array for NodeParts.
      if (!__hook__('#()', $hook$.global(__hook__, __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[55], 'Array', '#get')[__519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[56]], [
          'isArray',
          [__hook__('#.', this, ['value'], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[55])]
        ], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[55])) {
        __hook__('#=', this, [
          'value',
          []
        ], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[55]);
        __hook__('#()', this, [
          'clear',
          []
        ], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[55]);
      }
      // Lets us keep track of how many items we stamped so we can clear leftover
      // items from a previous render
      const itemParts = __hook__('#.', this, ['value'], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[57]);
      let partIndex = 0;
      let itemPart;
      for (const item of __hook__('#*', value, [], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[55])) {
        // Try to reuse an existing part
        itemPart = __hook__('#.', itemParts, [partIndex], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[55]);
        // If no existing part, create a new one
        if (itemPart === $hook$.global(__hook__, __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[55], 'undefined', '#get')[__519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[58]]) {
          itemPart = __hook__('mnew', NodePart, [
            __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[59],
            [__hook__('#.', this, ['options'], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[55])],
            (...args) => new NodePart(...args)
          ], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[55], null);
          __hook__('#()', itemParts, [
            'push',
            [itemPart]
          ], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[55]);
          if (partIndex === 0) {
            __hook__('#()', itemPart, [
              'appendIntoPart',
              [this]
            ], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[55]);
          } else {
            __hook__('#()', itemPart, [
              'insertAfterPart',
              [__hook__('#.', itemParts, [partIndex - 1], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[55])]
            ], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[55]);
          }
        }
        __hook__('#()', itemPart, [
          'setValue',
          [item]
        ], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[55]);
        __hook__('#()', itemPart, [
          'commit',
          []
        ], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[55]);
        partIndex++;
      }
      if (partIndex < __hook__('#.', itemParts, ['length'], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[55])) {
        // Truncate the parts array so _value reflects the current state
        __hook__('#=', itemParts, [
          'length',
          partIndex
        ], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[55]);
        __hook__('#()', this, [
          'clear',
          [itemPart && __hook__('#.', itemPart, ['endNode'], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[55])]
        ], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[55]);
      }
    }, null, arguments, __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[55]);
  }
  clear(startNode) {
    return __hook__((startNode = __hook__('#.', this, ['startNode'], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[60])) => {
      __hook__('m()', removeNodes, [
        __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[61],
        [
          __hook__('#.', __hook__('#.', this, ['startNode'], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[60]), ['parentNode'], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[60]),
          __hook__('#.', startNode, ['nextSibling'], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[60]),
          __hook__('#.', this, ['endNode'], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[60])
        ],
        (...args) => removeNodes(...args)
      ], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[60], null);
    }, null, arguments, __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[60]);
  }
}
/**
 * Implements a boolean attribute, roughly as defined in the HTML
 * specification.
 *
 * If the value is truthy, then the attribute is present with a value of
 * ''. If the value is falsey, the attribute is removed.
 */
class BooleanAttributePart {
  constructor(element, name, strings) {
    return __hook__((element, name, strings) => {
      __hook__('#=', this, [
        'value',
        $hook$.global(__hook__, __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[62], 'undefined', '#get')[__519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[63]]
      ], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[62]);
      __hook__('#=', this, [
        '__pendingValue',
        $hook$.global(__hook__, __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[62], 'undefined', '#get')[__519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[63]]
      ], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[62]);
      if (__hook__('#.', strings, ['length'], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[62]) !== 2 || __hook__('#.', strings, [0], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[62]) !== '' || __hook__('#.', strings, [1], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[62]) !== '') {
        throw __hook__($hook$.global(__hook__, __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[62], 'Error', '#get')[__519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[64]], null, ['Boolean attributes can only contain a single expression'], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[62], true);
      }
      __hook__('#=', this, [
        'element',
        element
      ], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[62]);
      __hook__('#=', this, [
        'name',
        name
      ], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[62]);
      __hook__('#=', this, [
        'strings',
        strings
      ], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[62]);
    }, null, arguments, __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[62]);
  }
  setValue(value) {
    return __hook__(value => {
      __hook__('#=', this, [
        '__pendingValue',
        value
      ], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[65]);
    }, null, arguments, __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[65]);
  }
  commit() {
    return __hook__(() => {
      while (__hook__('m()', isDirective, [
          __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[26],
          [__hook__('#.', this, ['__pendingValue'], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[66])],
          (...args) => isDirective(...args)
        ], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[66], null)) {
        const directive = __hook__('#.', this, ['__pendingValue'], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[67]);
        __hook__('#=', this, [
          '__pendingValue',
          __hook__('m', noChange, [__519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[25]], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[66], null)
        ], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[66]);
        __hook__(directive, null, [this], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[66], 0);
      }
      if (__hook__('#.', this, ['__pendingValue'], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[66]) === __hook__('m', noChange, [__519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[25]], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[66], null)) {
        return;
      }
      const value = !!__hook__('#.', this, ['__pendingValue'], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[68]);
      if (__hook__('#.', this, ['value'], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[66]) !== value) {
        if (value) {
          __hook__('#()', __hook__('#.', this, ['element'], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[66]), [
            'setAttribute',
            [
              __hook__('#.', this, ['name'], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[66]),
              ''
            ]
          ], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[66]);
        } else {
          __hook__('#()', __hook__('#.', this, ['element'], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[66]), [
            'removeAttribute',
            [__hook__('#.', this, ['name'], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[66])]
          ], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[66]);
        }
        __hook__('#=', this, [
          'value',
          value
        ], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[66]);
      }
      __hook__('#=', this, [
        '__pendingValue',
        __hook__('m', noChange, [__519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[25]], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[66], null)
      ], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[66]);
    }, null, arguments, __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[66]);
  }
}
/**
 * Sets attribute values for PropertyParts, so that the value is only set once
 * even if there are multiple parts for a property.
 *
 * If an expression controls the whole property value, then the value is simply
 * assigned to the property under control. If there are string literals or
 * multiple expressions, then the strings are expressions are interpolated into
 * a string first.
 */
class PropertyCommitter extends __hook__('m', AttributeCommitter, [__519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[70]], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[69], null) {
  constructor(element, name, strings) {
    return __hook__((element, name, strings) => {
      __hook__((newTarget, ...args) => super(...args), null, [
        new.target,
        element,
        name,
        strings
      ], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[71], '');
      __hook__('#=', this, [
        'single',
        __hook__('#.', strings, ['length'], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[71]) === 2 && __hook__('#.', strings, [0], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[71]) === '' && __hook__('#.', strings, [1], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[71]) === ''
      ], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[71]);
    }, null, arguments, __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[71]);
  }
  _createPart() {
    return __hook__(() => {
      return __hook__('mnew', PropertyPart, [
        __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[73],
        [this],
        (...args) => new PropertyPart(...args)
      ], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[72], null);
    }, null, arguments, __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[72]);
  }
  _getValue() {
    return __hook__(() => {
      if (__hook__('#.', this, ['single'], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[74])) {
        return __hook__('#.', __hook__('#.', __hook__('#.', this, ['parts'], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[74]), [0], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[74]), ['value'], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[74]);
      }
      return __hook__('s()', this, [
        '_getValue',
        [],
        p => super[p]
      ], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[74]);
    }, null, arguments, __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[74]);
  }
  commit() {
    return __hook__(() => {
      if (__hook__('#.', this, ['dirty'], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[75])) {
        __hook__('#=', this, [
          'dirty',
          false
        ], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[75]);
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        __hook__('#=', __hook__('#.', this, ['element'], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[75]), [
          __hook__('#.', this, ['name'], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[75]),
          __hook__('#()', this, [
            '_getValue',
            []
          ], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[75])
        ], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[75]);
      }
    }, null, arguments, __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[75]);
  }
}
class PropertyPart extends __hook__('m', AttributePart, [__519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[13]], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[73], null) {
}
// Detect event listener options support. If the `capture` property is read
// from the options object, then options are supported. If not, then the third
// argument to add/removeEventListener is interpreted as the boolean capture
// value so we should only pass the `capture` property.
let eventOptionsSupported = false;
// Wrap into an IIFE because MS Edge <= v41 does not support having try/catch
// blocks right into the body of a module
__hook__((...args) =>
  (__hook__(() => {
    try {
      const options = {
        get capture() {
          return __hook__(() => {
            eventOptionsSupported = true;
            return false;
          }, null, arguments, __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[76]);
        }
      };
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      __hook__('#()', $hook$.global(__hook__, __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[0], 'window', '#get')[__519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[77]], [
        'addEventListener',
        [
          'test',
          options,
          options
        ]
      ], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[0]);
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      __hook__('#()', $hook$.global(__hook__, __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[0], 'window', '#get')[__519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[77]], [
        'removeEventListener',
        [
          'test',
          options,
          options
        ]
      ], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[0]);
    } catch (_e) {
    }
  }, null, args, __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[0])), null, [], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[0], 0);
class EventPart {
  constructor(element, eventName, eventContext) {
    return __hook__((element, eventName, eventContext) => {
      __hook__('#=', this, [
        'value',
        $hook$.global(__hook__, __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[78], 'undefined', '#get')[__519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[79]]
      ], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[78]);
      __hook__('#=', this, [
        '__pendingValue',
        $hook$.global(__hook__, __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[78], 'undefined', '#get')[__519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[79]]
      ], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[78]);
      __hook__('#=', this, [
        'element',
        element
      ], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[78]);
      __hook__('#=', this, [
        'eventName',
        eventName
      ], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[78]);
      __hook__('#=', this, [
        'eventContext',
        eventContext
      ], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[78]);
      __hook__('#=', this, [
        '__boundHandleEvent',
        (...args) => __hook__(e => __hook__('#()', this, [
          'handleEvent',
          [e]
        ], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[78]), null, args, __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[78])
      ], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[78]);
    }, null, arguments, __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[78]);
  }
  setValue(value) {
    return __hook__(value => {
      __hook__('#=', this, [
        '__pendingValue',
        value
      ], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[80]);
    }, null, arguments, __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[80]);
  }
  commit() {
    return __hook__(() => {
      while (__hook__('m()', isDirective, [
          __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[26],
          [__hook__('#.', this, ['__pendingValue'], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[81])],
          (...args) => isDirective(...args)
        ], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[81], null)) {
        const directive = __hook__('#.', this, ['__pendingValue'], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[82]);
        __hook__('#=', this, [
          '__pendingValue',
          __hook__('m', noChange, [__519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[25]], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[81], null)
        ], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[81]);
        __hook__(directive, null, [this], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[81], 0);
      }
      if (__hook__('#.', this, ['__pendingValue'], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[81]) === __hook__('m', noChange, [__519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[25]], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[81], null)) {
        return;
      }
      const newListener = __hook__('#.', this, ['__pendingValue'], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[83]);
      const oldListener = __hook__('#.', this, ['value'], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[84]);
      const shouldRemoveListener = newListener == null || oldListener != null && (__hook__('#.', newListener, ['capture'], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[85]) !== __hook__('#.', oldListener, ['capture'], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[85]) || __hook__('#.', newListener, ['once'], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[85]) !== __hook__('#.', oldListener, ['once'], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[85]) || __hook__('#.', newListener, ['passive'], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[85]) !== __hook__('#.', oldListener, ['passive'], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[85]));
      const shouldAddListener = newListener != null && (oldListener == null || shouldRemoveListener);
      if (shouldRemoveListener) {
        __hook__('#()', __hook__('#.', this, ['element'], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[81]), [
          'removeEventListener',
          [
            __hook__('#.', this, ['eventName'], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[81]),
            __hook__('#.', this, ['__boundHandleEvent'], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[81]),
            __hook__('#.', this, ['__options'], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[81])
          ]
        ], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[81]);
      }
      if (shouldAddListener) {
        __hook__('#=', this, [
          '__options',
          __hook__(getOptions, null, [newListener], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[81], 0)
        ], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[81]);
        __hook__('#()', __hook__('#.', this, ['element'], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[81]), [
          'addEventListener',
          [
            __hook__('#.', this, ['eventName'], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[81]),
            __hook__('#.', this, ['__boundHandleEvent'], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[81]),
            __hook__('#.', this, ['__options'], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[81])
          ]
        ], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[81]);
      }
      __hook__('#=', this, [
        'value',
        newListener
      ], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[81]);
      __hook__('#=', this, [
        '__pendingValue',
        __hook__('m', noChange, [__519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[25]], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[81], null)
      ], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[81]);
    }, null, arguments, __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[81]);
  }
  handleEvent(event) {
    return __hook__(event => {
      if (typeof __hook__('#.', this, ['value'], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[86]) === 'function') {
        __hook__('#()', __hook__('#.', this, ['value'], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[86]), [
          'call',
          [
            __hook__('#.', this, ['eventContext'], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[86]) || __hook__('#.', this, ['element'], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[86]),
            event
          ]
        ], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[86]);
      } else {
        __hook__('#()', __hook__('#.', this, ['value'], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[86]), [
          'handleEvent',
          [event]
        ], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[86]);
      }
    }, null, arguments, __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[86]);
  }
}
// We copy options because of the inconsistent behavior of browsers when reading
// the third argument of add/removeEventListener. IE11 doesn't support options
// at all. Chrome 41 only reads `capture` if the argument is an object.
const getOptions = (...args) => __hook__(o => o && (eventOptionsSupported ? {
  capture: __hook__('#.', o, ['capture'], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[88]),
  passive: __hook__('#.', o, ['passive'], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[89]),
  once: __hook__('#.', o, ['once'], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[90])
} : __hook__('#.', o, ['capture'], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[87])), null, args, __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[87]);  __hook__(() => {
}, null, [
  'export',
  __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[0],
  __045213766b0e56a0c3f2db9279bb9770e31ccd73fa3bc118b7423459ba0ec60e__module_namespace_6
], __519906315b82cb47be64a6712a33ed6c7f7c7da2e912709d9384b2baa377b6dd__[0], NaN);

/**
 * @license
 * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
 * This code may only be used under the BSD style license found at
 * http://polymer.github.io/LICENSE.txt
 * The complete set of authors may be found at
 * http://polymer.github.io/AUTHORS.txt
 * The complete set of contributors may be found at
 * http://polymer.github.io/CONTRIBUTORS.txt
 * Code distributed by Google as part of the polymer project is also
 * subject to an additional IP rights grant found at
 * http://polymer.github.io/PATENTS.txt
 */
const __71ed6be1a8e316a1418346ef60b0c053dfb11c3e8eb5b63d80152db7daa13be7__ = $hook$.$(__hook__, [
  '/components/thin-hook/demo/node_modules/lit-html/lib/template-factory.js',
  '/components/thin-hook/demo/node_modules/lit-html/lib/template.js',
  '/components/thin-hook/demo/node_modules/lit-html/lib/template-factory.js,templateFactory',
  '/components/thin-hook/demo/node_modules/lit-html/lib/template-factory.js,templateFactory,templateCache',
  '/components/thin-hook/demo/node_modules/lit-html/lib/template-factory.js,templateCaches',
  'S_uNpREdiC4aB1e_undefined;/components/thin-hook/demo/node_modules/lit-html/lib/template-factory.js,templateFactory',
  '/components/thin-hook/demo/node_modules/lit-html/lib/template-factory.js,templateFactory,stringsArray',
  'S_uNpREdiC4aB1e_WeakMap;/components/thin-hook/demo/node_modules/lit-html/lib/template-factory.js,templateFactory,stringsArray',
  '/components/thin-hook/demo/node_modules/lit-html/lib/template-factory.js,templateFactory,keyString',
  'S_uNpREdiC4aB1e_Map;/components/thin-hook/demo/node_modules/lit-html/lib/template-factory.js,templateFactory,keyString',
  '/components/thin-hook/demo/node_modules/lit-html/lib/template-factory.js,templateFactory,template',
  '/components/thin-hook/demo/node_modules/lit-html/lib/template-factory.js,templateFactory,key',
  '/components/thin-hook/demo/node_modules/lit-html/lib/template.js,marker',
  '/components/thin-hook/demo/node_modules/lit-html/lib/template.js,Template',
  'S_uNpREdiC4aB1e_Map;/components/thin-hook/demo/node_modules/lit-html/lib/template-factory.js,templateCaches'
]);
__hook__(() => {
}, null, [
  'import',
  {
    [__71ed6be1a8e316a1418346ef60b0c053dfb11c3e8eb5b63d80152db7daa13be7__[1]]: [
      __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__module_namespace_6,
      'marker',
      'Template'
    ]
  }
], __71ed6be1a8e316a1418346ef60b0c053dfb11c3e8eb5b63d80152db7daa13be7__[0], NaN);
/**
 * The default TemplateFactory which caches Templates keyed on
 * result.type and result.strings.
 */
function templateFactory(result) {
  return __hook__(result => {
    let templateCache = __hook__('#()', __hook__('m', templateCaches, [__71ed6be1a8e316a1418346ef60b0c053dfb11c3e8eb5b63d80152db7daa13be7__[4]], __71ed6be1a8e316a1418346ef60b0c053dfb11c3e8eb5b63d80152db7daa13be7__[3], null), [
      'get',
      [__hook__('#.', result, ['type'], __71ed6be1a8e316a1418346ef60b0c053dfb11c3e8eb5b63d80152db7daa13be7__[3])]
    ], __71ed6be1a8e316a1418346ef60b0c053dfb11c3e8eb5b63d80152db7daa13be7__[3]);
    if (templateCache === $hook$.global(__hook__, __71ed6be1a8e316a1418346ef60b0c053dfb11c3e8eb5b63d80152db7daa13be7__[2], 'undefined', '#get')[__71ed6be1a8e316a1418346ef60b0c053dfb11c3e8eb5b63d80152db7daa13be7__[5]]) {
      templateCache = {
        stringsArray: __hook__($hook$.global(__hook__, __71ed6be1a8e316a1418346ef60b0c053dfb11c3e8eb5b63d80152db7daa13be7__[6], 'WeakMap', '#get')[__71ed6be1a8e316a1418346ef60b0c053dfb11c3e8eb5b63d80152db7daa13be7__[7]], null, [], __71ed6be1a8e316a1418346ef60b0c053dfb11c3e8eb5b63d80152db7daa13be7__[6], true),
        keyString: __hook__($hook$.global(__hook__, __71ed6be1a8e316a1418346ef60b0c053dfb11c3e8eb5b63d80152db7daa13be7__[8], 'Map', '#get')[__71ed6be1a8e316a1418346ef60b0c053dfb11c3e8eb5b63d80152db7daa13be7__[9]], null, [], __71ed6be1a8e316a1418346ef60b0c053dfb11c3e8eb5b63d80152db7daa13be7__[8], true)
      };
      __hook__('#()', __hook__('m', templateCaches, [__71ed6be1a8e316a1418346ef60b0c053dfb11c3e8eb5b63d80152db7daa13be7__[4]], __71ed6be1a8e316a1418346ef60b0c053dfb11c3e8eb5b63d80152db7daa13be7__[2], null), [
        'set',
        [
          __hook__('#.', result, ['type'], __71ed6be1a8e316a1418346ef60b0c053dfb11c3e8eb5b63d80152db7daa13be7__[2]),
          templateCache
        ]
      ], __71ed6be1a8e316a1418346ef60b0c053dfb11c3e8eb5b63d80152db7daa13be7__[2]);
    }
    let template = __hook__('#()', __hook__('#.', templateCache, ['stringsArray'], __71ed6be1a8e316a1418346ef60b0c053dfb11c3e8eb5b63d80152db7daa13be7__[10]), [
      'get',
      [__hook__('#.', result, ['strings'], __71ed6be1a8e316a1418346ef60b0c053dfb11c3e8eb5b63d80152db7daa13be7__[10])]
    ], __71ed6be1a8e316a1418346ef60b0c053dfb11c3e8eb5b63d80152db7daa13be7__[10]);
    if (template !== $hook$.global(__hook__, __71ed6be1a8e316a1418346ef60b0c053dfb11c3e8eb5b63d80152db7daa13be7__[2], 'undefined', '#get')[__71ed6be1a8e316a1418346ef60b0c053dfb11c3e8eb5b63d80152db7daa13be7__[5]]) {
      return template;
    }
    // If the TemplateStringsArray is new, generate a key from the strings
    // This key is shared between all templates with identical content
    const key = __hook__('#()', __hook__('#.', result, ['strings'], __71ed6be1a8e316a1418346ef60b0c053dfb11c3e8eb5b63d80152db7daa13be7__[11]), [
      'join',
      [__hook__('m', marker, [__71ed6be1a8e316a1418346ef60b0c053dfb11c3e8eb5b63d80152db7daa13be7__[12]], __71ed6be1a8e316a1418346ef60b0c053dfb11c3e8eb5b63d80152db7daa13be7__[11], null)]
    ], __71ed6be1a8e316a1418346ef60b0c053dfb11c3e8eb5b63d80152db7daa13be7__[11]);
    // Check if we already have a Template for this key
    template = __hook__('#()', __hook__('#.', templateCache, ['keyString'], __71ed6be1a8e316a1418346ef60b0c053dfb11c3e8eb5b63d80152db7daa13be7__[2]), [
      'get',
      [key]
    ], __71ed6be1a8e316a1418346ef60b0c053dfb11c3e8eb5b63d80152db7daa13be7__[2]);
    if (template === $hook$.global(__hook__, __71ed6be1a8e316a1418346ef60b0c053dfb11c3e8eb5b63d80152db7daa13be7__[2], 'undefined', '#get')[__71ed6be1a8e316a1418346ef60b0c053dfb11c3e8eb5b63d80152db7daa13be7__[5]]) {
      // If we have not seen this key before, create a new Template
      template = __hook__('mnew', Template, [
        __71ed6be1a8e316a1418346ef60b0c053dfb11c3e8eb5b63d80152db7daa13be7__[13],
        [
          result,
          __hook__('#()', result, [
            'getTemplateElement',
            []
          ], __71ed6be1a8e316a1418346ef60b0c053dfb11c3e8eb5b63d80152db7daa13be7__[2])
        ],
        (...args) => new Template(...args)
      ], __71ed6be1a8e316a1418346ef60b0c053dfb11c3e8eb5b63d80152db7daa13be7__[2], null);
      // Cache the Template for this key
      __hook__('#()', __hook__('#.', templateCache, ['keyString'], __71ed6be1a8e316a1418346ef60b0c053dfb11c3e8eb5b63d80152db7daa13be7__[2]), [
        'set',
        [
          key,
          template
        ]
      ], __71ed6be1a8e316a1418346ef60b0c053dfb11c3e8eb5b63d80152db7daa13be7__[2]);
    }
    // Cache all future queries for this TemplateStringsArray
    __hook__('#()', __hook__('#.', templateCache, ['stringsArray'], __71ed6be1a8e316a1418346ef60b0c053dfb11c3e8eb5b63d80152db7daa13be7__[2]), [
      'set',
      [
        __hook__('#.', result, ['strings'], __71ed6be1a8e316a1418346ef60b0c053dfb11c3e8eb5b63d80152db7daa13be7__[2]),
        template
      ]
    ], __71ed6be1a8e316a1418346ef60b0c053dfb11c3e8eb5b63d80152db7daa13be7__[2]);
    return template;
  }, null, arguments, __71ed6be1a8e316a1418346ef60b0c053dfb11c3e8eb5b63d80152db7daa13be7__[2]);
}
const templateCaches = __hook__($hook$.global(__hook__, __71ed6be1a8e316a1418346ef60b0c053dfb11c3e8eb5b63d80152db7daa13be7__[4], 'Map', '#get')[__71ed6be1a8e316a1418346ef60b0c053dfb11c3e8eb5b63d80152db7daa13be7__[14]], null, [], __71ed6be1a8e316a1418346ef60b0c053dfb11c3e8eb5b63d80152db7daa13be7__[4], true);  __hook__(() => {
}, null, [
  'export',
  __71ed6be1a8e316a1418346ef60b0c053dfb11c3e8eb5b63d80152db7daa13be7__[0],
  __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__module_namespace_4
], __71ed6be1a8e316a1418346ef60b0c053dfb11c3e8eb5b63d80152db7daa13be7__[0], NaN);

/**
 * @license
 * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
 * This code may only be used under the BSD style license found at
 * http://polymer.github.io/LICENSE.txt
 * The complete set of authors may be found at
 * http://polymer.github.io/AUTHORS.txt
 * The complete set of contributors may be found at
 * http://polymer.github.io/CONTRIBUTORS.txt
 * Code distributed by Google as part of the polymer project is also
 * subject to an additional IP rights grant found at
 * http://polymer.github.io/PATENTS.txt
 */
/**
 * @module lit-html
 */
const __767d90bb11d71f7844008c8fe2211346047849173a7c312b03d06c57b155d0b0__ = $hook$.$(__hook__, [
  '/components/thin-hook/demo/node_modules/lit-html/lib/render.js',
  '/components/thin-hook/demo/node_modules/lit-html/lib/dom.js',
  '/components/thin-hook/demo/node_modules/lit-html/lib/parts.js',
  '/components/thin-hook/demo/node_modules/lit-html/lib/template-factory.js',
  '/components/thin-hook/demo/node_modules/lit-html/lib/render.js,parts',
  'S_uNpREdiC4aB1e_WeakMap;/components/thin-hook/demo/node_modules/lit-html/lib/render.js,parts',
  '/components/thin-hook/demo/node_modules/lit-html/lib/render.js,render',
  '/components/thin-hook/demo/node_modules/lit-html/lib/render.js,render,part',
  'S_uNpREdiC4aB1e_undefined;/components/thin-hook/demo/node_modules/lit-html/lib/render.js,render',
  '/components/thin-hook/demo/node_modules/lit-html/lib/dom.js,removeNodes',
  '/components/thin-hook/demo/node_modules/lit-html/lib/parts.js,NodePart',
  'S_uNpREdiC4aB1e_Object;/components/thin-hook/demo/node_modules/lit-html/lib/render.js,render',
  '/components/thin-hook/demo/node_modules/lit-html/lib/render.js,render,templateFactory',
  '/components/thin-hook/demo/node_modules/lit-html/lib/template-factory.js,templateFactory'
]);
__hook__(() => {
}, null, [
  'import',
  {
    [__767d90bb11d71f7844008c8fe2211346047849173a7c312b03d06c57b155d0b0__[1]]: [
      __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__module_namespace_1,
      'removeNodes'
    ],
    [__767d90bb11d71f7844008c8fe2211346047849173a7c312b03d06c57b155d0b0__[2]]: [
      __045213766b0e56a0c3f2db9279bb9770e31ccd73fa3bc118b7423459ba0ec60e__module_namespace_6,
      'NodePart'
    ],
    [__767d90bb11d71f7844008c8fe2211346047849173a7c312b03d06c57b155d0b0__[3]]: [
      __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__module_namespace_4,
      'templateFactory'
    ]
  }
], __767d90bb11d71f7844008c8fe2211346047849173a7c312b03d06c57b155d0b0__[0], NaN);
const parts = __hook__($hook$.global(__hook__, __767d90bb11d71f7844008c8fe2211346047849173a7c312b03d06c57b155d0b0__[4], 'WeakMap', '#get')[__767d90bb11d71f7844008c8fe2211346047849173a7c312b03d06c57b155d0b0__[5]], null, [], __767d90bb11d71f7844008c8fe2211346047849173a7c312b03d06c57b155d0b0__[4], true);
/**
 * Renders a template result or other value to a container.
 *
 * To update a container with new values, reevaluate the template literal and
 * call `render` with the new result.
 *
 * @param result Any value renderable by NodePart - typically a TemplateResult
 *     created by evaluating a template tag like `html` or `svg`.
 * @param container A DOM parent to render to. The entire contents are either
 *     replaced, or efficiently updated if the same result type was previous
 *     rendered there.
 * @param options RenderOptions for the entire render tree rendered to this
 *     container. Render options must *not* change between renders to the same
 *     container, as those changes will not effect previously rendered DOM.
 */
const render = (...args) =>
  (__hook__((result, container, options) => {
    let part = __hook__('#()', __hook__('m', parts, [__767d90bb11d71f7844008c8fe2211346047849173a7c312b03d06c57b155d0b0__[4]], __767d90bb11d71f7844008c8fe2211346047849173a7c312b03d06c57b155d0b0__[7], null), [
      'get',
      [container]
    ], __767d90bb11d71f7844008c8fe2211346047849173a7c312b03d06c57b155d0b0__[7]);
    if (part === $hook$.global(__hook__, __767d90bb11d71f7844008c8fe2211346047849173a7c312b03d06c57b155d0b0__[6], 'undefined', '#get')[__767d90bb11d71f7844008c8fe2211346047849173a7c312b03d06c57b155d0b0__[8]]) {
      __hook__('m()', removeNodes, [
        __767d90bb11d71f7844008c8fe2211346047849173a7c312b03d06c57b155d0b0__[9],
        [
          container,
          __hook__('#.', container, ['firstChild'], __767d90bb11d71f7844008c8fe2211346047849173a7c312b03d06c57b155d0b0__[6])
        ],
        (...args) => removeNodes(...args)
      ], __767d90bb11d71f7844008c8fe2211346047849173a7c312b03d06c57b155d0b0__[6], null);
      __hook__('#()', __hook__('m', parts, [__767d90bb11d71f7844008c8fe2211346047849173a7c312b03d06c57b155d0b0__[4]], __767d90bb11d71f7844008c8fe2211346047849173a7c312b03d06c57b155d0b0__[6], null), [
        'set',
        [
          container,
          part = __hook__('mnew', NodePart, [
            __767d90bb11d71f7844008c8fe2211346047849173a7c312b03d06c57b155d0b0__[10],
            [__hook__('#()', $hook$.global(__hook__, __767d90bb11d71f7844008c8fe2211346047849173a7c312b03d06c57b155d0b0__[6], 'Object', '#get')[__767d90bb11d71f7844008c8fe2211346047849173a7c312b03d06c57b155d0b0__[11]], [
                'assign',
                [
                  { templateFactory: __hook__('m', templateFactory, [__767d90bb11d71f7844008c8fe2211346047849173a7c312b03d06c57b155d0b0__[13]], __767d90bb11d71f7844008c8fe2211346047849173a7c312b03d06c57b155d0b0__[12], null) },
                  options
                ]
              ], __767d90bb11d71f7844008c8fe2211346047849173a7c312b03d06c57b155d0b0__[6])],
            (...args) => new NodePart(...args)
          ], __767d90bb11d71f7844008c8fe2211346047849173a7c312b03d06c57b155d0b0__[6], null)
        ]
      ], __767d90bb11d71f7844008c8fe2211346047849173a7c312b03d06c57b155d0b0__[6]);
      __hook__('#()', part, [
        'appendInto',
        [container]
      ], __767d90bb11d71f7844008c8fe2211346047849173a7c312b03d06c57b155d0b0__[6]);
    }
    __hook__('#()', part, [
      'setValue',
      [result]
    ], __767d90bb11d71f7844008c8fe2211346047849173a7c312b03d06c57b155d0b0__[6]);
    __hook__('#()', part, [
      'commit',
      []
    ], __767d90bb11d71f7844008c8fe2211346047849173a7c312b03d06c57b155d0b0__[6]);
  }, null, args, __767d90bb11d71f7844008c8fe2211346047849173a7c312b03d06c57b155d0b0__[6]));  __hook__(() => {
}, null, [
  'export',
  __767d90bb11d71f7844008c8fe2211346047849173a7c312b03d06c57b155d0b0__[0],
  __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__module_namespace_3
], __767d90bb11d71f7844008c8fe2211346047849173a7c312b03d06c57b155d0b0__[0], NaN);

/**
 * @license
 * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
 * This code may only be used under the BSD style license found at
 * http://polymer.github.io/LICENSE.txt
 * The complete set of authors may be found at
 * http://polymer.github.io/AUTHORS.txt
 * The complete set of contributors may be found at
 * http://polymer.github.io/CONTRIBUTORS.txt
 * Code distributed by Google as part of the polymer project is also
 * subject to an additional IP rights grant found at
 * http://polymer.github.io/PATENTS.txt
 */
const __03885b0ee4011b42c029afa64bacfffbd4ff687478d42262e8bfc8cf3ceaf961__ = $hook$.$(__hook__, [
  '/components/thin-hook/demo/node_modules/lit-html/lib/default-template-processor.js',
  '/components/thin-hook/demo/node_modules/lit-html/lib/parts.js',
  '/components/thin-hook/demo/node_modules/lit-html/lib/default-template-processor.js,DefaultTemplateProcessor,handleAttributeExpressions',
  '/components/thin-hook/demo/node_modules/lit-html/lib/default-template-processor.js,DefaultTemplateProcessor,handleAttributeExpressions,prefix',
  '/components/thin-hook/demo/node_modules/lit-html/lib/default-template-processor.js,DefaultTemplateProcessor,handleAttributeExpressions,committer',
  '/components/thin-hook/demo/node_modules/lit-html/lib/parts.js,PropertyCommitter',
  '/components/thin-hook/demo/node_modules/lit-html/lib/parts.js,EventPart',
  '/components/thin-hook/demo/node_modules/lit-html/lib/parts.js,BooleanAttributePart',
  '/components/thin-hook/demo/node_modules/lit-html/lib/parts.js,AttributeCommitter',
  '/components/thin-hook/demo/node_modules/lit-html/lib/default-template-processor.js,DefaultTemplateProcessor,handleTextExpression',
  '/components/thin-hook/demo/node_modules/lit-html/lib/parts.js,NodePart',
  '/components/thin-hook/demo/node_modules/lit-html/lib/default-template-processor.js,defaultTemplateProcessor',
  '/components/thin-hook/demo/node_modules/lit-html/lib/default-template-processor.js,DefaultTemplateProcessor'
]);
__hook__(() => {
}, null, [
  'import',
  {
    [__03885b0ee4011b42c029afa64bacfffbd4ff687478d42262e8bfc8cf3ceaf961__[1]]: [
      __045213766b0e56a0c3f2db9279bb9770e31ccd73fa3bc118b7423459ba0ec60e__module_namespace_6,
      'AttributeCommitter',
      'BooleanAttributePart',
      'EventPart',
      'NodePart',
      'PropertyCommitter'
    ]
  }
], __03885b0ee4011b42c029afa64bacfffbd4ff687478d42262e8bfc8cf3ceaf961__[0], NaN);
/**
 * Creates Parts when a template is instantiated.
 */
class DefaultTemplateProcessor {
  /**
     * Create parts for an attribute-position binding, given the event, attribute
     * name, and string literals.
     *
     * @param element The element containing the binding
     * @param name  The attribute name
     * @param strings The string literals. There are always at least two strings,
     *   event for fully-controlled bindings with a single expression.
     */
  handleAttributeExpressions(element, name, strings, options) {
    return __hook__((element, name, strings, options) => {
      const prefix = __hook__('#.', name, [0], __03885b0ee4011b42c029afa64bacfffbd4ff687478d42262e8bfc8cf3ceaf961__[3]);
      if (prefix === '.') {
        const committer = __hook__('mnew', PropertyCommitter, [
          __03885b0ee4011b42c029afa64bacfffbd4ff687478d42262e8bfc8cf3ceaf961__[5],
          [
            element,
            __hook__('#()', name, [
              'slice',
              [1]
            ], __03885b0ee4011b42c029afa64bacfffbd4ff687478d42262e8bfc8cf3ceaf961__[4]),
            strings
          ],
          (...args) => new PropertyCommitter(...args)
        ], __03885b0ee4011b42c029afa64bacfffbd4ff687478d42262e8bfc8cf3ceaf961__[4], null);
        return __hook__('#.', committer, ['parts'], __03885b0ee4011b42c029afa64bacfffbd4ff687478d42262e8bfc8cf3ceaf961__[2]);
      }
      if (prefix === '@') {
        return [__hook__('mnew', EventPart, [
            __03885b0ee4011b42c029afa64bacfffbd4ff687478d42262e8bfc8cf3ceaf961__[6],
            [
              element,
              __hook__('#()', name, [
                'slice',
                [1]
              ], __03885b0ee4011b42c029afa64bacfffbd4ff687478d42262e8bfc8cf3ceaf961__[2]),
              __hook__('#.', options, ['eventContext'], __03885b0ee4011b42c029afa64bacfffbd4ff687478d42262e8bfc8cf3ceaf961__[2])
            ],
            (...args) => new EventPart(...args)
          ], __03885b0ee4011b42c029afa64bacfffbd4ff687478d42262e8bfc8cf3ceaf961__[2], null)];
      }
      if (prefix === '?') {
        return [__hook__('mnew', BooleanAttributePart, [
            __03885b0ee4011b42c029afa64bacfffbd4ff687478d42262e8bfc8cf3ceaf961__[7],
            [
              element,
              __hook__('#()', name, [
                'slice',
                [1]
              ], __03885b0ee4011b42c029afa64bacfffbd4ff687478d42262e8bfc8cf3ceaf961__[2]),
              strings
            ],
            (...args) => new BooleanAttributePart(...args)
          ], __03885b0ee4011b42c029afa64bacfffbd4ff687478d42262e8bfc8cf3ceaf961__[2], null)];
      }
      const committer = __hook__('mnew', AttributeCommitter, [
        __03885b0ee4011b42c029afa64bacfffbd4ff687478d42262e8bfc8cf3ceaf961__[8],
        [
          element,
          name,
          strings
        ],
        (...args) => new AttributeCommitter(...args)
      ], __03885b0ee4011b42c029afa64bacfffbd4ff687478d42262e8bfc8cf3ceaf961__[4], null);
      return __hook__('#.', committer, ['parts'], __03885b0ee4011b42c029afa64bacfffbd4ff687478d42262e8bfc8cf3ceaf961__[2]);
    }, null, arguments, __03885b0ee4011b42c029afa64bacfffbd4ff687478d42262e8bfc8cf3ceaf961__[2]);
  }
  /**
     * Create parts for a text-position binding.
     * @param templateFactory
     */
  handleTextExpression(options) {
    return __hook__(options => {
      return __hook__('mnew', NodePart, [
        __03885b0ee4011b42c029afa64bacfffbd4ff687478d42262e8bfc8cf3ceaf961__[10],
        [options],
        (...args) => new NodePart(...args)
      ], __03885b0ee4011b42c029afa64bacfffbd4ff687478d42262e8bfc8cf3ceaf961__[9], null);
    }, null, arguments, __03885b0ee4011b42c029afa64bacfffbd4ff687478d42262e8bfc8cf3ceaf961__[9]);
  }
}
const defaultTemplateProcessor = __hook__('mnew', DefaultTemplateProcessor, [
  __03885b0ee4011b42c029afa64bacfffbd4ff687478d42262e8bfc8cf3ceaf961__[12],
  [],
  (...args) => new DefaultTemplateProcessor(...args)
], __03885b0ee4011b42c029afa64bacfffbd4ff687478d42262e8bfc8cf3ceaf961__[11], null);  __hook__(() => {
}, null, [
  'export',
  __03885b0ee4011b42c029afa64bacfffbd4ff687478d42262e8bfc8cf3ceaf961__[0],
  __045213766b0e56a0c3f2db9279bb9770e31ccd73fa3bc118b7423459ba0ec60e__module_namespace_1
], __03885b0ee4011b42c029afa64bacfffbd4ff687478d42262e8bfc8cf3ceaf961__[0], NaN);

/**
 * @license
 * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
 * This code may only be used under the BSD style license found at
 * http://polymer.github.io/LICENSE.txt
 * The complete set of authors may be found at
 * http://polymer.github.io/AUTHORS.txt
 * The complete set of contributors may be found at
 * http://polymer.github.io/CONTRIBUTORS.txt
 * Code distributed by Google as part of the polymer project is also
 * subject to an additional IP rights grant found at
 * http://polymer.github.io/PATENTS.txt
 */
/**
 *
 * Main lit-html module.
 *
 * Main exports:
 *
 * -  [[html]]
 * -  [[svg]]
 * -  [[render]]
 *
 * @module lit-html
 * @preferred
 */
/**
 * Do not remove this comment; it keeps typedoc from misplacing the module
 * docs.
 */
const __045213766b0e56a0c3f2db9279bb9770e31ccd73fa3bc118b7423459ba0ec60e__ = $hook$.$(__hook__, [
  '/components/thin-hook/demo/node_modules/lit-html/lit-html.js',
  '/components/thin-hook/demo/node_modules/lit-html/lib/default-template-processor.js',
  '/components/thin-hook/demo/node_modules/lit-html/lib/template-result.js',
  '/components/thin-hook/demo/node_modules/lit-html/lib/directive.js',
  '/components/thin-hook/demo/node_modules/lit-html/lib/dom.js',
  '/components/thin-hook/demo/node_modules/lit-html/lib/part.js',
  '/components/thin-hook/demo/node_modules/lit-html/lib/parts.js',
  '/components/thin-hook/demo/node_modules/lit-html/lib/render.js',
  '/components/thin-hook/demo/node_modules/lit-html/lib/template-factory.js',
  '/components/thin-hook/demo/node_modules/lit-html/lib/template-instance.js',
  '/components/thin-hook/demo/node_modules/lit-html/lib/template.js',
  'S_uNpREdiC4aB1e_window;/components/thin-hook/demo/node_modules/lit-html/lit-html.js',
  '/components/thin-hook/demo/node_modules/lit-html/lit-html.js,html',
  '/components/thin-hook/demo/node_modules/lit-html/lib/template-result.js,TemplateResult',
  '/components/thin-hook/demo/node_modules/lit-html/lib/default-template-processor.js,defaultTemplateProcessor',
  '/components/thin-hook/demo/node_modules/lit-html/lit-html.js,svg',
  '/components/thin-hook/demo/node_modules/lit-html/lib/template-result.js,SVGTemplateResult'
]);
__hook__(() => {
}, null, [
  'import',
  {
    [__045213766b0e56a0c3f2db9279bb9770e31ccd73fa3bc118b7423459ba0ec60e__[1]]: [
      __045213766b0e56a0c3f2db9279bb9770e31ccd73fa3bc118b7423459ba0ec60e__module_namespace_1,
      'defaultTemplateProcessor',
      'DefaultTemplateProcessor'
    ],
    [__045213766b0e56a0c3f2db9279bb9770e31ccd73fa3bc118b7423459ba0ec60e__[2]]: [
      __045213766b0e56a0c3f2db9279bb9770e31ccd73fa3bc118b7423459ba0ec60e__module_namespace_2,
      'SVGTemplateResult',
      'TemplateResult'
    ],
    [__045213766b0e56a0c3f2db9279bb9770e31ccd73fa3bc118b7423459ba0ec60e__[3]]: [
      __045213766b0e56a0c3f2db9279bb9770e31ccd73fa3bc118b7423459ba0ec60e__module_namespace_3,
      'directive',
      'isDirective'
    ],
    [__045213766b0e56a0c3f2db9279bb9770e31ccd73fa3bc118b7423459ba0ec60e__[4]]: [
      __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__module_namespace_1,
      'removeNodes',
      'reparentNodes'
    ],
    [__045213766b0e56a0c3f2db9279bb9770e31ccd73fa3bc118b7423459ba0ec60e__[5]]: [
      __045213766b0e56a0c3f2db9279bb9770e31ccd73fa3bc118b7423459ba0ec60e__module_namespace_5,
      'noChange',
      'nothing'
    ],
    [__045213766b0e56a0c3f2db9279bb9770e31ccd73fa3bc118b7423459ba0ec60e__[6]]: [
      __045213766b0e56a0c3f2db9279bb9770e31ccd73fa3bc118b7423459ba0ec60e__module_namespace_6,
      'AttributeCommitter',
      'AttributePart',
      'BooleanAttributePart',
      'EventPart',
      'isIterable',
      'isPrimitive',
      'NodePart',
      'PropertyCommitter',
      'PropertyPart'
    ],
    [__045213766b0e56a0c3f2db9279bb9770e31ccd73fa3bc118b7423459ba0ec60e__[7]]: [
      __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__module_namespace_3,
      'parts',
      'render'
    ],
    [__045213766b0e56a0c3f2db9279bb9770e31ccd73fa3bc118b7423459ba0ec60e__[8]]: [
      __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__module_namespace_4,
      'templateCaches',
      'templateFactory'
    ],
    [__045213766b0e56a0c3f2db9279bb9770e31ccd73fa3bc118b7423459ba0ec60e__[9]]: [
      __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__module_namespace_5,
      'TemplateInstance'
    ],
    [__045213766b0e56a0c3f2db9279bb9770e31ccd73fa3bc118b7423459ba0ec60e__[10]]: [
      __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__module_namespace_6,
      'createMarker',
      'isTemplatePartActive',
      'Template'
    ]
  }
], __045213766b0e56a0c3f2db9279bb9770e31ccd73fa3bc118b7423459ba0ec60e__[0], NaN);
// IMPORTANT: do not change the property name or the assignment expression.
// This line will be used in regexes to search for lit-html usage.
// TODO(justinfagnani): inject version number at build time
if (typeof $hook$.global(__hook__, __045213766b0e56a0c3f2db9279bb9770e31ccd73fa3bc118b7423459ba0ec60e__[0], 'window', '#typeof')[__045213766b0e56a0c3f2db9279bb9770e31ccd73fa3bc118b7423459ba0ec60e__[11]] !== 'undefined') {
  __hook__('#()', __hook__('#.', $hook$.global(__hook__, __045213766b0e56a0c3f2db9279bb9770e31ccd73fa3bc118b7423459ba0ec60e__[0], 'window', '#get')[__045213766b0e56a0c3f2db9279bb9770e31ccd73fa3bc118b7423459ba0ec60e__[11]], ['litHtmlVersions'], __045213766b0e56a0c3f2db9279bb9770e31ccd73fa3bc118b7423459ba0ec60e__[0]) || __hook__('#=', window, [
    'litHtmlVersions',
    []
  ], __045213766b0e56a0c3f2db9279bb9770e31ccd73fa3bc118b7423459ba0ec60e__[0]), [
    'push',
    ['1.2.1']
  ], __045213766b0e56a0c3f2db9279bb9770e31ccd73fa3bc118b7423459ba0ec60e__[0]);
}
/**
 * Interprets a template literal as an HTML template that can efficiently
 * render to and update a container.
 */
const html = (...args) => __hook__((strings, ...values) => __hook__('mnew', TemplateResult, [
  __045213766b0e56a0c3f2db9279bb9770e31ccd73fa3bc118b7423459ba0ec60e__[13],
  [
    strings,
    values,
    'html',
    __hook__('m', defaultTemplateProcessor, [__045213766b0e56a0c3f2db9279bb9770e31ccd73fa3bc118b7423459ba0ec60e__[14]], __045213766b0e56a0c3f2db9279bb9770e31ccd73fa3bc118b7423459ba0ec60e__[12], null)
  ],
  (...args) => new TemplateResult(...args)
], __045213766b0e56a0c3f2db9279bb9770e31ccd73fa3bc118b7423459ba0ec60e__[12], null), null, args, __045213766b0e56a0c3f2db9279bb9770e31ccd73fa3bc118b7423459ba0ec60e__[12]);
/**
 * Interprets a template literal as an SVG template that can efficiently
 * render to and update a container.
 */
const svg = (...args) => __hook__((strings, ...values) => __hook__('mnew', SVGTemplateResult, [
  __045213766b0e56a0c3f2db9279bb9770e31ccd73fa3bc118b7423459ba0ec60e__[16],
  [
    strings,
    values,
    'svg',
    __hook__('m', defaultTemplateProcessor, [__045213766b0e56a0c3f2db9279bb9770e31ccd73fa3bc118b7423459ba0ec60e__[14]], __045213766b0e56a0c3f2db9279bb9770e31ccd73fa3bc118b7423459ba0ec60e__[15], null)
  ],
  (...args) => new SVGTemplateResult(...args)
], __045213766b0e56a0c3f2db9279bb9770e31ccd73fa3bc118b7423459ba0ec60e__[15], null), null, args, __045213766b0e56a0c3f2db9279bb9770e31ccd73fa3bc118b7423459ba0ec60e__[15]);  __hook__(() => {
}, null, [
  'export',
  __045213766b0e56a0c3f2db9279bb9770e31ccd73fa3bc118b7423459ba0ec60e__[0],
  litHtmlNamespace
], __045213766b0e56a0c3f2db9279bb9770e31ccd73fa3bc118b7423459ba0ec60e__[0], NaN);

/**
 * @license
 * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
 * This code may only be used under the BSD style license found at
 * http://polymer.github.io/LICENSE.txt
 * The complete set of authors may be found at
 * http://polymer.github.io/AUTHORS.txt
 * The complete set of contributors may be found at
 * http://polymer.github.io/CONTRIBUTORS.txt
 * Code distributed by Google as part of the polymer project is also
 * subject to an additional IP rights grant found at
 * http://polymer.github.io/PATENTS.txt
 */
/**
 * Module to add shady DOM/shady CSS polyfill support to lit-html template
 * rendering. See the [[render]] method for details.
 *
 * @module shady-render
 * @preferred
 */
/**
 * Do not remove this comment; it keeps typedoc from misplacing the module
 * docs.
 */
const __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__ = $hook$.$(__hook__, [
  '/components/thin-hook/demo/node_modules/lit-html/lib/shady-render.js',
  '/components/thin-hook/demo/node_modules/lit-html/lib/dom.js',
  '/components/thin-hook/demo/node_modules/lit-html/lib/modify-template.js',
  '/components/thin-hook/demo/node_modules/lit-html/lib/render.js',
  '/components/thin-hook/demo/node_modules/lit-html/lib/template-factory.js',
  '/components/thin-hook/demo/node_modules/lit-html/lib/template-instance.js',
  '/components/thin-hook/demo/node_modules/lit-html/lib/template.js',
  '/components/thin-hook/demo/node_modules/lit-html/lit-html.js',
  '/components/thin-hook/demo/node_modules/lit-html/lib/shady-render.js,getTemplateCacheKey',
  'S_uNpREdiC4aB1e_window;/components/thin-hook/demo/node_modules/lit-html/lib/shady-render.js',
  'S_uNpREdiC4aB1e_console;/components/thin-hook/demo/node_modules/lit-html/lib/shady-render.js',
  '/components/thin-hook/demo/node_modules/lit-html/lib/shady-render.js,shadyTemplateFactory',
  '/components/thin-hook/demo/node_modules/lit-html/lib/shady-render.js,shadyTemplateFactory,cacheKey',
  '/components/thin-hook/demo/node_modules/lit-html/lib/shady-render.js,shadyTemplateFactory,templateCache',
  '/components/thin-hook/demo/node_modules/lit-html/lib/template-factory.js,templateCaches',
  'S_uNpREdiC4aB1e_undefined;/components/thin-hook/demo/node_modules/lit-html/lib/shady-render.js,shadyTemplateFactory',
  '/components/thin-hook/demo/node_modules/lit-html/lib/shady-render.js,shadyTemplateFactory,stringsArray',
  'S_uNpREdiC4aB1e_WeakMap;/components/thin-hook/demo/node_modules/lit-html/lib/shady-render.js,shadyTemplateFactory,stringsArray',
  '/components/thin-hook/demo/node_modules/lit-html/lib/shady-render.js,shadyTemplateFactory,keyString',
  'S_uNpREdiC4aB1e_Map;/components/thin-hook/demo/node_modules/lit-html/lib/shady-render.js,shadyTemplateFactory,keyString',
  '/components/thin-hook/demo/node_modules/lit-html/lib/shady-render.js,shadyTemplateFactory,template',
  '/components/thin-hook/demo/node_modules/lit-html/lib/shady-render.js,shadyTemplateFactory,key',
  '/components/thin-hook/demo/node_modules/lit-html/lib/template.js,marker',
  '/components/thin-hook/demo/node_modules/lit-html/lib/shady-render.js,shadyTemplateFactory,element',
  'S_uNpREdiC4aB1e_window;/components/thin-hook/demo/node_modules/lit-html/lib/shady-render.js,shadyTemplateFactory',
  '/components/thin-hook/demo/node_modules/lit-html/lib/template.js,Template',
  '/components/thin-hook/demo/node_modules/lit-html/lib/shady-render.js,removeStylesFromLitTemplates',
  '/components/thin-hook/demo/node_modules/lit-html/lib/shady-render.js,removeStylesFromLitTemplates,templates',
  'S_uNpREdiC4aB1e_undefined;/components/thin-hook/demo/node_modules/lit-html/lib/shady-render.js,removeStylesFromLitTemplates',
  '/components/thin-hook/demo/node_modules/lit-html/lib/shady-render.js,removeStylesFromLitTemplates,styles',
  'S_uNpREdiC4aB1e_Set;/components/thin-hook/demo/node_modules/lit-html/lib/shady-render.js,removeStylesFromLitTemplates,styles',
  'S_uNpREdiC4aB1e_Array;/components/thin-hook/demo/node_modules/lit-html/lib/shady-render.js,removeStylesFromLitTemplates',
  '/components/thin-hook/demo/node_modules/lit-html/lib/modify-template.js,removeNodesFromTemplate',
  '/components/thin-hook/demo/node_modules/lit-html/lib/shady-render.js,shadyRenderSet',
  'S_uNpREdiC4aB1e_Set;/components/thin-hook/demo/node_modules/lit-html/lib/shady-render.js,shadyRenderSet',
  '/components/thin-hook/demo/node_modules/lit-html/lib/shady-render.js,prepareTemplateStyles',
  '/components/thin-hook/demo/node_modules/lit-html/lib/shady-render.js,prepareTemplateStyles,templateElement',
  'S_uNpREdiC4aB1e_document;/components/thin-hook/demo/node_modules/lit-html/lib/shady-render.js,prepareTemplateStyles,templateElement',
  '/components/thin-hook/demo/node_modules/lit-html/lib/shady-render.js,prepareTemplateStyles,styles',
  'S_uNpREdiC4aB1e_window;/components/thin-hook/demo/node_modules/lit-html/lib/shady-render.js,prepareTemplateStyles',
  '/components/thin-hook/demo/node_modules/lit-html/lib/shady-render.js,prepareTemplateStyles,condensedStyle',
  'S_uNpREdiC4aB1e_document;/components/thin-hook/demo/node_modules/lit-html/lib/shady-render.js,prepareTemplateStyles,condensedStyle',
  '/components/thin-hook/demo/node_modules/lit-html/lib/shady-render.js,prepareTemplateStyles,style',
  '/components/thin-hook/demo/node_modules/lit-html/lib/shady-render.js,prepareTemplateStyles,content',
  '/components/thin-hook/demo/node_modules/lit-html/lib/modify-template.js,insertNodeIntoTemplate',
  '/components/thin-hook/demo/node_modules/lit-html/lib/shady-render.js,prepareTemplateStyles,removes',
  'S_uNpREdiC4aB1e_Set;/components/thin-hook/demo/node_modules/lit-html/lib/shady-render.js,prepareTemplateStyles,removes',
  '/components/thin-hook/demo/node_modules/lit-html/lib/shady-render.js,render',
  'S_uNpREdiC4aB1e_Error;/components/thin-hook/demo/node_modules/lit-html/lib/shady-render.js,render',
  '/components/thin-hook/demo/node_modules/lit-html/lib/shady-render.js,render,scopeName',
  '/components/thin-hook/demo/node_modules/lit-html/lib/shady-render.js,render,hasRendered',
  '/components/thin-hook/demo/node_modules/lit-html/lib/render.js,parts',
  '/components/thin-hook/demo/node_modules/lit-html/lib/shady-render.js,render,needsScoping',
  '/components/thin-hook/demo/node_modules/lit-html/lib/shady-render.js,render,firstScopeRender',
  '/components/thin-hook/demo/node_modules/lit-html/lib/shady-render.js,render,renderContainer',
  'S_uNpREdiC4aB1e_document;/components/thin-hook/demo/node_modules/lit-html/lib/shady-render.js,render,renderContainer',
  '/components/thin-hook/demo/node_modules/lit-html/lib/render.js,render',
  'S_uNpREdiC4aB1e_Object;/components/thin-hook/demo/node_modules/lit-html/lib/shady-render.js,render',
  '/components/thin-hook/demo/node_modules/lit-html/lib/shady-render.js,render,templateFactory',
  '/components/thin-hook/demo/node_modules/lit-html/lib/shady-render.js,render,part',
  '/components/thin-hook/demo/node_modules/lit-html/lib/shady-render.js,render,template',
  '/components/thin-hook/demo/node_modules/lit-html/lib/template-instance.js,TemplateInstance',
  'S_uNpREdiC4aB1e_undefined;/components/thin-hook/demo/node_modules/lit-html/lib/shady-render.js,render,template',
  '/components/thin-hook/demo/node_modules/lit-html/lib/dom.js,removeNodes',
  'S_uNpREdiC4aB1e_window;/components/thin-hook/demo/node_modules/lit-html/lib/shady-render.js,render'
]);
__hook__(() => {
}, null, [
  'import',
  {
    [__b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[1]]: [
      __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__module_namespace_1,
      'removeNodes'
    ],
    [__b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[2]]: [
      __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__module_namespace_2,
      'insertNodeIntoTemplate',
      'removeNodesFromTemplate'
    ],
    [__b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[3]]: [
      __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__module_namespace_3,
      'parts',
      'render'
    ],
    [__b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[4]]: [
      __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__module_namespace_4,
      'templateCaches'
    ],
    [__b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[5]]: [
      __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__module_namespace_5,
      'TemplateInstance'
    ],
    [__b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[6]]: [
      __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__module_namespace_6,
      'marker',
      'Template'
    ],
    [__b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[7]]: [
      litHtmlNamespace,
      'html',
      'svg',
      'TemplateResult'
    ]
  }
], __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[0], NaN);
// Get a key to lookup in `templateCaches`.
const getTemplateCacheKey = (...args) => __hook__((type, scopeName) => `${ type }--${ scopeName }`, null, args, __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[8]);
let compatibleShadyCSSVersion = true;
if (typeof __hook__('#.', $hook$.global(__hook__, __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[0], 'window', '#get')[__b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[9]], ['ShadyCSS'], __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[0]) === 'undefined') {
  compatibleShadyCSSVersion = false;
} else if (typeof __hook__('#.', __hook__('#.', $hook$.global(__hook__, __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[0], 'window', '#get')[__b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[9]], ['ShadyCSS'], __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[0]), ['prepareTemplateDom'], __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[0]) === 'undefined') {
  __hook__('#()', $hook$.global(__hook__, __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[0], 'console', '#get')[__b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[10]], [
    'warn',
    [`Incompatible ShadyCSS version detected. ` + `Please update to at least @webcomponents/webcomponentsjs@2.0.2 and ` + `@webcomponents/shadycss@1.3.1.`]
  ], __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[0]);
  compatibleShadyCSSVersion = false;
}
/**
 * Template factory which scopes template DOM using ShadyCSS.
 * @param scopeName {string}
 */
const shadyTemplateFactory = (...args) => __hook__(scopeName => (...args) =>
  (__hook__(result => {
    const cacheKey = __hook__(getTemplateCacheKey, null, [
      __hook__('#.', result, ['type'], __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[12]),
      scopeName
    ], __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[12], 0);
    let templateCache = __hook__('#()', __hook__('m', templateCaches, [__b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[14]], __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[13], null), [
      'get',
      [cacheKey]
    ], __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[13]);
    if (templateCache === $hook$.global(__hook__, __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[11], 'undefined', '#get')[__b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[15]]) {
      templateCache = {
        stringsArray: __hook__($hook$.global(__hook__, __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[16], 'WeakMap', '#get')[__b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[17]], null, [], __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[16], true),
        keyString: __hook__($hook$.global(__hook__, __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[18], 'Map', '#get')[__b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[19]], null, [], __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[18], true)
      };
      __hook__('#()', __hook__('m', templateCaches, [__b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[14]], __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[11], null), [
        'set',
        [
          cacheKey,
          templateCache
        ]
      ], __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[11]);
    }
    let template = __hook__('#()', __hook__('#.', templateCache, ['stringsArray'], __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[20]), [
      'get',
      [__hook__('#.', result, ['strings'], __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[20])]
    ], __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[20]);
    if (template !== $hook$.global(__hook__, __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[11], 'undefined', '#get')[__b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[15]]) {
      return template;
    }
    const key = __hook__('#()', __hook__('#.', result, ['strings'], __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[21]), [
      'join',
      [__hook__('m', marker, [__b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[22]], __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[21], null)]
    ], __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[21]);
    template = __hook__('#()', __hook__('#.', templateCache, ['keyString'], __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[11]), [
      'get',
      [key]
    ], __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[11]);
    if (template === $hook$.global(__hook__, __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[11], 'undefined', '#get')[__b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[15]]) {
      const element = __hook__('#()', result, [
        'getTemplateElement',
        []
      ], __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[23]);
      if (compatibleShadyCSSVersion) {
        __hook__('#()', __hook__('#.', $hook$.global(__hook__, __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[11], 'window', '#get')[__b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[24]], ['ShadyCSS'], __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[11]), [
          'prepareTemplateDom',
          [
            element,
            scopeName
          ]
        ], __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[11]);
      }
      template = __hook__('mnew', Template, [
        __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[25],
        [
          result,
          element
        ],
        (...args) => new Template(...args)
      ], __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[11], null);
      __hook__('#()', __hook__('#.', templateCache, ['keyString'], __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[11]), [
        'set',
        [
          key,
          template
        ]
      ], __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[11]);
    }
    __hook__('#()', __hook__('#.', templateCache, ['stringsArray'], __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[11]), [
      'set',
      [
        __hook__('#.', result, ['strings'], __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[11]),
        template
      ]
    ], __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[11]);
    return template;
  }, null, args, __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[11])), null, args, __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[11]);
const TEMPLATE_TYPES = [
  'html',
  'svg'
];
/**
 * Removes all style elements from Templates for the given scopeName.
 */
const removeStylesFromLitTemplates = (...args) =>
  (__hook__(scopeName => {
    __hook__('#()', TEMPLATE_TYPES, [
      'forEach',
      [(...args) =>
          (__hook__(type => {
            const templates = __hook__('#()', __hook__('m', templateCaches, [__b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[14]], __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[27], null), [
              'get',
              [__hook__(getTemplateCacheKey, null, [
                  type,
                  scopeName
                ], __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[27], 0)]
            ], __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[27]);
            if (templates !== $hook$.global(__hook__, __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[26], 'undefined', '#get')[__b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[28]]) {
              __hook__('#()', __hook__('#.', templates, ['keyString'], __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[26]), [
                'forEach',
                [(...args) =>
                    (__hook__(template => {
                      const {
                        element: {content}
                      } = __hook__('#*', template, [], __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[26]);
                      // IE 11 doesn't support the iterable param Set constructor
                      const styles = __hook__($hook$.global(__hook__, __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[29], 'Set', '#get')[__b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[30]], null, [], __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[29], true);
                      __hook__('#()', __hook__('#()', $hook$.global(__hook__, __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[26], 'Array', '#get')[__b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[31]], [
                        'from',
                        [__hook__('#()', content, [
                            'querySelectorAll',
                            ['style']
                          ], __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[26])]
                      ], __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[26]), [
                        'forEach',
                        [(...args) =>
                            (__hook__(s => {
                              __hook__('#()', styles, [
                                'add',
                                [s]
                              ], __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[26]);
                            }, null, args, __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[26]))]
                      ], __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[26]);
                      __hook__('m()', removeNodesFromTemplate, [
                        __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[32],
                        [
                          template,
                          styles
                        ],
                        (...args) => removeNodesFromTemplate(...args)
                      ], __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[26], null);
                    }, null, args, __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[26]))]
              ], __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[26]);
            }
          }, null, args, __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[26]))]
    ], __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[26]);
  }, null, args, __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[26]));
const shadyRenderSet = __hook__($hook$.global(__hook__, __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[33], 'Set', '#get')[__b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[34]], null, [], __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[33], true);
/**
 * For the given scope name, ensures that ShadyCSS style scoping is performed.
 * This is done just once per scope name so the fragment and template cannot
 * be modified.
 * (1) extracts styles from the rendered fragment and hands them to ShadyCSS
 * to be scoped and appended to the document
 * (2) removes style elements from all lit-html Templates for this scope name.
 *
 * Note, <style> elements can only be placed into templates for the
 * initial rendering of the scope. If <style> elements are included in templates
 * dynamically rendered to the scope (after the first scope render), they will
 * not be scoped and the <style> will be left in the template and rendered
 * output.
 */
const prepareTemplateStyles = (...args) =>
  (__hook__((scopeName, renderedDOM, template) => {
    __hook__('#()', shadyRenderSet, [
      'add',
      [scopeName]
    ], __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[35]);
    // If `renderedDOM` is stamped from a Template, then we need to edit that
    // Template's underlying template element. Otherwise, we create one here
    // to give to ShadyCSS, which still requires one while scoping.
    const templateElement = !!template ? __hook__('#.', template, ['element'], __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[36]) : __hook__('#()', $hook$.global(__hook__, __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[36], 'document', '#get')[__b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[37]], [
      'createElement',
      ['template']
    ], __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[36]);
    // Move styles out of rendered DOM and store.
    const styles = __hook__('#()', renderedDOM, [
      'querySelectorAll',
      ['style']
    ], __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[38]);
    const {length} = __hook__('#*', styles, [], __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[35]);
    // If there are no styles, skip unnecessary work
    if (length === 0) {
      // Ensure prepareTemplateStyles is called to support adding
      // styles via `prepareAdoptedCssText` since that requires that
      // `prepareTemplateStyles` is called.
      //
      // ShadyCSS will only update styles containing @apply in the template
      // given to `prepareTemplateStyles`. If no lit Template was given,
      // ShadyCSS will not be able to update uses of @apply in any relevant
      // template. However, this is not a problem because we only create the
      // template for the purpose of supporting `prepareAdoptedCssText`,
      // which doesn't support @apply at all.
      __hook__('#()', __hook__('#.', $hook$.global(__hook__, __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[35], 'window', '#get')[__b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[39]], ['ShadyCSS'], __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[35]), [
        'prepareTemplateStyles',
        [
          templateElement,
          scopeName
        ]
      ], __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[35]);
      return;
    }
    const condensedStyle = __hook__('#()', $hook$.global(__hook__, __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[40], 'document', '#get')[__b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[41]], [
      'createElement',
      ['style']
    ], __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[40]);
    // Collect styles into a single style. This helps us make sure ShadyCSS
    // manipulations will not prevent us from being able to fix up template
    // part indices.
    // NOTE: collecting styles is inefficient for browsers but ShadyCSS
    // currently does this anyway. When it does not, this should be changed.
    for (let i = 0; i < length; i++) {
      const style = __hook__('#.', styles, [i], __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[42]);
      __hook__('#()', __hook__('#.', style, ['parentNode'], __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[35]), [
        'removeChild',
        [style]
      ], __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[35]);
      __hook__('#+=', condensedStyle, [
        'textContent',
        __hook__('#.', style, ['textContent'], __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[35])
      ], __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[35]);
    }
    // Remove styles from nested templates in this scope.
    __hook__(removeStylesFromLitTemplates, null, [scopeName], __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[35], 0);
    // And then put the condensed style into the "root" template passed in as
    // `template`.
    const content = __hook__('#.', templateElement, ['content'], __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[43]);
    if (!!template) {
      __hook__('m()', insertNodeIntoTemplate, [
        __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[44],
        [
          template,
          condensedStyle,
          __hook__('#.', content, ['firstChild'], __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[35])
        ],
        (...args) => insertNodeIntoTemplate(...args)
      ], __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[35], null);
    } else {
      __hook__('#()', content, [
        'insertBefore',
        [
          condensedStyle,
          __hook__('#.', content, ['firstChild'], __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[35])
        ]
      ], __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[35]);
    }
    // Note, it's important that ShadyCSS gets the template that `lit-html`
    // will actually render so that it can update the style inside when
    // needed (e.g. @apply native Shadow DOM case).
    __hook__('#()', __hook__('#.', $hook$.global(__hook__, __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[35], 'window', '#get')[__b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[39]], ['ShadyCSS'], __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[35]), [
      'prepareTemplateStyles',
      [
        templateElement,
        scopeName
      ]
    ], __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[35]);
    const style = __hook__('#()', content, [
      'querySelector',
      ['style']
    ], __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[42]);
    if (__hook__('#.', __hook__('#.', $hook$.global(__hook__, __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[35], 'window', '#get')[__b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[39]], ['ShadyCSS'], __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[35]), ['nativeShadow'], __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[35]) && style !== null) {
      // When in native Shadow DOM, ensure the style created by ShadyCSS is
      // included in initially rendered output (`renderedDOM`).
      __hook__('#()', renderedDOM, [
        'insertBefore',
        [
          __hook__('#()', style, [
            'cloneNode',
            [true]
          ], __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[35]),
          __hook__('#.', renderedDOM, ['firstChild'], __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[35])
        ]
      ], __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[35]);
    } else if (!!template) {
      // When no style is left in the template, parts will be broken as a
      // result. To fix this, we put back the style node ShadyCSS removed
      // and then tell lit to remove that node from the template.
      // There can be no style in the template in 2 cases (1) when Shady DOM
      // is in use, ShadyCSS removes all styles, (2) when native Shadow DOM
      // is in use ShadyCSS removes the style if it contains no content.
      // NOTE, ShadyCSS creates its own style so we can safely add/remove
      // `condensedStyle` here.
      __hook__('#()', content, [
        'insertBefore',
        [
          condensedStyle,
          __hook__('#.', content, ['firstChild'], __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[35])
        ]
      ], __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[35]);
      const removes = __hook__($hook$.global(__hook__, __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[45], 'Set', '#get')[__b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[46]], null, [], __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[45], true);
      __hook__('#()', removes, [
        'add',
        [condensedStyle]
      ], __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[35]);
      __hook__('m()', removeNodesFromTemplate, [
        __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[32],
        [
          template,
          removes
        ],
        (...args) => removeNodesFromTemplate(...args)
      ], __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[35], null);
    }
  }, null, args, __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[35]));
/**
 * Extension to the standard `render` method which supports rendering
 * to ShadowRoots when the ShadyDOM (https://github.com/webcomponents/shadydom)
 * and ShadyCSS (https://github.com/webcomponents/shadycss) polyfills are used
 * or when the webcomponentsjs
 * (https://github.com/webcomponents/webcomponentsjs) polyfill is used.
 *
 * Adds a `scopeName` option which is used to scope element DOM and stylesheets
 * when native ShadowDOM is unavailable. The `scopeName` will be added to
 * the class attribute of all rendered DOM. In addition, any style elements will
 * be automatically re-written with this `scopeName` selector and moved out
 * of the rendered DOM and into the document `<head>`.
 *
 * It is common to use this render method in conjunction with a custom element
 * which renders a shadowRoot. When this is done, typically the element's
 * `localName` should be used as the `scopeName`.
 *
 * In addition to DOM scoping, ShadyCSS also supports a basic shim for css
 * custom properties (needed only on older browsers like IE11) and a shim for
 * a deprecated feature called `@apply` that supports applying a set of css
 * custom properties to a given location.
 *
 * Usage considerations:
 *
 * * Part values in `<style>` elements are only applied the first time a given
 * `scopeName` renders. Subsequent changes to parts in style elements will have
 * no effect. Because of this, parts in style elements should only be used for
 * values that will never change, for example parts that set scope-wide theme
 * values or parts which render shared style elements.
 *
 * * Note, due to a limitation of the ShadyDOM polyfill, rendering in a
 * custom element's `constructor` is not supported. Instead rendering should
 * either done asynchronously, for example at microtask timing (for example
 * `Promise.resolve()`), or be deferred until the first time the element's
 * `connectedCallback` runs.
 *
 * Usage considerations when using shimmed custom properties or `@apply`:
 *
 * * Whenever any dynamic changes are made which affect
 * css custom properties, `ShadyCSS.styleElement(element)` must be called
 * to update the element. There are two cases when this is needed:
 * (1) the element is connected to a new parent, (2) a class is added to the
 * element that causes it to match different custom properties.
 * To address the first case when rendering a custom element, `styleElement`
 * should be called in the element's `connectedCallback`.
 *
 * * Shimmed custom properties may only be defined either for an entire
 * shadowRoot (for example, in a `:host` rule) or via a rule that directly
 * matches an element with a shadowRoot. In other words, instead of flowing from
 * parent to child as do native css custom properties, shimmed custom properties
 * flow only from shadowRoots to nested shadowRoots.
 *
 * * When using `@apply` mixing css shorthand property names with
 * non-shorthand names (for example `border` and `border-width`) is not
 * supported.
 */
const render$1 = (...args) =>
  (__hook__((result, container, options) => {
    if (!options || typeof options !== 'object' || !__hook__('#.', options, ['scopeName'], __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[47])) {
      throw __hook__($hook$.global(__hook__, __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[47], 'Error', '#get')[__b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[48]], null, ['The `scopeName` option is required.'], __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[47], true);
    }
    const scopeName = __hook__('#.', options, ['scopeName'], __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[49]);
    const hasRendered = __hook__('#()', __hook__('m', parts, [__b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[51]], __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[50], null), [
      'has',
      [container]
    ], __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[50]);
    const needsScoping = compatibleShadyCSSVersion && __hook__('#.', container, ['nodeType'], __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[52]) === 11  /* Node.DOCUMENT_FRAGMENT_NODE */ && !!__hook__('#.', container, ['host'], __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[52]);
    // Handle first render to a scope specially...
    const firstScopeRender = needsScoping && !__hook__('#()', shadyRenderSet, [
      'has',
      [scopeName]
    ], __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[53]);
    // On first scope render, render into a fragment; this cannot be a single
    // fragment that is reused since nested renders can occur synchronously.
    const renderContainer = firstScopeRender ? __hook__('#()', $hook$.global(__hook__, __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[54], 'document', '#get')[__b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[55]], [
      'createDocumentFragment',
      []
    ], __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[54]) : container;
    __hook__('m()', render, [
      __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[56],
      [
        result,
        renderContainer,
        __hook__('#()', $hook$.global(__hook__, __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[47], 'Object', '#get')[__b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[57]], [
          'assign',
          [
            { templateFactory: __hook__(shadyTemplateFactory, null, [scopeName], __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[58], 0) },
            options
          ]
        ], __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[47])
      ],
      (...args) => render(...args)
    ], __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[47], null);
    // When performing first scope render,
    // (1) We've rendered into a fragment so that there's a chance to
    // `prepareTemplateStyles` before sub-elements hit the DOM
    // (which might cause them to render based on a common pattern of
    // rendering in a custom element's `connectedCallback`);
    // (2) Scope the template with ShadyCSS one time only for this scope.
    // (3) Render the fragment into the container and make sure the
    // container knows its `part` is the one we just rendered. This ensures
    // DOM will be re-used on subsequent renders.
    if (firstScopeRender) {
      const part = __hook__('#()', __hook__('m', parts, [__b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[51]], __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[59], null), [
        'get',
        [renderContainer]
      ], __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[59]);
      __hook__('#()', __hook__('m', parts, [__b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[51]], __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[47], null), [
        'delete',
        [renderContainer]
      ], __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[47]);
      // ShadyCSS might have style sheets (e.g. from `prepareAdoptedCssText`)
      // that should apply to `renderContainer` even if the rendered value is
      // not a TemplateInstance. However, it will only insert scoped styles
      // into the document if `prepareTemplateStyles` has already been called
      // for the given scope name.
      const template = __hook__('#.', part, ['value'], __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[60]) instanceof __hook__('m', TemplateInstance, [__b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[61]], __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[60], null) ? __hook__('#.', __hook__('#.', part, ['value'], __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[60]), ['template'], __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[60]) : $hook$.global(__hook__, __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[60], 'undefined', '#get')[__b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[62]];
      __hook__(prepareTemplateStyles, null, [
        scopeName,
        renderContainer,
        template
      ], __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[47], 0);
      __hook__('m()', removeNodes, [
        __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[63],
        [
          container,
          __hook__('#.', container, ['firstChild'], __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[47])
        ],
        (...args) => removeNodes(...args)
      ], __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[47], null);
      __hook__('#()', container, [
        'appendChild',
        [renderContainer]
      ], __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[47]);
      __hook__('#()', __hook__('m', parts, [__b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[51]], __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[47], null), [
        'set',
        [
          container,
          part
        ]
      ], __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[47]);
    }
    // After elements have hit the DOM, update styling if this is the
    // initial render to this container.
    // This is needed whenever dynamic changes are made so it would be
    // safest to do every render; however, this would regress performance
    // so we leave it up to the user to call `ShadyCSS.styleElement`
    // for dynamic changes.
    if (!hasRendered && needsScoping) {
      __hook__('#()', __hook__('#.', $hook$.global(__hook__, __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[47], 'window', '#get')[__b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[64]], ['ShadyCSS'], __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[47]), [
        'styleElement',
        [__hook__('#.', container, ['host'], __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[47])]
      ], __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[47]);
    }
  }, null, args, __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[47]));  __hook__(() => {
}, null, [
  'export',
  __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[0],
  __90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__module_namespace_1
], __b1c5a9766bcd967bd30676903b4dc75a84f7b63ef574f4cf9d72dfa2acced099__[0], NaN);

/**
 * @license
 * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
 * This code may only be used under the BSD style license found at
 * http://polymer.github.io/LICENSE.txt
 * The complete set of authors may be found at
 * http://polymer.github.io/AUTHORS.txt
 * The complete set of contributors may be found at
 * http://polymer.github.io/CONTRIBUTORS.txt
 * Code distributed by Google as part of the polymer project is also
 * subject to an additional IP rights grant found at
 * http://polymer.github.io/PATENTS.txt
 */
const __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__ = $hook$.$(__hook__, [
  '/components/thin-hook/demo/node_modules/lit-element/lib/updating-element.js',
  '/components/thin-hook/demo/node_modules/lit-element/lib/updating-element.js,defaultConverter,toAttribute',
  'S_uNpREdiC4aB1e_Boolean;/components/thin-hook/demo/node_modules/lit-element/lib/updating-element.js,defaultConverter,toAttribute',
  'S_uNpREdiC4aB1e_Object;/components/thin-hook/demo/node_modules/lit-element/lib/updating-element.js,defaultConverter,toAttribute',
  'S_uNpREdiC4aB1e_JSON;/components/thin-hook/demo/node_modules/lit-element/lib/updating-element.js,defaultConverter,toAttribute',
  'S_uNpREdiC4aB1e_Array;/components/thin-hook/demo/node_modules/lit-element/lib/updating-element.js,defaultConverter,toAttribute',
  '/components/thin-hook/demo/node_modules/lit-element/lib/updating-element.js,defaultConverter,fromAttribute',
  'S_uNpREdiC4aB1e_Boolean;/components/thin-hook/demo/node_modules/lit-element/lib/updating-element.js,defaultConverter,fromAttribute',
  'S_uNpREdiC4aB1e_Number;/components/thin-hook/demo/node_modules/lit-element/lib/updating-element.js,defaultConverter,fromAttribute',
  'S_uNpREdiC4aB1e_Object;/components/thin-hook/demo/node_modules/lit-element/lib/updating-element.js,defaultConverter,fromAttribute',
  'S_uNpREdiC4aB1e_JSON;/components/thin-hook/demo/node_modules/lit-element/lib/updating-element.js,defaultConverter,fromAttribute',
  'S_uNpREdiC4aB1e_Array;/components/thin-hook/demo/node_modules/lit-element/lib/updating-element.js,defaultConverter,fromAttribute',
  '/components/thin-hook/demo/node_modules/lit-element/lib/updating-element.js,notEqual',
  '/components/thin-hook/demo/node_modules/lit-element/lib/updating-element.js,defaultPropertyDeclaration,type',
  'S_uNpREdiC4aB1e_String;/components/thin-hook/demo/node_modules/lit-element/lib/updating-element.js,defaultPropertyDeclaration,type',
  '/components/thin-hook/demo/node_modules/lit-element/lib/updating-element.js,defaultPropertyDeclaration,converter',
  '/components/thin-hook/demo/node_modules/lit-element/lib/updating-element.js,defaultConverter',
  '/components/thin-hook/demo/node_modules/lit-element/lib/updating-element.js,defaultPropertyDeclaration,hasChanged',
  '/components/thin-hook/demo/node_modules/lit-element/lib/updating-element.js,UpdatingElement',
  'S_uNpREdiC4aB1e_HTMLElement;/components/thin-hook/demo/node_modules/lit-element/lib/updating-element.js,UpdatingElement',
  '/components/thin-hook/demo/node_modules/lit-element/lib/updating-element.js,UpdatingElement,constructor',
  'S_uNpREdiC4aB1e_undefined;/components/thin-hook/demo/node_modules/lit-element/lib/updating-element.js,UpdatingElement,constructor',
  'S_uNpREdiC4aB1e_Promise;/components/thin-hook/demo/node_modules/lit-element/lib/updating-element.js,UpdatingElement,constructor',
  'S_uNpREdiC4aB1e_Map;/components/thin-hook/demo/node_modules/lit-element/lib/updating-element.js,UpdatingElement,constructor',
  '/components/thin-hook/demo/node_modules/lit-element/lib/updating-element.js,UpdatingElement,get observedAttributes',
  '/components/thin-hook/demo/node_modules/lit-element/lib/updating-element.js,UpdatingElement,get observedAttributes,attr',
  'S_uNpREdiC4aB1e_undefined;/components/thin-hook/demo/node_modules/lit-element/lib/updating-element.js,UpdatingElement,get observedAttributes',
  '/components/thin-hook/demo/node_modules/lit-element/lib/updating-element.js,UpdatingElement,static _ensureClassProperties',
  'S_uNpREdiC4aB1e_JSCompiler_renameProperty;/components/thin-hook/demo/node_modules/lit-element/lib/updating-element.js,UpdatingElement,static _ensureClassProperties',
  'S_uNpREdiC4aB1e_Map;/components/thin-hook/demo/node_modules/lit-element/lib/updating-element.js,UpdatingElement,static _ensureClassProperties',
  '/components/thin-hook/demo/node_modules/lit-element/lib/updating-element.js,UpdatingElement,static _ensureClassProperties,superProperties',
  'S_uNpREdiC4aB1e_Object;/components/thin-hook/demo/node_modules/lit-element/lib/updating-element.js,UpdatingElement,static _ensureClassProperties,superProperties',
  'S_uNpREdiC4aB1e_undefined;/components/thin-hook/demo/node_modules/lit-element/lib/updating-element.js,UpdatingElement,static _ensureClassProperties',
  '/components/thin-hook/demo/node_modules/lit-element/lib/updating-element.js,UpdatingElement,static createProperty',
  '/components/thin-hook/demo/node_modules/lit-element/lib/updating-element.js,UpdatingElement,static createProperty,key',
  'S_uNpREdiC4aB1e_Symbol;/components/thin-hook/demo/node_modules/lit-element/lib/updating-element.js,UpdatingElement,static createProperty,key',
  '/components/thin-hook/demo/node_modules/lit-element/lib/updating-element.js,UpdatingElement,static createProperty,descriptor',
  'S_uNpREdiC4aB1e_undefined;/components/thin-hook/demo/node_modules/lit-element/lib/updating-element.js,UpdatingElement,static createProperty',
  'S_uNpREdiC4aB1e_Object;/components/thin-hook/demo/node_modules/lit-element/lib/updating-element.js,UpdatingElement,static createProperty',
  '/components/thin-hook/demo/node_modules/lit-element/lib/updating-element.js,UpdatingElement,static getPropertyDescriptor',
  '/components/thin-hook/demo/node_modules/lit-element/lib/updating-element.js,UpdatingElement,static getPropertyDescriptor,get',
  '/components/thin-hook/demo/node_modules/lit-element/lib/updating-element.js,UpdatingElement,static getPropertyDescriptor,set',
  '/components/thin-hook/demo/node_modules/lit-element/lib/updating-element.js,UpdatingElement,static getPropertyDescriptor,set,oldValue',
  '/components/thin-hook/demo/node_modules/lit-element/lib/updating-element.js,UpdatingElement,static getPropertyOptions',
  '/components/thin-hook/demo/node_modules/lit-element/lib/updating-element.js,UpdatingElement,static finalize',
  '/components/thin-hook/demo/node_modules/lit-element/lib/updating-element.js,UpdatingElement,static finalize,superCtor',
  'S_uNpREdiC4aB1e_Object;/components/thin-hook/demo/node_modules/lit-element/lib/updating-element.js,UpdatingElement,static finalize,superCtor',
  'S_uNpREdiC4aB1e_Map;/components/thin-hook/demo/node_modules/lit-element/lib/updating-element.js,UpdatingElement,static finalize',
  'S_uNpREdiC4aB1e_JSCompiler_renameProperty;/components/thin-hook/demo/node_modules/lit-element/lib/updating-element.js,UpdatingElement,static finalize',
  '/components/thin-hook/demo/node_modules/lit-element/lib/updating-element.js,UpdatingElement,static finalize,props',
  '/components/thin-hook/demo/node_modules/lit-element/lib/updating-element.js,UpdatingElement,static finalize,propKeys',
  'S_uNpREdiC4aB1e_Object;/components/thin-hook/demo/node_modules/lit-element/lib/updating-element.js,UpdatingElement,static finalize,propKeys',
  '/components/thin-hook/demo/node_modules/lit-element/lib/updating-element.js,UpdatingElement,static _attributeNameForProperty',
  '/components/thin-hook/demo/node_modules/lit-element/lib/updating-element.js,UpdatingElement,static _attributeNameForProperty,attribute',
  'S_uNpREdiC4aB1e_undefined;/components/thin-hook/demo/node_modules/lit-element/lib/updating-element.js,UpdatingElement,static _attributeNameForProperty',
  '/components/thin-hook/demo/node_modules/lit-element/lib/updating-element.js,UpdatingElement,static _valueHasChanged',
  '/components/thin-hook/demo/node_modules/lit-element/lib/updating-element.js,UpdatingElement,static _propertyValueFromAttribute',
  '/components/thin-hook/demo/node_modules/lit-element/lib/updating-element.js,UpdatingElement,static _propertyValueFromAttribute,type',
  '/components/thin-hook/demo/node_modules/lit-element/lib/updating-element.js,UpdatingElement,static _propertyValueFromAttribute,converter',
  '/components/thin-hook/demo/node_modules/lit-element/lib/updating-element.js,UpdatingElement,static _propertyValueFromAttribute,fromAttribute',
  '/components/thin-hook/demo/node_modules/lit-element/lib/updating-element.js,UpdatingElement,static _propertyValueToAttribute',
  'S_uNpREdiC4aB1e_undefined;/components/thin-hook/demo/node_modules/lit-element/lib/updating-element.js,UpdatingElement,static _propertyValueToAttribute',
  '/components/thin-hook/demo/node_modules/lit-element/lib/updating-element.js,UpdatingElement,static _propertyValueToAttribute,type',
  '/components/thin-hook/demo/node_modules/lit-element/lib/updating-element.js,UpdatingElement,static _propertyValueToAttribute,converter',
  '/components/thin-hook/demo/node_modules/lit-element/lib/updating-element.js,UpdatingElement,static _propertyValueToAttribute,toAttribute',
  '/components/thin-hook/demo/node_modules/lit-element/lib/updating-element.js,UpdatingElement,initialize',
  '/components/thin-hook/demo/node_modules/lit-element/lib/updating-element.js,UpdatingElement,_saveInstanceProperties',
  '/components/thin-hook/demo/node_modules/lit-element/lib/updating-element.js,UpdatingElement,_saveInstanceProperties,value',
  'S_uNpREdiC4aB1e_Map;/components/thin-hook/demo/node_modules/lit-element/lib/updating-element.js,UpdatingElement,_saveInstanceProperties',
  '/components/thin-hook/demo/node_modules/lit-element/lib/updating-element.js,UpdatingElement,_applyInstanceProperties',
  'S_uNpREdiC4aB1e_undefined;/components/thin-hook/demo/node_modules/lit-element/lib/updating-element.js,UpdatingElement,_applyInstanceProperties',
  '/components/thin-hook/demo/node_modules/lit-element/lib/updating-element.js,UpdatingElement,connectedCallback',
  '/components/thin-hook/demo/node_modules/lit-element/lib/updating-element.js,UpdatingElement,enableUpdating',
  'S_uNpREdiC4aB1e_undefined;/components/thin-hook/demo/node_modules/lit-element/lib/updating-element.js,UpdatingElement,enableUpdating',
  '/components/thin-hook/demo/node_modules/lit-element/lib/updating-element.js,UpdatingElement,disconnectedCallback',
  '/components/thin-hook/demo/node_modules/lit-element/lib/updating-element.js,UpdatingElement,attributeChangedCallback',
  '/components/thin-hook/demo/node_modules/lit-element/lib/updating-element.js,UpdatingElement,_propertyToAttribute',
  '/components/thin-hook/demo/node_modules/lit-element/lib/updating-element.js,UpdatingElement,_propertyToAttribute,ctor',
  '/components/thin-hook/demo/node_modules/lit-element/lib/updating-element.js,UpdatingElement,_propertyToAttribute,attr',
  'S_uNpREdiC4aB1e_undefined;/components/thin-hook/demo/node_modules/lit-element/lib/updating-element.js,UpdatingElement,_propertyToAttribute',
  '/components/thin-hook/demo/node_modules/lit-element/lib/updating-element.js,UpdatingElement,_propertyToAttribute,attrValue',
  '/components/thin-hook/demo/node_modules/lit-element/lib/updating-element.js,UpdatingElement,_attributeToProperty',
  '/components/thin-hook/demo/node_modules/lit-element/lib/updating-element.js,UpdatingElement,_attributeToProperty,ctor',
  '/components/thin-hook/demo/node_modules/lit-element/lib/updating-element.js,UpdatingElement,_attributeToProperty,propName',
  'S_uNpREdiC4aB1e_undefined;/components/thin-hook/demo/node_modules/lit-element/lib/updating-element.js,UpdatingElement,_attributeToProperty',
  '/components/thin-hook/demo/node_modules/lit-element/lib/updating-element.js,UpdatingElement,_attributeToProperty,options',
  '/components/thin-hook/demo/node_modules/lit-element/lib/updating-element.js,UpdatingElement,_requestUpdate',
  'S_uNpREdiC4aB1e_undefined;/components/thin-hook/demo/node_modules/lit-element/lib/updating-element.js,UpdatingElement,_requestUpdate',
  '/components/thin-hook/demo/node_modules/lit-element/lib/updating-element.js,UpdatingElement,_requestUpdate,ctor',
  '/components/thin-hook/demo/node_modules/lit-element/lib/updating-element.js,UpdatingElement,_requestUpdate,options',
  'S_uNpREdiC4aB1e_Map;/components/thin-hook/demo/node_modules/lit-element/lib/updating-element.js,UpdatingElement,_requestUpdate',
  '/components/thin-hook/demo/node_modules/lit-element/lib/updating-element.js,UpdatingElement,requestUpdate',
  '/components/thin-hook/demo/node_modules/lit-element/lib/updating-element.js,UpdatingElement,_enqueueUpdate',
  '/components/thin-hook/demo/node_modules/lit-element/lib/updating-element.js,UpdatingElement,_enqueueUpdate,result',
  '/components/thin-hook/demo/node_modules/lit-element/lib/updating-element.js,UpdatingElement,get _hasRequestedUpdate',
  '/components/thin-hook/demo/node_modules/lit-element/lib/updating-element.js,UpdatingElement,get hasUpdated',
  '/components/thin-hook/demo/node_modules/lit-element/lib/updating-element.js,UpdatingElement,performUpdate',
  '/components/thin-hook/demo/node_modules/lit-element/lib/updating-element.js,UpdatingElement,performUpdate,changedProperties',
  '/components/thin-hook/demo/node_modules/lit-element/lib/updating-element.js,UpdatingElement,_markUpdated',
  'S_uNpREdiC4aB1e_Map;/components/thin-hook/demo/node_modules/lit-element/lib/updating-element.js,UpdatingElement,_markUpdated',
  '/components/thin-hook/demo/node_modules/lit-element/lib/updating-element.js,UpdatingElement,get updateComplete',
  '/components/thin-hook/demo/node_modules/lit-element/lib/updating-element.js,UpdatingElement,_getUpdateComplete',
  '/components/thin-hook/demo/node_modules/lit-element/lib/updating-element.js,UpdatingElement,shouldUpdate',
  '/components/thin-hook/demo/node_modules/lit-element/lib/updating-element.js,UpdatingElement,update',
  'S_uNpREdiC4aB1e_undefined;/components/thin-hook/demo/node_modules/lit-element/lib/updating-element.js,UpdatingElement,update',
  '/components/thin-hook/demo/node_modules/lit-element/lib/updating-element.js,UpdatingElement,updated',
  '/components/thin-hook/demo/node_modules/lit-element/lib/updating-element.js,UpdatingElement,firstUpdated'
]);
var _a;
/**
 * When using Closure Compiler, JSCompiler_renameProperty(property, object) is
 * replaced at compile time by the munged name for object[property]. We cannot
 * alias this function, so we have to use a small shim that has the same
 * behavior when not compiling.
 */
__hook__('#=', window, [
  'JSCompiler_renameProperty',
  (...args) => __hook__((prop, _obj) => prop, null, args, __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[0])
], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[0]);
const defaultConverter = {
  toAttribute(value, type) {
    return __hook__((value, type) => {
      switch (type) {
      case $hook$.global(__hook__, __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[1], 'Boolean', '#get')[__da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[2]]:
        return value ? '' : null;
      case $hook$.global(__hook__, __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[1], 'Object', '#get')[__da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[3]]:
      case $hook$.global(__hook__, __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[1], 'Array', '#get')[__da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[5]]:
        // if the value is `null` or `undefined` pass this through
        // to allow removing/no change behavior.
        return value == null ? value : __hook__('#()', $hook$.global(__hook__, __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[1], 'JSON', '#get')[__da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[4]], [
          'stringify',
          [value]
        ], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[1]);
      }
      return value;
    }, null, arguments, __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[1]);
  },
  fromAttribute(value, type) {
    return __hook__((value, type) => {
      switch (type) {
      case $hook$.global(__hook__, __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[6], 'Boolean', '#get')[__da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[7]]:
        return value !== null;
      case $hook$.global(__hook__, __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[6], 'Number', '#get')[__da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[8]]:
        return value === null ? null : __hook__($hook$.global(__hook__, __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[6], 'Number', '#get')[__da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[8]], null, [value], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[6], 0);
      case $hook$.global(__hook__, __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[6], 'Object', '#get')[__da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[9]]:
      case $hook$.global(__hook__, __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[6], 'Array', '#get')[__da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[11]]:
        return __hook__('#()', $hook$.global(__hook__, __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[6], 'JSON', '#get')[__da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[10]], [
          'parse',
          [value]
        ], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[6]);
      }
      return value;
    }, null, arguments, __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[6]);
  }
};
/**
 * Change function that returns true if `value` is different from `oldValue`.
 * This method is used as the default for a property's `hasChanged` function.
 */
const notEqual = (...args) =>
  (__hook__((value, old) => {
    // This ensures (old==NaN, value==NaN) always returns false
    return old !== value && (old === old || value === value);
  }, null, args, __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[12]));
const defaultPropertyDeclaration = {
  attribute: true,
  type: $hook$.global(__hook__, __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[13], 'String', '#get')[__da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[14]],
  converter: __hook__('m', defaultConverter, [__da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[16]], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[15], null),
  reflect: false,
  hasChanged: __hook__('m', notEqual, [__da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[12]], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[17], null)
};
const STATE_HAS_UPDATED = 1;
const STATE_UPDATE_REQUESTED = 1 << 2;
const STATE_IS_REFLECTING_TO_ATTRIBUTE = 1 << 3;
const STATE_IS_REFLECTING_TO_PROPERTY = 1 << 4;
/**
 * The Closure JS Compiler doesn't currently have good support for static
 * property semantics where "this" is dynamic (e.g.
 * https://github.com/google/closure-compiler/issues/3177 and others) so we use
 * this hack to bypass any rewriting by the compiler.
 */
const finalized = 'finalized';
/**
 * Base element class which manages element properties and attributes. When
 * properties change, the `update` method is asynchronously called. This method
 * should be supplied by subclassers to render updates as desired.
 */
class UpdatingElement extends $hook$.global(__hook__, __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[18], 'HTMLElement', '#get')[__da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[19]] {
  constructor() {
    return __hook__(() => {
      __hook__((newTarget, ...args) => super(...args), null, [new.target], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[20], '');
      __hook__('#=', this, [
        '_updateState',
        0
      ], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[20]);
      __hook__('#=', this, [
        '_instanceProperties',
        $hook$.global(__hook__, __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[20], 'undefined', '#get')[__da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[21]]
      ], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[20]);
      // Initialize to an unresolved Promise so we can make sure the element has
      // connected before first update.
      __hook__('#=', this, [
        '_updatePromise',
        __hook__($hook$.global(__hook__, __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[20], 'Promise', '#get')[__da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[22]], null, [(...args) => __hook__(res => __hook__('#=', this, [
            '_enableUpdatingResolver',
            res
          ], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[20]), null, args, __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[20])], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[20], true)
      ], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[20]);
      /**
         * Map with keys for any properties that have changed since the last
         * update cycle with previous values.
         */
      __hook__('#=', this, [
        '_changedProperties',
        __hook__($hook$.global(__hook__, __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[20], 'Map', '#get')[__da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[23]], null, [], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[20], true)
      ], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[20]);
      /**
         * Map with keys of properties that should be reflected when updated.
         */
      __hook__('#=', this, [
        '_reflectingProperties',
        $hook$.global(__hook__, __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[20], 'undefined', '#get')[__da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[21]]
      ], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[20]);
      __hook__('#()', this, [
        'initialize',
        []
      ], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[20]);
    }, null, arguments, __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[20]);
  }
  /**
     * Returns a list of attributes corresponding to the registered properties.
     * @nocollapse
     */
  static get observedAttributes() {
    return __hook__(() => {
      // note: piggy backing on this to ensure we're finalized.
      __hook__('#()', this, [
        'finalize',
        []
      ], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[24]);
      const attributes = [];
      // Use forEach so this works even if for/of loops are compiled to for loops
      // expecting arrays
      __hook__('#()', __hook__('#.', this, ['_classProperties'], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[24]), [
        'forEach',
        [(...args) =>
            (__hook__((v, p) => {
              const attr = __hook__('#()', this, [
                '_attributeNameForProperty',
                [
                  p,
                  v
                ]
              ], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[25]);
              if (attr !== $hook$.global(__hook__, __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[24], 'undefined', '#get')[__da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[26]]) {
                __hook__('#()', __hook__('#.', this, ['_attributeToPropertyMap'], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[24]), [
                  'set',
                  [
                    attr,
                    p
                  ]
                ], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[24]);
                __hook__('#()', attributes, [
                  'push',
                  [attr]
                ], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[24]);
              }
            }, null, args, __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[24]))]
      ], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[24]);
      return attributes;
    }, null, arguments, __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[24]);
  }
  /**
     * Ensures the private `_classProperties` property metadata is created.
     * In addition to `finalize` this is also called in `createProperty` to
     * ensure the `@property` decorator can add property metadata.
     */
  /** @nocollapse */
  static _ensureClassProperties() {
    return __hook__(() => {
      // ensure private storage for property declarations.
      if (!__hook__('#()', this, [
          'hasOwnProperty',
          [__hook__($hook$.global(__hook__, __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[27], 'JSCompiler_renameProperty', '#get')[__da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[28]], null, [
              '_classProperties',
              this
            ], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[27], 0)]
        ], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[27])) {
        __hook__('#=', this, [
          '_classProperties',
          __hook__($hook$.global(__hook__, __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[27], 'Map', '#get')[__da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[29]], null, [], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[27], true)
        ], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[27]);
        // NOTE: Workaround IE11 not supporting Map constructor argument.
        const superProperties = __hook__('#.', __hook__('#()', $hook$.global(__hook__, __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[30], 'Object', '#get')[__da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[31]], [
          'getPrototypeOf',
          [this]
        ], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[30]), ['_classProperties'], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[30]);
        if (superProperties !== $hook$.global(__hook__, __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[27], 'undefined', '#get')[__da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[32]]) {
          __hook__('#()', superProperties, [
            'forEach',
            [(...args) => __hook__((v, k) => __hook__('#()', __hook__('#.', this, ['_classProperties'], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[27]), [
                'set',
                [
                  k,
                  v
                ]
              ], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[27]), null, args, __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[27])]
          ], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[27]);
        }
      }
    }, null, arguments, __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[27]);
  }
  /**
     * Creates a property accessor on the element prototype if one does not exist
     * and stores a PropertyDeclaration for the property with the given options.
     * The property setter calls the property's `hasChanged` property option
     * or uses a strict identity check to determine whether or not to request
     * an update.
     *
     * This method may be overridden to customize properties; however,
     * when doing so, it's important to call `super.createProperty` to ensure
     * the property is setup correctly. This method calls
     * `getPropertyDescriptor` internally to get a descriptor to install.
     * To customize what properties do when they are get or set, override
     * `getPropertyDescriptor`. To customize the options for a property,
     * implement `createProperty` like this:
     *
     * static createProperty(name, options) {
     *   options = Object.assign(options, {myOption: true});
     *   super.createProperty(name, options);
     * }
     *
     * @nocollapse
     */
  static createProperty(name, options) {
    return __hook__((name, options = defaultPropertyDeclaration) => {
      // Note, since this can be called by the `@property` decorator which
      // is called before `finalize`, we ensure storage exists for property
      // metadata.
      __hook__('#()', this, [
        '_ensureClassProperties',
        []
      ], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[33]);
      __hook__('#()', __hook__('#.', this, ['_classProperties'], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[33]), [
        'set',
        [
          name,
          options
        ]
      ], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[33]);
      // Do not generate an accessor if the prototype already has one, since
      // it would be lost otherwise and that would never be the user's intention;
      // Instead, we expect users to call `requestUpdate` themselves from
      // user-defined accessors. Note that if the super has an accessor we will
      // still overwrite it
      if (__hook__('#.', options, ['noAccessor'], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[33]) || __hook__('#()', __hook__('#.', this, ['prototype'], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[33]), [
          'hasOwnProperty',
          [name]
        ], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[33])) {
        return;
      }
      const key = typeof name === 'symbol' ? __hook__($hook$.global(__hook__, __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[34], 'Symbol', '#get')[__da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[35]], null, [], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[34], 0) : `__${ name }`;
      const descriptor = __hook__('#()', this, [
        'getPropertyDescriptor',
        [
          name,
          key,
          options
        ]
      ], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[36]);
      if (descriptor !== $hook$.global(__hook__, __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[33], 'undefined', '#get')[__da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[37]]) {
        __hook__('#()', $hook$.global(__hook__, __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[33], 'Object', '#get')[__da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[38]], [
          'defineProperty',
          [
            __hook__('#.', this, ['prototype'], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[33]),
            name,
            descriptor
          ]
        ], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[33]);
      }
    }, null, arguments, __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[33]);
  }
  /**
     * Returns a property descriptor to be defined on the given named property.
     * If no descriptor is returned, the property will not become an accessor.
     * For example,
     *
     *   class MyElement extends LitElement {
     *     static getPropertyDescriptor(name, key, options) {
     *       const defaultDescriptor =
     *           super.getPropertyDescriptor(name, key, options);
     *       const setter = defaultDescriptor.set;
     *       return {
     *         get: defaultDescriptor.get,
     *         set(value) {
     *           setter.call(this, value);
     *           // custom action.
     *         },
     *         configurable: true,
     *         enumerable: true
     *       }
     *     }
     *   }
     *
     * @nocollapse
     */
  static getPropertyDescriptor(name, key, _options) {
    return __hook__((name, key, _options) => {
      return {
        // tslint:disable-next-line:no-any no symbol in index
        get() {
          return __hook__(() => {
            return __hook__('#.', this, [key], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[40]);
          }, null, arguments, __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[40]);
        },
        set(value) {
          return __hook__(value => {
            const oldValue = __hook__('#.', this, [name], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[42]);
            __hook__('#=', this, [
              key,
              value
            ], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[41]);
            __hook__('#()', this, [
              '_requestUpdate',
              [
                name,
                oldValue
              ]
            ], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[41]);
          }, null, arguments, __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[41]);
        },
        configurable: true,
        enumerable: true
      };
    }, null, arguments, __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[39]);
  }
  /**
     * Returns the property options associated with the given property.
     * These options are defined with a PropertyDeclaration via the `properties`
     * object or the `@property` decorator and are registered in
     * `createProperty(...)`.
     *
     * Note, this method should be considered "final" and not overridden. To
     * customize the options for a given property, override `createProperty`.
     *
     * @nocollapse
     * @final
     */
  static getPropertyOptions(name) {
    return __hook__(name => {
      return __hook__('#.', this, ['_classProperties'], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[43]) && __hook__('#()', __hook__('#.', this, ['_classProperties'], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[43]), [
        'get',
        [name]
      ], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[43]) || defaultPropertyDeclaration;
    }, null, arguments, __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[43]);
  }
  /**
     * Creates property accessors for registered properties and ensures
     * any superclasses are also finalized.
     * @nocollapse
     */
  static finalize() {
    return __hook__(() => {
      // finalize any superclasses
      const superCtor = __hook__('#()', $hook$.global(__hook__, __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[45], 'Object', '#get')[__da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[46]], [
        'getPrototypeOf',
        [this]
      ], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[45]);
      if (!__hook__('#()', superCtor, [
          'hasOwnProperty',
          [finalized]
        ], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[44])) {
        __hook__('#()', superCtor, [
          'finalize',
          []
        ], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[44]);
      }
      __hook__('#=', this, [
        finalized,
        true
      ], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[44]);
      __hook__('#()', this, [
        '_ensureClassProperties',
        []
      ], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[44]);
      // initialize Map populated in observedAttributes
      __hook__('#=', this, [
        '_attributeToPropertyMap',
        __hook__($hook$.global(__hook__, __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[44], 'Map', '#get')[__da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[47]], null, [], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[44], true)
      ], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[44]);
      // make any properties
      // Note, only process "own" properties since this element will inherit
      // any properties defined on the superClass, and finalization ensures
      // the entire prototype chain is finalized.
      if (__hook__('#()', this, [
          'hasOwnProperty',
          [__hook__($hook$.global(__hook__, __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[44], 'JSCompiler_renameProperty', '#get')[__da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[48]], null, [
              'properties',
              this
            ], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[44], 0)]
        ], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[44])) {
        const props = __hook__('#.', this, ['properties'], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[49]);
        // support symbols in properties (IE11 does not support this)
        const propKeys = [
          ...__hook__('#()', $hook$.global(__hook__, __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[50], 'Object', '#get')[__da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[51]], [
            'getOwnPropertyNames',
            [props]
          ], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[50]),
          ...typeof __hook__('#.', $hook$.global(__hook__, __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[50], 'Object', '#get')[__da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[51]], ['getOwnPropertySymbols'], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[50]) === 'function' ? __hook__('#()', $hook$.global(__hook__, __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[50], 'Object', '#get')[__da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[51]], [
            'getOwnPropertySymbols',
            [props]
          ], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[50]) : []
        ];
        // This for/of is ok because propKeys is an array
        for (const p of __hook__('#*', propKeys, [], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[44])) {
          // note, use of `any` is due to TypeSript lack of support for symbol in
          // index types
          // tslint:disable-next-line:no-any no symbol in index
          __hook__('#()', this, [
            'createProperty',
            [
              p,
              __hook__('#.', props, [p], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[44])
            ]
          ], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[44]);
        }
      }
    }, null, arguments, __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[44]);
  }
  /**
     * Returns the property name for the given attribute `name`.
     * @nocollapse
     */
  static _attributeNameForProperty(name, options) {
    return __hook__((name, options) => {
      const attribute = __hook__('#.', options, ['attribute'], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[53]);
      return attribute === false ? $hook$.global(__hook__, __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[52], 'undefined', '#get')[__da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[54]] : typeof attribute === 'string' ? attribute : typeof name === 'string' ? __hook__('#()', name, [
        'toLowerCase',
        []
      ], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[52]) : $hook$.global(__hook__, __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[52], 'undefined', '#get')[__da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[54]];
    }, null, arguments, __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[52]);
  }
  /**
     * Returns true if a property should request an update.
     * Called when a property value is set and uses the `hasChanged`
     * option for the property if present or a strict identity check.
     * @nocollapse
     */
  static _valueHasChanged(value, old, hasChanged) {
    return __hook__((value, old, hasChanged = __hook__('m', notEqual, [__da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[12]], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[55], null)) => {
      return __hook__(hasChanged, null, [
        value,
        old
      ], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[55], 0);
    }, null, arguments, __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[55]);
  }
  /**
     * Returns the property value for the given attribute value.
     * Called via the `attributeChangedCallback` and uses the property's
     * `converter` or `converter.fromAttribute` property option.
     * @nocollapse
     */
  static _propertyValueFromAttribute(value, options) {
    return __hook__((value, options) => {
      const type = __hook__('#.', options, ['type'], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[57]);
      const converter = __hook__('#.', options, ['converter'], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[58]) || __hook__('m', defaultConverter, [__da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[16]], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[58], null);
      const fromAttribute = typeof converter === 'function' ? converter : __hook__('#.', converter, ['fromAttribute'], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[59]);
      return fromAttribute ? __hook__(fromAttribute, null, [
        value,
        type
      ], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[56], 0) : value;
    }, null, arguments, __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[56]);
  }
  /**
     * Returns the attribute value for the given property value. If this
     * returns undefined, the property will *not* be reflected to an attribute.
     * If this returns null, the attribute will be removed, otherwise the
     * attribute will be set to the value.
     * This uses the property's `reflect` and `type.toAttribute` property options.
     * @nocollapse
     */
  static _propertyValueToAttribute(value, options) {
    return __hook__((value, options) => {
      if (__hook__('#.', options, ['reflect'], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[60]) === $hook$.global(__hook__, __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[60], 'undefined', '#get')[__da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[61]]) {
        return;
      }
      const type = __hook__('#.', options, ['type'], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[62]);
      const converter = __hook__('#.', options, ['converter'], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[63]);
      const toAttribute = converter && __hook__('#.', converter, ['toAttribute'], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[64]) || __hook__('#.', __hook__('m', defaultConverter, [__da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[16]], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[64], null), ['toAttribute'], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[64]);
      return __hook__(toAttribute, null, [
        value,
        type
      ], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[60], 0);
    }, null, arguments, __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[60]);
  }
  /**
     * Performs element initialization. By default captures any pre-set values for
     * registered properties.
     */
  initialize() {
    return __hook__(() => {
      __hook__('#()', this, [
        '_saveInstanceProperties',
        []
      ], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[65]);
      // ensures first update will be caught by an early access of
      // `updateComplete`
      __hook__('#()', this, [
        '_requestUpdate',
        []
      ], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[65]);
    }, null, arguments, __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[65]);
  }
  /**
     * Fixes any properties set on the instance before upgrade time.
     * Otherwise these would shadow the accessor and break these properties.
     * The properties are stored in a Map which is played back after the
     * constructor runs. Note, on very old versions of Safari (<=9) or Chrome
     * (<=41), properties created for native platform properties like (`id` or
     * `name`) may not have default values set in the element constructor. On
     * these browsers native properties appear on instances and therefore their
     * default value will overwrite any element default (e.g. if the element sets
     * this.id = 'id' in the constructor, the 'id' will become '' since this is
     * the native platform default).
     */
  _saveInstanceProperties() {
    return __hook__(() => {
      // Use forEach so this works even if for/of loops are compiled to for loops
      // expecting arrays
      __hook__('#()', __hook__('#.', __hook__('#.', this, ['constructor'], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[66]), ['_classProperties'], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[66]), [
        'forEach',
        [(...args) =>
            (__hook__((_v, p) => {
              if (__hook__('#()', this, [
                  'hasOwnProperty',
                  [p]
                ], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[66])) {
                const value = __hook__('#.', this, [p], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[67]);
                __hook__('#delete', this, [p], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[66]);
                if (!__hook__('#.', this, ['_instanceProperties'], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[66])) {
                  __hook__('#=', this, [
                    '_instanceProperties',
                    __hook__($hook$.global(__hook__, __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[66], 'Map', '#get')[__da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[68]], null, [], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[66], true)
                  ], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[66]);
                }
                __hook__('#()', __hook__('#.', this, ['_instanceProperties'], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[66]), [
                  'set',
                  [
                    p,
                    value
                  ]
                ], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[66]);
              }
            }, null, args, __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[66]))]
      ], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[66]);
    }, null, arguments, __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[66]);
  }
  /**
     * Applies previously saved instance properties.
     */
  _applyInstanceProperties() {
    return __hook__(() => {
      // Use forEach so this works even if for/of loops are compiled to for loops
      // expecting arrays
      // tslint:disable-next-line:no-any
      __hook__('#()', __hook__('#.', this, ['_instanceProperties'], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[69]), [
        'forEach',
        [(...args) => __hook__((v, p) => __hook__('#=', this, [
            p,
            v
          ], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[69]), null, args, __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[69])]
      ], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[69]);
      __hook__('#=', this, [
        '_instanceProperties',
        $hook$.global(__hook__, __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[69], 'undefined', '#get')[__da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[70]]
      ], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[69]);
    }, null, arguments, __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[69]);
  }
  connectedCallback() {
    return __hook__(() => {
      // Ensure first connection completes an update. Updates cannot complete
      // before connection.
      __hook__('#()', this, [
        'enableUpdating',
        []
      ], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[71]);
    }, null, arguments, __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[71]);
  }
  enableUpdating() {
    return __hook__(() => {
      if (__hook__('#.', this, ['_enableUpdatingResolver'], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[72]) !== $hook$.global(__hook__, __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[72], 'undefined', '#get')[__da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[73]]) {
        __hook__('#()', this, [
          '_enableUpdatingResolver',
          []
        ], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[72]);
        __hook__('#=', this, [
          '_enableUpdatingResolver',
          $hook$.global(__hook__, __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[72], 'undefined', '#get')[__da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[73]]
        ], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[72]);
      }
    }, null, arguments, __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[72]);
  }
  /**
     * Allows for `super.disconnectedCallback()` in extensions while
     * reserving the possibility of making non-breaking feature additions
     * when disconnecting at some point in the future.
     */
  disconnectedCallback() {
    return __hook__(() => {
    }, null, arguments, __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[74]);
  }
  /**
     * Synchronizes property values when attributes change.
     */
  attributeChangedCallback(name, old, value) {
    return __hook__((name, old, value) => {
      if (old !== value) {
        __hook__('#()', this, [
          '_attributeToProperty',
          [
            name,
            value
          ]
        ], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[75]);
      }
    }, null, arguments, __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[75]);
  }
  _propertyToAttribute(name, value, options) {
    return __hook__((name, value, options = defaultPropertyDeclaration) => {
      const ctor = __hook__('#.', this, ['constructor'], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[77]);
      const attr = __hook__('#()', ctor, [
        '_attributeNameForProperty',
        [
          name,
          options
        ]
      ], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[78]);
      if (attr !== $hook$.global(__hook__, __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[76], 'undefined', '#get')[__da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[79]]) {
        const attrValue = __hook__('#()', ctor, [
          '_propertyValueToAttribute',
          [
            value,
            options
          ]
        ], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[80]);
        // an undefined value does not change the attribute.
        if (attrValue === $hook$.global(__hook__, __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[76], 'undefined', '#get')[__da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[79]]) {
          return;
        }
        // Track if the property is being reflected to avoid
        // setting the property again via `attributeChangedCallback`. Note:
        // 1. this takes advantage of the fact that the callback is synchronous.
        // 2. will behave incorrectly if multiple attributes are in the reaction
        // stack at time of calling. However, since we process attributes
        // in `update` this should not be possible (or an extreme corner case
        // that we'd like to discover).
        // mark state reflecting
        __hook__('#=', this, [
          '_updateState',
          __hook__('#.', this, ['_updateState'], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[76]) | STATE_IS_REFLECTING_TO_ATTRIBUTE
        ], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[76]);
        if (attrValue == null) {
          __hook__('#()', this, [
            'removeAttribute',
            [attr]
          ], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[76]);
        } else {
          __hook__('#()', this, [
            'setAttribute',
            [
              attr,
              attrValue
            ]
          ], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[76]);
        }
        // mark state not reflecting
        __hook__('#=', this, [
          '_updateState',
          __hook__('#.', this, ['_updateState'], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[76]) & ~STATE_IS_REFLECTING_TO_ATTRIBUTE
        ], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[76]);
      }
    }, null, arguments, __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[76]);
  }
  _attributeToProperty(name, value) {
    return __hook__((name, value) => {
      // Use tracking info to avoid deserializing attribute value if it was
      // just set from a property setter.
      if (__hook__('#.', this, ['_updateState'], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[81]) & STATE_IS_REFLECTING_TO_ATTRIBUTE) {
        return;
      }
      const ctor = __hook__('#.', this, ['constructor'], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[82]);
      // Note, hint this as an `AttributeMap` so closure clearly understands
      // the type; it has issues with tracking types through statics
      // tslint:disable-next-line:no-unnecessary-type-assertion
      const propName = __hook__('#()', __hook__('#.', ctor, ['_attributeToPropertyMap'], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[83]), [
        'get',
        [name]
      ], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[83]);
      if (propName !== $hook$.global(__hook__, __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[81], 'undefined', '#get')[__da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[84]]) {
        const options = __hook__('#()', ctor, [
          'getPropertyOptions',
          [propName]
        ], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[85]);
        // mark state reflecting
        __hook__('#=', this, [
          '_updateState',
          __hook__('#.', this, ['_updateState'], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[81]) | STATE_IS_REFLECTING_TO_PROPERTY
        ], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[81]);
        __hook__('#=', this, [
          propName,
          // tslint:disable-next-line:no-any
          __hook__('#()', ctor, [
            '_propertyValueFromAttribute',
            [
              value,
              options
            ]
          ], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[81])
        ], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[81]);
        // mark state not reflecting
        __hook__('#=', this, [
          '_updateState',
          __hook__('#.', this, ['_updateState'], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[81]) & ~STATE_IS_REFLECTING_TO_PROPERTY
        ], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[81]);
      }
    }, null, arguments, __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[81]);
  }
  /**
     * This private version of `requestUpdate` does not access or return the
     * `updateComplete` promise. This promise can be overridden and is therefore
     * not free to access.
     */
  _requestUpdate(name, oldValue) {
    return __hook__((name, oldValue) => {
      let shouldRequestUpdate = true;
      // If we have a property key, perform property update steps.
      if (name !== $hook$.global(__hook__, __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[86], 'undefined', '#get')[__da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[87]]) {
        const ctor = __hook__('#.', this, ['constructor'], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[88]);
        const options = __hook__('#()', ctor, [
          'getPropertyOptions',
          [name]
        ], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[89]);
        if (__hook__('#()', ctor, [
            '_valueHasChanged',
            [
              __hook__('#.', this, [name], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[86]),
              oldValue,
              __hook__('#.', options, ['hasChanged'], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[86])
            ]
          ], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[86])) {
          if (!__hook__('#()', __hook__('#.', this, ['_changedProperties'], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[86]), [
              'has',
              [name]
            ], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[86])) {
            __hook__('#()', __hook__('#.', this, ['_changedProperties'], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[86]), [
              'set',
              [
                name,
                oldValue
              ]
            ], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[86]);
          }
          // Add to reflecting properties set.
          // Note, it's important that every change has a chance to add the
          // property to `_reflectingProperties`. This ensures setting
          // attribute + property reflects correctly.
          if (__hook__('#.', options, ['reflect'], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[86]) === true && !(__hook__('#.', this, ['_updateState'], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[86]) & STATE_IS_REFLECTING_TO_PROPERTY)) {
            if (__hook__('#.', this, ['_reflectingProperties'], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[86]) === $hook$.global(__hook__, __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[86], 'undefined', '#get')[__da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[87]]) {
              __hook__('#=', this, [
                '_reflectingProperties',
                __hook__($hook$.global(__hook__, __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[86], 'Map', '#get')[__da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[90]], null, [], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[86], true)
              ], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[86]);
            }
            __hook__('#()', __hook__('#.', this, ['_reflectingProperties'], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[86]), [
              'set',
              [
                name,
                options
              ]
            ], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[86]);
          }
        } else {
          // Abort the request if the property should not be considered changed.
          shouldRequestUpdate = false;
        }
      }
      if (!__hook__('#.', this, ['_hasRequestedUpdate'], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[86]) && shouldRequestUpdate) {
        __hook__('#=', this, [
          '_updatePromise',
          __hook__('#()', this, [
            '_enqueueUpdate',
            []
          ], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[86])
        ], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[86]);
      }
    }, null, arguments, __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[86]);
  }
  /**
     * Requests an update which is processed asynchronously. This should
     * be called when an element should update based on some state not triggered
     * by setting a property. In this case, pass no arguments. It should also be
     * called when manually implementing a property setter. In this case, pass the
     * property `name` and `oldValue` to ensure that any configured property
     * options are honored. Returns the `updateComplete` Promise which is resolved
     * when the update completes.
     *
     * @param name {PropertyKey} (optional) name of requesting property
     * @param oldValue {any} (optional) old value of requesting property
     * @returns {Promise} A Promise that is resolved when the update completes.
     */
  requestUpdate(name, oldValue) {
    return __hook__((name, oldValue) => {
      __hook__('#()', this, [
        '_requestUpdate',
        [
          name,
          oldValue
        ]
      ], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[91]);
      return __hook__('#.', this, ['updateComplete'], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[91]);
    }, null, arguments, __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[91]);
  }
  /**
     * Sets up the element to asynchronously update.
     */
  async _enqueueUpdate() {
    return __hook__(async () => {
      __hook__('#=', this, [
        '_updateState',
        __hook__('#.', this, ['_updateState'], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[92]) | STATE_UPDATE_REQUESTED
      ], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[92]);
      try {
        // Ensure any previous update has resolved before updating.
        // This `await` also ensures that property changes are batched.
        await __hook__('#.', this, ['_updatePromise'], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[92]);
      } catch (e) {
      }
      const result = __hook__('#()', this, [
        'performUpdate',
        []
      ], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[93]);
      // If `performUpdate` returns a Promise, we await it. This is done to
      // enable coordinating updates with a scheduler. Note, the result is
      // checked to avoid delaying an additional microtask unless we need to.
      if (result != null) {
        await result;
      }
      return !__hook__('#.', this, ['_hasRequestedUpdate'], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[92]);
    }, null, arguments, __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[92]);
  }
  get _hasRequestedUpdate() {
    return __hook__(() => {
      return __hook__('#.', this, ['_updateState'], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[94]) & STATE_UPDATE_REQUESTED;
    }, null, arguments, __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[94]);
  }
  get hasUpdated() {
    return __hook__(() => {
      return __hook__('#.', this, ['_updateState'], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[95]) & STATE_HAS_UPDATED;
    }, null, arguments, __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[95]);
  }
  /**
     * Performs an element update. Note, if an exception is thrown during the
     * update, `firstUpdated` and `updated` will not be called.
     *
     * You can override this method to change the timing of updates. If this
     * method is overridden, `super.performUpdate()` must be called.
     *
     * For instance, to schedule updates to occur just before the next frame:
     *
     * ```
     * protected async performUpdate(): Promise<unknown> {
     *   await new Promise((resolve) => requestAnimationFrame(() => resolve()));
     *   super.performUpdate();
     * }
     * ```
     */
  performUpdate() {
    return __hook__(() => {
      // Mixin instance properties once, if they exist.
      if (__hook__('#.', this, ['_instanceProperties'], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[96])) {
        __hook__('#()', this, [
          '_applyInstanceProperties',
          []
        ], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[96]);
      }
      let shouldUpdate = false;
      const changedProperties = __hook__('#.', this, ['_changedProperties'], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[97]);
      try {
        shouldUpdate = __hook__('#()', this, [
          'shouldUpdate',
          [changedProperties]
        ], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[96]);
        if (shouldUpdate) {
          __hook__('#()', this, [
            'update',
            [changedProperties]
          ], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[96]);
        } else {
          __hook__('#()', this, [
            '_markUpdated',
            []
          ], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[96]);
        }
      } catch (e) {
        // Prevent `firstUpdated` and `updated` from running when there's an
        // update exception.
        shouldUpdate = false;
        // Ensure element can accept additional updates after an exception.
        __hook__('#()', this, [
          '_markUpdated',
          []
        ], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[96]);
        throw e;
      }
      if (shouldUpdate) {
        if (!(__hook__('#.', this, ['_updateState'], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[96]) & STATE_HAS_UPDATED)) {
          __hook__('#=', this, [
            '_updateState',
            __hook__('#.', this, ['_updateState'], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[96]) | STATE_HAS_UPDATED
          ], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[96]);
          __hook__('#()', this, [
            'firstUpdated',
            [changedProperties]
          ], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[96]);
        }
        __hook__('#()', this, [
          'updated',
          [changedProperties]
        ], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[96]);
      }
    }, null, arguments, __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[96]);
  }
  _markUpdated() {
    return __hook__(() => {
      __hook__('#=', this, [
        '_changedProperties',
        __hook__($hook$.global(__hook__, __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[98], 'Map', '#get')[__da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[99]], null, [], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[98], true)
      ], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[98]);
      __hook__('#=', this, [
        '_updateState',
        __hook__('#.', this, ['_updateState'], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[98]) & ~STATE_UPDATE_REQUESTED
      ], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[98]);
    }, null, arguments, __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[98]);
  }
  /**
     * Returns a Promise that resolves when the element has completed updating.
     * The Promise value is a boolean that is `true` if the element completed the
     * update without triggering another update. The Promise result is `false` if
     * a property was set inside `updated()`. If the Promise is rejected, an
     * exception was thrown during the update.
     *
     * To await additional asynchronous work, override the `_getUpdateComplete`
     * method. For example, it is sometimes useful to await a rendered element
     * before fulfilling this Promise. To do this, first await
     * `super._getUpdateComplete()`, then any subsequent state.
     *
     * @returns {Promise} The Promise returns a boolean that indicates if the
     * update resolved without triggering another update.
     */
  get updateComplete() {
    return __hook__(() => {
      return __hook__('#()', this, [
        '_getUpdateComplete',
        []
      ], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[100]);
    }, null, arguments, __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[100]);
  }
  /**
     * Override point for the `updateComplete` promise.
     *
     * It is not safe to override the `updateComplete` getter directly due to a
     * limitation in TypeScript which means it is not possible to call a
     * superclass getter (e.g. `super.updateComplete.then(...)`) when the target
     * language is ES5 (https://github.com/microsoft/TypeScript/issues/338).
     * This method should be overridden instead. For example:
     *
     *   class MyElement extends LitElement {
     *     async _getUpdateComplete() {
     *       await super._getUpdateComplete();
     *       await this._myChild.updateComplete;
     *     }
     *   }
     */
  _getUpdateComplete() {
    return __hook__(() => {
      return __hook__('#.', this, ['_updatePromise'], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[101]);
    }, null, arguments, __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[101]);
  }
  /**
     * Controls whether or not `update` should be called when the element requests
     * an update. By default, this method always returns `true`, but this can be
     * customized to control when to update.
     *
     * @param _changedProperties Map of changed properties with old values
     */
  shouldUpdate(_changedProperties) {
    return __hook__(_changedProperties => {
      return true;
    }, null, arguments, __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[102]);
  }
  /**
     * Updates the element. This method reflects property values to attributes.
     * It can be overridden to render and keep updated element DOM.
     * Setting properties inside this method will *not* trigger
     * another update.
     *
     * @param _changedProperties Map of changed properties with old values
     */
  update(_changedProperties) {
    return __hook__(_changedProperties => {
      if (__hook__('#.', this, ['_reflectingProperties'], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[103]) !== $hook$.global(__hook__, __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[103], 'undefined', '#get')[__da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[104]] && __hook__('#.', __hook__('#.', this, ['_reflectingProperties'], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[103]), ['size'], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[103]) > 0) {
        // Use forEach so this works even if for/of loops are compiled to for
        // loops expecting arrays
        __hook__('#()', __hook__('#.', this, ['_reflectingProperties'], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[103]), [
          'forEach',
          [(...args) => __hook__((v, k) => __hook__('#()', this, [
              '_propertyToAttribute',
              [
                k,
                __hook__('#.', this, [k], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[103]),
                v
              ]
            ], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[103]), null, args, __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[103])]
        ], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[103]);
        __hook__('#=', this, [
          '_reflectingProperties',
          $hook$.global(__hook__, __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[103], 'undefined', '#get')[__da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[104]]
        ], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[103]);
      }
      __hook__('#()', this, [
        '_markUpdated',
        []
      ], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[103]);
    }, null, arguments, __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[103]);
  }
  /**
     * Invoked whenever the element is updated. Implement to perform
     * post-updating tasks via DOM APIs, for example, focusing an element.
     *
     * Setting properties inside this method will trigger the element to update
     * again after this update cycle completes.
     *
     * @param _changedProperties Map of changed properties with old values
     */
  updated(_changedProperties) {
    return __hook__(_changedProperties => {
    }, null, arguments, __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[105]);
  }
  /**
     * Invoked when the element is first updated. Implement to perform one time
     * work on the element after update.
     *
     * Setting properties inside this method will trigger the element to update
     * again after this update cycle completes.
     *
     * @param _changedProperties Map of changed properties with old values
     */
  firstUpdated(_changedProperties) {
    return __hook__(_changedProperties => {
    }, null, arguments, __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[106]);
  }
}
_a = finalized;
/**
 * Marks class as having finished creating properties.
 */
__hook__('#=', __hook__('m', UpdatingElement, [__da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[18]], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[0], null), [
  _a,
  true
], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[0]);  __hook__(() => {
}, null, [
  'export',
  __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[0],
  __90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__module_namespace_2
], __da140e61ecdb563be368893121319116701c615bcefe29ebb808fe09cc48f2a6__[0], NaN);

/**
 * @license
 * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
 * This code may only be used under the BSD style license found at
 * http://polymer.github.io/LICENSE.txt
 * The complete set of authors may be found at
 * http://polymer.github.io/AUTHORS.txt
 * The complete set of contributors may be found at
 * http://polymer.github.io/CONTRIBUTORS.txt
 * Code distributed by Google as part of the polymer project is also
 * subject to an additional IP rights grant found at
 * http://polymer.github.io/PATENTS.txt
 */
const __a4354ecfaee88c6142417df75f6a09cb7d291ed91d50b2093ebf730a479b94a7__ = $hook$.$(__hook__, [
  '/components/thin-hook/demo/node_modules/lit-element/lib/decorators.js',
  '/components/thin-hook/demo/node_modules/lit-element/lib/decorators.js,legacyCustomElement',
  'S_uNpREdiC4aB1e_window;/components/thin-hook/demo/node_modules/lit-element/lib/decorators.js,legacyCustomElement',
  '/components/thin-hook/demo/node_modules/lit-element/lib/decorators.js,standardCustomElement',
  '/components/thin-hook/demo/node_modules/lit-element/lib/decorators.js,standardCustomElement,finisher',
  'S_uNpREdiC4aB1e_window;/components/thin-hook/demo/node_modules/lit-element/lib/decorators.js,standardCustomElement,finisher',
  '/components/thin-hook/demo/node_modules/lit-element/lib/decorators.js,customElement',
  '/components/thin-hook/demo/node_modules/lit-element/lib/decorators.js,standardProperty',
  'S_uNpREdiC4aB1e_Object;/components/thin-hook/demo/node_modules/lit-element/lib/decorators.js,standardProperty',
  '/components/thin-hook/demo/node_modules/lit-element/lib/decorators.js,standardProperty,finisher',
  '/components/thin-hook/demo/node_modules/lit-element/lib/decorators.js,standardProperty,key',
  'S_uNpREdiC4aB1e_Symbol;/components/thin-hook/demo/node_modules/lit-element/lib/decorators.js,standardProperty,key',
  '/components/thin-hook/demo/node_modules/lit-element/lib/decorators.js,standardProperty,initializer',
  '/components/thin-hook/demo/node_modules/lit-element/lib/decorators.js,legacyProperty',
  '/components/thin-hook/demo/node_modules/lit-element/lib/decorators.js,property',
  'S_uNpREdiC4aB1e_undefined;/components/thin-hook/demo/node_modules/lit-element/lib/decorators.js,property',
  '/components/thin-hook/demo/node_modules/lit-element/lib/decorators.js,internalProperty',
  '/components/thin-hook/demo/node_modules/lit-element/lib/decorators.js,internalProperty,hasChanged',
  '/components/thin-hook/demo/node_modules/lit-element/lib/decorators.js,query',
  '/components/thin-hook/demo/node_modules/lit-element/lib/decorators.js,query,descriptor,get',
  'S_uNpREdiC4aB1e_undefined;/components/thin-hook/demo/node_modules/lit-element/lib/decorators.js,query',
  '/components/thin-hook/demo/node_modules/lit-element/lib/decorators.js,queryAsync',
  '/components/thin-hook/demo/node_modules/lit-element/lib/decorators.js,queryAsync,descriptor,get',
  'S_uNpREdiC4aB1e_undefined;/components/thin-hook/demo/node_modules/lit-element/lib/decorators.js,queryAsync',
  '/components/thin-hook/demo/node_modules/lit-element/lib/decorators.js,queryAll',
  '/components/thin-hook/demo/node_modules/lit-element/lib/decorators.js,queryAll,descriptor,get',
  'S_uNpREdiC4aB1e_undefined;/components/thin-hook/demo/node_modules/lit-element/lib/decorators.js,queryAll',
  '/components/thin-hook/demo/node_modules/lit-element/lib/decorators.js,legacyQuery',
  'S_uNpREdiC4aB1e_Object;/components/thin-hook/demo/node_modules/lit-element/lib/decorators.js,legacyQuery',
  '/components/thin-hook/demo/node_modules/lit-element/lib/decorators.js,standardQuery',
  '/components/thin-hook/demo/node_modules/lit-element/lib/decorators.js,standardQuery,key',
  '/components/thin-hook/demo/node_modules/lit-element/lib/decorators.js,standardEventOptions',
  'S_uNpREdiC4aB1e_Object;/components/thin-hook/demo/node_modules/lit-element/lib/decorators.js,standardEventOptions',
  '/components/thin-hook/demo/node_modules/lit-element/lib/decorators.js,standardEventOptions,finisher',
  'S_uNpREdiC4aB1e_Object;/components/thin-hook/demo/node_modules/lit-element/lib/decorators.js,standardEventOptions,finisher',
  '/components/thin-hook/demo/node_modules/lit-element/lib/decorators.js,legacyEventOptions',
  'S_uNpREdiC4aB1e_Object;/components/thin-hook/demo/node_modules/lit-element/lib/decorators.js,legacyEventOptions',
  '/components/thin-hook/demo/node_modules/lit-element/lib/decorators.js,eventOptions',
  'S_uNpREdiC4aB1e_undefined;/components/thin-hook/demo/node_modules/lit-element/lib/decorators.js,eventOptions',
  '/components/thin-hook/demo/node_modules/lit-element/lib/decorators.js,queryAssignedNodes',
  '/components/thin-hook/demo/node_modules/lit-element/lib/decorators.js,queryAssignedNodes,descriptor,get',
  '/components/thin-hook/demo/node_modules/lit-element/lib/decorators.js,queryAssignedNodes,descriptor,get,slot',
  'S_uNpREdiC4aB1e_undefined;/components/thin-hook/demo/node_modules/lit-element/lib/decorators.js,queryAssignedNodes'
]);
const legacyCustomElement = (...args) =>
  (__hook__((tagName, clazz) => {
    __hook__('#()', __hook__('#.', $hook$.global(__hook__, __a4354ecfaee88c6142417df75f6a09cb7d291ed91d50b2093ebf730a479b94a7__[1], 'window', '#get')[__a4354ecfaee88c6142417df75f6a09cb7d291ed91d50b2093ebf730a479b94a7__[2]], ['customElements'], __a4354ecfaee88c6142417df75f6a09cb7d291ed91d50b2093ebf730a479b94a7__[1]), [
      'define',
      [
        tagName,
        clazz
      ]
    ], __a4354ecfaee88c6142417df75f6a09cb7d291ed91d50b2093ebf730a479b94a7__[1]);
    // Cast as any because TS doesn't recognize the return type as being a
    // subtype of the decorated class when clazz is typed as
    // `Constructor<HTMLElement>` for some reason.
    // `Constructor<HTMLElement>` is helpful to make sure the decorator is
    // applied to elements however.
    // tslint:disable-next-line:no-any
    return clazz;
  }, null, args, __a4354ecfaee88c6142417df75f6a09cb7d291ed91d50b2093ebf730a479b94a7__[1]));
const standardCustomElement = (...args) =>
  (__hook__((tagName, descriptor) => {
    const {kind, elements} = __hook__('#*', descriptor, [], __a4354ecfaee88c6142417df75f6a09cb7d291ed91d50b2093ebf730a479b94a7__[3]);
    return {
      kind,
      elements,
      // This callback is called once the class is otherwise fully defined
      finisher(clazz) {
        return __hook__(clazz => {
          __hook__('#()', __hook__('#.', $hook$.global(__hook__, __a4354ecfaee88c6142417df75f6a09cb7d291ed91d50b2093ebf730a479b94a7__[4], 'window', '#get')[__a4354ecfaee88c6142417df75f6a09cb7d291ed91d50b2093ebf730a479b94a7__[5]], ['customElements'], __a4354ecfaee88c6142417df75f6a09cb7d291ed91d50b2093ebf730a479b94a7__[4]), [
            'define',
            [
              tagName,
              clazz
            ]
          ], __a4354ecfaee88c6142417df75f6a09cb7d291ed91d50b2093ebf730a479b94a7__[4]);
        }, null, arguments, __a4354ecfaee88c6142417df75f6a09cb7d291ed91d50b2093ebf730a479b94a7__[4]);
      }
    };
  }, null, args, __a4354ecfaee88c6142417df75f6a09cb7d291ed91d50b2093ebf730a479b94a7__[3]));
/**
 * Class decorator factory that defines the decorated class as a custom element.
 *
 * ```
 * @customElement('my-element')
 * class MyElement {
 *   render() {
 *     return html``;
 *   }
 * }
 * ```
 *
 * @param tagName The name of the custom element to define.
 */
const customElement = (...args) => __hook__(tagName => (...args) => __hook__(classOrDescriptor => typeof classOrDescriptor === 'function' ? __hook__(legacyCustomElement, null, [
  tagName,
  classOrDescriptor
], __a4354ecfaee88c6142417df75f6a09cb7d291ed91d50b2093ebf730a479b94a7__[6], 0) : __hook__(standardCustomElement, null, [
  tagName,
  classOrDescriptor
], __a4354ecfaee88c6142417df75f6a09cb7d291ed91d50b2093ebf730a479b94a7__[6], 0), null, args, __a4354ecfaee88c6142417df75f6a09cb7d291ed91d50b2093ebf730a479b94a7__[6]), null, args, __a4354ecfaee88c6142417df75f6a09cb7d291ed91d50b2093ebf730a479b94a7__[6]);
const standardProperty = (...args) =>
  (__hook__((options, element) => {
    // When decorating an accessor, pass it through and add property metadata.
    // Note, the `hasOwnProperty` check in `createProperty` ensures we don't
    // stomp over the user's accessor.
    if (__hook__('#.', element, ['kind'], __a4354ecfaee88c6142417df75f6a09cb7d291ed91d50b2093ebf730a479b94a7__[7]) === 'method' && __hook__('#.', element, ['descriptor'], __a4354ecfaee88c6142417df75f6a09cb7d291ed91d50b2093ebf730a479b94a7__[7]) && !__hook__('#in', __hook__('#.', element, ['descriptor'], __a4354ecfaee88c6142417df75f6a09cb7d291ed91d50b2093ebf730a479b94a7__[7]), ['value'], __a4354ecfaee88c6142417df75f6a09cb7d291ed91d50b2093ebf730a479b94a7__[7])) {
      return __hook__('#()', $hook$.global(__hook__, __a4354ecfaee88c6142417df75f6a09cb7d291ed91d50b2093ebf730a479b94a7__[7], 'Object', '#get')[__a4354ecfaee88c6142417df75f6a09cb7d291ed91d50b2093ebf730a479b94a7__[8]], [
        'assign',
        [
          __hook__('#()', $hook$.global(__hook__, __a4354ecfaee88c6142417df75f6a09cb7d291ed91d50b2093ebf730a479b94a7__[7], 'Object', '#get')[__a4354ecfaee88c6142417df75f6a09cb7d291ed91d50b2093ebf730a479b94a7__[8]], [
            'assign',
            [
              {},
              element
            ]
          ], __a4354ecfaee88c6142417df75f6a09cb7d291ed91d50b2093ebf730a479b94a7__[7]),
          {
            finisher(clazz) {
              return __hook__(clazz => {
                __hook__('#()', clazz, [
                  'createProperty',
                  [
                    __hook__('#.', element, ['key'], __a4354ecfaee88c6142417df75f6a09cb7d291ed91d50b2093ebf730a479b94a7__[9]),
                    options
                  ]
                ], __a4354ecfaee88c6142417df75f6a09cb7d291ed91d50b2093ebf730a479b94a7__[9]);
              }, null, arguments, __a4354ecfaee88c6142417df75f6a09cb7d291ed91d50b2093ebf730a479b94a7__[9]);
            }
          }
        ]
      ], __a4354ecfaee88c6142417df75f6a09cb7d291ed91d50b2093ebf730a479b94a7__[7]);
    } else {
      // createProperty() takes care of defining the property, but we still
      // must return some kind of descriptor, so return a descriptor for an
      // unused prototype field. The finisher calls createProperty().
      return {
        kind: 'field',
        key: __hook__($hook$.global(__hook__, __a4354ecfaee88c6142417df75f6a09cb7d291ed91d50b2093ebf730a479b94a7__[10], 'Symbol', '#get')[__a4354ecfaee88c6142417df75f6a09cb7d291ed91d50b2093ebf730a479b94a7__[11]], null, [], __a4354ecfaee88c6142417df75f6a09cb7d291ed91d50b2093ebf730a479b94a7__[10], 0),
        placement: 'own',
        descriptor: {},
        // When @babel/plugin-proposal-decorators implements initializers,
        // do this instead of the initializer below. See:
        // https://github.com/babel/babel/issues/9260 extras: [
        //   {
        //     kind: 'initializer',
        //     placement: 'own',
        //     initializer: descriptor.initializer,
        //   }
        // ],
        initializer() {
          return __hook__(() => {
            if (typeof __hook__('#.', element, ['initializer'], __a4354ecfaee88c6142417df75f6a09cb7d291ed91d50b2093ebf730a479b94a7__[12]) === 'function') {
              __hook__('#=', this, [
                __hook__('#.', element, ['key'], __a4354ecfaee88c6142417df75f6a09cb7d291ed91d50b2093ebf730a479b94a7__[12]),
                __hook__('#()', __hook__('#.', element, ['initializer'], __a4354ecfaee88c6142417df75f6a09cb7d291ed91d50b2093ebf730a479b94a7__[12]), [
                  'call',
                  [this]
                ], __a4354ecfaee88c6142417df75f6a09cb7d291ed91d50b2093ebf730a479b94a7__[12])
              ], __a4354ecfaee88c6142417df75f6a09cb7d291ed91d50b2093ebf730a479b94a7__[12]);
            }
          }, null, arguments, __a4354ecfaee88c6142417df75f6a09cb7d291ed91d50b2093ebf730a479b94a7__[12]);
        },
        finisher(clazz) {
          return __hook__(clazz => {
            __hook__('#()', clazz, [
              'createProperty',
              [
                __hook__('#.', element, ['key'], __a4354ecfaee88c6142417df75f6a09cb7d291ed91d50b2093ebf730a479b94a7__[9]),
                options
              ]
            ], __a4354ecfaee88c6142417df75f6a09cb7d291ed91d50b2093ebf730a479b94a7__[9]);
          }, null, arguments, __a4354ecfaee88c6142417df75f6a09cb7d291ed91d50b2093ebf730a479b94a7__[9]);
        }
      };
    }
  }, null, args, __a4354ecfaee88c6142417df75f6a09cb7d291ed91d50b2093ebf730a479b94a7__[7]));
const legacyProperty = (...args) =>
  (__hook__((options, proto, name) => {
    __hook__('#()', __hook__('#.', proto, ['constructor'], __a4354ecfaee88c6142417df75f6a09cb7d291ed91d50b2093ebf730a479b94a7__[13]), [
      'createProperty',
      [
        name,
        options
      ]
    ], __a4354ecfaee88c6142417df75f6a09cb7d291ed91d50b2093ebf730a479b94a7__[13]);
  }, null, args, __a4354ecfaee88c6142417df75f6a09cb7d291ed91d50b2093ebf730a479b94a7__[13]));
/**
 * A property decorator which creates a LitElement property which reflects a
 * corresponding attribute value. A `PropertyDeclaration` may optionally be
 * supplied to configure property features.
 *
 * This decorator should only be used for public fields. Private or protected
 * fields should use the internalProperty decorator.
 *
 * @example
 *
 *     class MyElement {
 *       @property({ type: Boolean })
 *       clicked = false;
 *     }
 *
 * @ExportDecoratedItems
 */
function property(options) {
  return __hook__(options => {
    // tslint:disable-next-line:no-any decorator
    return (...args) => __hook__((protoOrDescriptor, name) => name !== $hook$.global(__hook__, __a4354ecfaee88c6142417df75f6a09cb7d291ed91d50b2093ebf730a479b94a7__[14], 'undefined', '#get')[__a4354ecfaee88c6142417df75f6a09cb7d291ed91d50b2093ebf730a479b94a7__[15]] ? __hook__(legacyProperty, null, [
      options,
      protoOrDescriptor,
      name
    ], __a4354ecfaee88c6142417df75f6a09cb7d291ed91d50b2093ebf730a479b94a7__[14], 0) : __hook__(standardProperty, null, [
      options,
      protoOrDescriptor
    ], __a4354ecfaee88c6142417df75f6a09cb7d291ed91d50b2093ebf730a479b94a7__[14], 0), null, args, __a4354ecfaee88c6142417df75f6a09cb7d291ed91d50b2093ebf730a479b94a7__[14]);
  }, null, arguments, __a4354ecfaee88c6142417df75f6a09cb7d291ed91d50b2093ebf730a479b94a7__[14]);
}
/**
 * Declares a private or protected property that still triggers updates to the
 * element when it changes.
 *
 * Properties declared this way must not be used from HTML or HTML templating
 * systems, they're solely for properties internal to the element. These
 * properties may be renamed by optimization tools like closure compiler.
 */
function internalProperty(options) {
  return __hook__(options => {
    return __hook__('m()', property, [
      __a4354ecfaee88c6142417df75f6a09cb7d291ed91d50b2093ebf730a479b94a7__[14],
      [{
          attribute: false,
          hasChanged: options === null || options === void 0 ? void 0 : __hook__('#.', options, ['hasChanged'], __a4354ecfaee88c6142417df75f6a09cb7d291ed91d50b2093ebf730a479b94a7__[17])
        }],
      (...args) => property(...args)
    ], __a4354ecfaee88c6142417df75f6a09cb7d291ed91d50b2093ebf730a479b94a7__[16], null);
  }, null, arguments, __a4354ecfaee88c6142417df75f6a09cb7d291ed91d50b2093ebf730a479b94a7__[16]);
}
/**
 * A property decorator that converts a class property into a getter that
 * executes a querySelector on the element's renderRoot.
 *
 * @param selector A DOMString containing one or more selectors to match.
 *
 * See: https://developer.mozilla.org/en-US/docs/Web/API/Document/querySelector
 *
 * @example
 *
 *     class MyElement {
 *       @query('#first')
 *       first;
 *
 *       render() {
 *         return html`
 *           <div id="first"></div>
 *           <div id="second"></div>
 *         `;
 *       }
 *     }
 *
 */
function query(selector) {
  return __hook__(selector => {
    return (...args) =>
      (__hook__((protoOrDescriptor, name) => {
        const descriptor = {
          get() {
            return __hook__(() => {
              return __hook__('#()', __hook__('#.', this, ['renderRoot'], __a4354ecfaee88c6142417df75f6a09cb7d291ed91d50b2093ebf730a479b94a7__[19]), [
                'querySelector',
                [selector]
              ], __a4354ecfaee88c6142417df75f6a09cb7d291ed91d50b2093ebf730a479b94a7__[19]);
            }, null, arguments, __a4354ecfaee88c6142417df75f6a09cb7d291ed91d50b2093ebf730a479b94a7__[19]);
          },
          enumerable: true,
          configurable: true
        };
        return name !== $hook$.global(__hook__, __a4354ecfaee88c6142417df75f6a09cb7d291ed91d50b2093ebf730a479b94a7__[18], 'undefined', '#get')[__a4354ecfaee88c6142417df75f6a09cb7d291ed91d50b2093ebf730a479b94a7__[20]] ? __hook__(legacyQuery, null, [
          descriptor,
          protoOrDescriptor,
          name
        ], __a4354ecfaee88c6142417df75f6a09cb7d291ed91d50b2093ebf730a479b94a7__[18], 0) : __hook__(standardQuery, null, [
          descriptor,
          protoOrDescriptor
        ], __a4354ecfaee88c6142417df75f6a09cb7d291ed91d50b2093ebf730a479b94a7__[18], 0);
      }, null, args, __a4354ecfaee88c6142417df75f6a09cb7d291ed91d50b2093ebf730a479b94a7__[18]));
  }, null, arguments, __a4354ecfaee88c6142417df75f6a09cb7d291ed91d50b2093ebf730a479b94a7__[18]);
}
// Note, in the future, we may extend this decorator to support the use case
// where the queried element may need to do work to become ready to interact
// with (e.g. load some implementation code). If so, we might elect to
// add a second argument defining a function that can be run to make the
// queried element loaded/updated/ready.
/**
 * A property decorator that converts a class property into a getter that
 * returns a promise that resolves to the result of a querySelector on the
 * element's renderRoot done after the element's `updateComplete` promise
 * resolves. When the queried property may change with element state, this
 * decorator can be used instead of requiring users to await the
 * `updateComplete` before accessing the property.
 *
 * @param selector A DOMString containing one or more selectors to match.
 *
 * See: https://developer.mozilla.org/en-US/docs/Web/API/Document/querySelector
 *
 * @example
 *
 *     class MyElement {
 *       @queryAsync('#first')
 *       first;
 *
 *       render() {
 *         return html`
 *           <div id="first"></div>
 *           <div id="second"></div>
 *         `;
 *       }
 *     }
 *
 *     // external usage
 *     async doSomethingWithFirst() {
 *      (await aMyElement.first).doSomething();
 *     }
 */
function queryAsync(selector) {
  return __hook__(selector => {
    return (...args) =>
      (__hook__((protoOrDescriptor, name) => {
        const descriptor = {
          async get() {
            return __hook__(async () => {
              await __hook__('#.', this, ['updateComplete'], __a4354ecfaee88c6142417df75f6a09cb7d291ed91d50b2093ebf730a479b94a7__[22]);
              return __hook__('#()', __hook__('#.', this, ['renderRoot'], __a4354ecfaee88c6142417df75f6a09cb7d291ed91d50b2093ebf730a479b94a7__[22]), [
                'querySelector',
                [selector]
              ], __a4354ecfaee88c6142417df75f6a09cb7d291ed91d50b2093ebf730a479b94a7__[22]);
            }, null, arguments, __a4354ecfaee88c6142417df75f6a09cb7d291ed91d50b2093ebf730a479b94a7__[22]);
          },
          enumerable: true,
          configurable: true
        };
        return name !== $hook$.global(__hook__, __a4354ecfaee88c6142417df75f6a09cb7d291ed91d50b2093ebf730a479b94a7__[21], 'undefined', '#get')[__a4354ecfaee88c6142417df75f6a09cb7d291ed91d50b2093ebf730a479b94a7__[23]] ? __hook__(legacyQuery, null, [
          descriptor,
          protoOrDescriptor,
          name
        ], __a4354ecfaee88c6142417df75f6a09cb7d291ed91d50b2093ebf730a479b94a7__[21], 0) : __hook__(standardQuery, null, [
          descriptor,
          protoOrDescriptor
        ], __a4354ecfaee88c6142417df75f6a09cb7d291ed91d50b2093ebf730a479b94a7__[21], 0);
      }, null, args, __a4354ecfaee88c6142417df75f6a09cb7d291ed91d50b2093ebf730a479b94a7__[21]));
  }, null, arguments, __a4354ecfaee88c6142417df75f6a09cb7d291ed91d50b2093ebf730a479b94a7__[21]);
}
/**
 * A property decorator that converts a class property into a getter
 * that executes a querySelectorAll on the element's renderRoot.
 *
 * @param selector A DOMString containing one or more selectors to match.
 *
 * See:
 * https://developer.mozilla.org/en-US/docs/Web/API/Document/querySelectorAll
 *
 * @example
 *
 *     class MyElement {
 *       @queryAll('div')
 *       divs;
 *
 *       render() {
 *         return html`
 *           <div id="first"></div>
 *           <div id="second"></div>
 *         `;
 *       }
 *     }
 */
function queryAll(selector) {
  return __hook__(selector => {
    return (...args) =>
      (__hook__((protoOrDescriptor, name) => {
        const descriptor = {
          get() {
            return __hook__(() => {
              return __hook__('#()', __hook__('#.', this, ['renderRoot'], __a4354ecfaee88c6142417df75f6a09cb7d291ed91d50b2093ebf730a479b94a7__[25]), [
                'querySelectorAll',
                [selector]
              ], __a4354ecfaee88c6142417df75f6a09cb7d291ed91d50b2093ebf730a479b94a7__[25]);
            }, null, arguments, __a4354ecfaee88c6142417df75f6a09cb7d291ed91d50b2093ebf730a479b94a7__[25]);
          },
          enumerable: true,
          configurable: true
        };
        return name !== $hook$.global(__hook__, __a4354ecfaee88c6142417df75f6a09cb7d291ed91d50b2093ebf730a479b94a7__[24], 'undefined', '#get')[__a4354ecfaee88c6142417df75f6a09cb7d291ed91d50b2093ebf730a479b94a7__[26]] ? __hook__(legacyQuery, null, [
          descriptor,
          protoOrDescriptor,
          name
        ], __a4354ecfaee88c6142417df75f6a09cb7d291ed91d50b2093ebf730a479b94a7__[24], 0) : __hook__(standardQuery, null, [
          descriptor,
          protoOrDescriptor
        ], __a4354ecfaee88c6142417df75f6a09cb7d291ed91d50b2093ebf730a479b94a7__[24], 0);
      }, null, args, __a4354ecfaee88c6142417df75f6a09cb7d291ed91d50b2093ebf730a479b94a7__[24]));
  }, null, arguments, __a4354ecfaee88c6142417df75f6a09cb7d291ed91d50b2093ebf730a479b94a7__[24]);
}
const legacyQuery = (...args) =>
  (__hook__((descriptor, proto, name) => {
    __hook__('#()', $hook$.global(__hook__, __a4354ecfaee88c6142417df75f6a09cb7d291ed91d50b2093ebf730a479b94a7__[27], 'Object', '#get')[__a4354ecfaee88c6142417df75f6a09cb7d291ed91d50b2093ebf730a479b94a7__[28]], [
      'defineProperty',
      [
        proto,
        name,
        descriptor
      ]
    ], __a4354ecfaee88c6142417df75f6a09cb7d291ed91d50b2093ebf730a479b94a7__[27]);
  }, null, args, __a4354ecfaee88c6142417df75f6a09cb7d291ed91d50b2093ebf730a479b94a7__[27]));
const standardQuery = (...args) => __hook__((descriptor, element) => ({
  kind: 'method',
  placement: 'prototype',
  key: __hook__('#.', element, ['key'], __a4354ecfaee88c6142417df75f6a09cb7d291ed91d50b2093ebf730a479b94a7__[30]),
  descriptor
}), null, args, __a4354ecfaee88c6142417df75f6a09cb7d291ed91d50b2093ebf730a479b94a7__[29]);
const standardEventOptions = (...args) =>
  (__hook__((options, element) => {
    return __hook__('#()', $hook$.global(__hook__, __a4354ecfaee88c6142417df75f6a09cb7d291ed91d50b2093ebf730a479b94a7__[31], 'Object', '#get')[__a4354ecfaee88c6142417df75f6a09cb7d291ed91d50b2093ebf730a479b94a7__[32]], [
      'assign',
      [
        __hook__('#()', $hook$.global(__hook__, __a4354ecfaee88c6142417df75f6a09cb7d291ed91d50b2093ebf730a479b94a7__[31], 'Object', '#get')[__a4354ecfaee88c6142417df75f6a09cb7d291ed91d50b2093ebf730a479b94a7__[32]], [
          'assign',
          [
            {},
            element
          ]
        ], __a4354ecfaee88c6142417df75f6a09cb7d291ed91d50b2093ebf730a479b94a7__[31]),
        {
          finisher(clazz) {
            return __hook__(clazz => {
              __hook__('#()', $hook$.global(__hook__, __a4354ecfaee88c6142417df75f6a09cb7d291ed91d50b2093ebf730a479b94a7__[33], 'Object', '#get')[__a4354ecfaee88c6142417df75f6a09cb7d291ed91d50b2093ebf730a479b94a7__[34]], [
                'assign',
                [
                  __hook__('#.', __hook__('#.', clazz, ['prototype'], __a4354ecfaee88c6142417df75f6a09cb7d291ed91d50b2093ebf730a479b94a7__[33]), [__hook__('#.', element, ['key'], __a4354ecfaee88c6142417df75f6a09cb7d291ed91d50b2093ebf730a479b94a7__[33])], __a4354ecfaee88c6142417df75f6a09cb7d291ed91d50b2093ebf730a479b94a7__[33]),
                  options
                ]
              ], __a4354ecfaee88c6142417df75f6a09cb7d291ed91d50b2093ebf730a479b94a7__[33]);
            }, null, arguments, __a4354ecfaee88c6142417df75f6a09cb7d291ed91d50b2093ebf730a479b94a7__[33]);
          }
        }
      ]
    ], __a4354ecfaee88c6142417df75f6a09cb7d291ed91d50b2093ebf730a479b94a7__[31]);
  }, null, args, __a4354ecfaee88c6142417df75f6a09cb7d291ed91d50b2093ebf730a479b94a7__[31]));
const legacyEventOptions = // tslint:disable-next-line:no-any legacy decorator
(...args) =>
  (__hook__((options, proto, name) => {
    __hook__('#()', $hook$.global(__hook__, __a4354ecfaee88c6142417df75f6a09cb7d291ed91d50b2093ebf730a479b94a7__[35], 'Object', '#get')[__a4354ecfaee88c6142417df75f6a09cb7d291ed91d50b2093ebf730a479b94a7__[36]], [
      'assign',
      [
        __hook__('#.', proto, [name], __a4354ecfaee88c6142417df75f6a09cb7d291ed91d50b2093ebf730a479b94a7__[35]),
        options
      ]
    ], __a4354ecfaee88c6142417df75f6a09cb7d291ed91d50b2093ebf730a479b94a7__[35]);
  }, null, args, __a4354ecfaee88c6142417df75f6a09cb7d291ed91d50b2093ebf730a479b94a7__[35]));
/**
 * Adds event listener options to a method used as an event listener in a
 * lit-html template.
 *
 * @param options An object that specifies event listener options as accepted by
 * `EventTarget#addEventListener` and `EventTarget#removeEventListener`.
 *
 * Current browsers support the `capture`, `passive`, and `once` options. See:
 * https://developer.mozilla.org/en-US/docs/Web/API/EventTarget/addEventListener#Parameters
 *
 * @example
 *
 *     class MyElement {
 *       clicked = false;
 *
 *       render() {
 *         return html`
 *           <div @click=${this._onClick}`>
 *             <button></button>
 *           </div>
 *         `;
 *       }
 *
 *       @eventOptions({capture: true})
 *       _onClick(e) {
 *         this.clicked = true;
 *       }
 *     }
 */
function eventOptions(options) {
  return __hook__(options => {
    // Return value typed as any to prevent TypeScript from complaining that
    // standard decorator function signature does not match TypeScript decorator
    // signature
    // TODO(kschaaf): unclear why it was only failing on this decorator and not
    // the others
    return (...args) => __hook__((protoOrDescriptor, name) => name !== $hook$.global(__hook__, __a4354ecfaee88c6142417df75f6a09cb7d291ed91d50b2093ebf730a479b94a7__[37], 'undefined', '#get')[__a4354ecfaee88c6142417df75f6a09cb7d291ed91d50b2093ebf730a479b94a7__[38]] ? __hook__(legacyEventOptions, null, [
      options,
      protoOrDescriptor,
      name
    ], __a4354ecfaee88c6142417df75f6a09cb7d291ed91d50b2093ebf730a479b94a7__[37], 0) : __hook__(standardEventOptions, null, [
      options,
      protoOrDescriptor
    ], __a4354ecfaee88c6142417df75f6a09cb7d291ed91d50b2093ebf730a479b94a7__[37], 0), null, args, __a4354ecfaee88c6142417df75f6a09cb7d291ed91d50b2093ebf730a479b94a7__[37]);
  }, null, arguments, __a4354ecfaee88c6142417df75f6a09cb7d291ed91d50b2093ebf730a479b94a7__[37]);
}
/**
 * A property decorator that converts a class property into a getter that
 * returns the `assignedNodes` of the given named `slot`. Note, the type of
 * this property should be annotated as `NodeListOf<HTMLElement>`.
 *
 */
function queryAssignedNodes(slotName, flatten) {
  return __hook__((slotName = '', flatten = false) => {
    return (...args) =>
      (__hook__((protoOrDescriptor, name) => {
        const descriptor = {
          get() {
            return __hook__(() => {
              const selector = `slot${ slotName ? `[name=${ slotName }]` : '' }`;
              const slot = __hook__('#()', __hook__('#.', this, ['renderRoot'], __a4354ecfaee88c6142417df75f6a09cb7d291ed91d50b2093ebf730a479b94a7__[41]), [
                'querySelector',
                [selector]
              ], __a4354ecfaee88c6142417df75f6a09cb7d291ed91d50b2093ebf730a479b94a7__[41]);
              return slot && __hook__('#()', slot, [
                'assignedNodes',
                [{ flatten }]
              ], __a4354ecfaee88c6142417df75f6a09cb7d291ed91d50b2093ebf730a479b94a7__[40]);
            }, null, arguments, __a4354ecfaee88c6142417df75f6a09cb7d291ed91d50b2093ebf730a479b94a7__[40]);
          },
          enumerable: true,
          configurable: true
        };
        return name !== $hook$.global(__hook__, __a4354ecfaee88c6142417df75f6a09cb7d291ed91d50b2093ebf730a479b94a7__[39], 'undefined', '#get')[__a4354ecfaee88c6142417df75f6a09cb7d291ed91d50b2093ebf730a479b94a7__[42]] ? __hook__(legacyQuery, null, [
          descriptor,
          protoOrDescriptor,
          name
        ], __a4354ecfaee88c6142417df75f6a09cb7d291ed91d50b2093ebf730a479b94a7__[39], 0) : __hook__(standardQuery, null, [
          descriptor,
          protoOrDescriptor
        ], __a4354ecfaee88c6142417df75f6a09cb7d291ed91d50b2093ebf730a479b94a7__[39], 0);
      }, null, args, __a4354ecfaee88c6142417df75f6a09cb7d291ed91d50b2093ebf730a479b94a7__[39]));
  }, null, arguments, __a4354ecfaee88c6142417df75f6a09cb7d291ed91d50b2093ebf730a479b94a7__[39]);
}
__hook__(() => {
}, null, [
  'export',
  __a4354ecfaee88c6142417df75f6a09cb7d291ed91d50b2093ebf730a479b94a7__[0],
  __90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__module_namespace_3
], __a4354ecfaee88c6142417df75f6a09cb7d291ed91d50b2093ebf730a479b94a7__[0], NaN);

/**
@license
Copyright (c) 2019 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at
http://polymer.github.io/LICENSE.txt The complete set of authors may be found at
http://polymer.github.io/AUTHORS.txt The complete set of contributors may be
found at http://polymer.github.io/CONTRIBUTORS.txt Code distributed by Google as
part of the polymer project is also subject to an additional IP rights grant
found at http://polymer.github.io/PATENTS.txt
*/
const __a849996e1a1fa106b922e1e7262c25bad15f0748b05b39d5f38613d553fc8993__ = $hook$.$(__hook__, [
  '/components/thin-hook/demo/node_modules/lit-element/lib/css-tag.js',
  '/components/thin-hook/demo/node_modules/lit-element/lib/css-tag.js,supportsAdoptingStyleSheets',
  'S_uNpREdiC4aB1e_Document;/components/thin-hook/demo/node_modules/lit-element/lib/css-tag.js,supportsAdoptingStyleSheets',
  'S_uNpREdiC4aB1e_CSSStyleSheet;/components/thin-hook/demo/node_modules/lit-element/lib/css-tag.js,supportsAdoptingStyleSheets',
  '/components/thin-hook/demo/node_modules/lit-element/lib/css-tag.js,constructionToken',
  'S_uNpREdiC4aB1e_Symbol;/components/thin-hook/demo/node_modules/lit-element/lib/css-tag.js,constructionToken',
  '/components/thin-hook/demo/node_modules/lit-element/lib/css-tag.js,CSSResult,constructor',
  'S_uNpREdiC4aB1e_Error;/components/thin-hook/demo/node_modules/lit-element/lib/css-tag.js,CSSResult,constructor',
  '/components/thin-hook/demo/node_modules/lit-element/lib/css-tag.js,CSSResult,get styleSheet',
  'S_uNpREdiC4aB1e_undefined;/components/thin-hook/demo/node_modules/lit-element/lib/css-tag.js,CSSResult,get styleSheet',
  'S_uNpREdiC4aB1e_CSSStyleSheet;/components/thin-hook/demo/node_modules/lit-element/lib/css-tag.js,CSSResult,get styleSheet',
  '/components/thin-hook/demo/node_modules/lit-element/lib/css-tag.js,CSSResult,toString',
  '/components/thin-hook/demo/node_modules/lit-element/lib/css-tag.js,unsafeCSS',
  '/components/thin-hook/demo/node_modules/lit-element/lib/css-tag.js,CSSResult',
  'S_uNpREdiC4aB1e_String;/components/thin-hook/demo/node_modules/lit-element/lib/css-tag.js,unsafeCSS',
  '/components/thin-hook/demo/node_modules/lit-element/lib/css-tag.js,textFromCSSResult',
  'S_uNpREdiC4aB1e_Error;/components/thin-hook/demo/node_modules/lit-element/lib/css-tag.js,textFromCSSResult',
  '/components/thin-hook/demo/node_modules/lit-element/lib/css-tag.js,css',
  '/components/thin-hook/demo/node_modules/lit-element/lib/css-tag.js,css,cssText'
]);
const supportsAdoptingStyleSheets = __hook__('#in', __hook__('#.', $hook$.global(__hook__, __a849996e1a1fa106b922e1e7262c25bad15f0748b05b39d5f38613d553fc8993__[1], 'Document', '#get')[__a849996e1a1fa106b922e1e7262c25bad15f0748b05b39d5f38613d553fc8993__[2]], ['prototype'], __a849996e1a1fa106b922e1e7262c25bad15f0748b05b39d5f38613d553fc8993__[1]), ['adoptedStyleSheets'], __a849996e1a1fa106b922e1e7262c25bad15f0748b05b39d5f38613d553fc8993__[1]) && __hook__('#in', __hook__('#.', $hook$.global(__hook__, __a849996e1a1fa106b922e1e7262c25bad15f0748b05b39d5f38613d553fc8993__[1], 'CSSStyleSheet', '#get')[__a849996e1a1fa106b922e1e7262c25bad15f0748b05b39d5f38613d553fc8993__[3]], ['prototype'], __a849996e1a1fa106b922e1e7262c25bad15f0748b05b39d5f38613d553fc8993__[1]), ['replace'], __a849996e1a1fa106b922e1e7262c25bad15f0748b05b39d5f38613d553fc8993__[1]);
const constructionToken = __hook__($hook$.global(__hook__, __a849996e1a1fa106b922e1e7262c25bad15f0748b05b39d5f38613d553fc8993__[4], 'Symbol', '#get')[__a849996e1a1fa106b922e1e7262c25bad15f0748b05b39d5f38613d553fc8993__[5]], null, [], __a849996e1a1fa106b922e1e7262c25bad15f0748b05b39d5f38613d553fc8993__[4], 0);
class CSSResult {
  constructor(cssText, safeToken) {
    return __hook__((cssText, safeToken) => {
      if (safeToken !== constructionToken) {
        throw __hook__($hook$.global(__hook__, __a849996e1a1fa106b922e1e7262c25bad15f0748b05b39d5f38613d553fc8993__[6], 'Error', '#get')[__a849996e1a1fa106b922e1e7262c25bad15f0748b05b39d5f38613d553fc8993__[7]], null, ['CSSResult is not constructable. Use `unsafeCSS` or `css` instead.'], __a849996e1a1fa106b922e1e7262c25bad15f0748b05b39d5f38613d553fc8993__[6], true);
      }
      __hook__('#=', this, [
        'cssText',
        cssText
      ], __a849996e1a1fa106b922e1e7262c25bad15f0748b05b39d5f38613d553fc8993__[6]);
    }, null, arguments, __a849996e1a1fa106b922e1e7262c25bad15f0748b05b39d5f38613d553fc8993__[6]);
  }
  // Note, this is a getter so that it's lazy. In practice, this means
  // stylesheets are not created until the first element instance is made.
  get styleSheet() {
    return __hook__(() => {
      if (__hook__('#.', this, ['_styleSheet'], __a849996e1a1fa106b922e1e7262c25bad15f0748b05b39d5f38613d553fc8993__[8]) === $hook$.global(__hook__, __a849996e1a1fa106b922e1e7262c25bad15f0748b05b39d5f38613d553fc8993__[8], 'undefined', '#get')[__a849996e1a1fa106b922e1e7262c25bad15f0748b05b39d5f38613d553fc8993__[9]]) {
        // Note, if `adoptedStyleSheets` is supported then we assume CSSStyleSheet
        // is constructable.
        if (__hook__('m', supportsAdoptingStyleSheets, [__a849996e1a1fa106b922e1e7262c25bad15f0748b05b39d5f38613d553fc8993__[1]], __a849996e1a1fa106b922e1e7262c25bad15f0748b05b39d5f38613d553fc8993__[8], null)) {
          __hook__('#=', this, [
            '_styleSheet',
            __hook__($hook$.global(__hook__, __a849996e1a1fa106b922e1e7262c25bad15f0748b05b39d5f38613d553fc8993__[8], 'CSSStyleSheet', '#get')[__a849996e1a1fa106b922e1e7262c25bad15f0748b05b39d5f38613d553fc8993__[10]], null, [], __a849996e1a1fa106b922e1e7262c25bad15f0748b05b39d5f38613d553fc8993__[8], true)
          ], __a849996e1a1fa106b922e1e7262c25bad15f0748b05b39d5f38613d553fc8993__[8]);
          __hook__('#()', __hook__('#.', this, ['_styleSheet'], __a849996e1a1fa106b922e1e7262c25bad15f0748b05b39d5f38613d553fc8993__[8]), [
            'replaceSync',
            [__hook__('#.', this, ['cssText'], __a849996e1a1fa106b922e1e7262c25bad15f0748b05b39d5f38613d553fc8993__[8])]
          ], __a849996e1a1fa106b922e1e7262c25bad15f0748b05b39d5f38613d553fc8993__[8]);
        } else {
          __hook__('#=', this, [
            '_styleSheet',
            null
          ], __a849996e1a1fa106b922e1e7262c25bad15f0748b05b39d5f38613d553fc8993__[8]);
        }
      }
      return __hook__('#.', this, ['_styleSheet'], __a849996e1a1fa106b922e1e7262c25bad15f0748b05b39d5f38613d553fc8993__[8]);
    }, null, arguments, __a849996e1a1fa106b922e1e7262c25bad15f0748b05b39d5f38613d553fc8993__[8]);
  }
  toString() {
    return __hook__(() => {
      return __hook__('#.', this, ['cssText'], __a849996e1a1fa106b922e1e7262c25bad15f0748b05b39d5f38613d553fc8993__[11]);
    }, null, arguments, __a849996e1a1fa106b922e1e7262c25bad15f0748b05b39d5f38613d553fc8993__[11]);
  }
}
/**
 * Wrap a value for interpolation in a css tagged template literal.
 *
 * This is unsafe because untrusted CSS text can be used to phone home
 * or exfiltrate data to an attacker controlled site. Take care to only use
 * this with trusted input.
 */
const unsafeCSS = (...args) =>
  (__hook__(value => {
    return __hook__('mnew', CSSResult, [
      __a849996e1a1fa106b922e1e7262c25bad15f0748b05b39d5f38613d553fc8993__[13],
      [
        __hook__($hook$.global(__hook__, __a849996e1a1fa106b922e1e7262c25bad15f0748b05b39d5f38613d553fc8993__[12], 'String', '#get')[__a849996e1a1fa106b922e1e7262c25bad15f0748b05b39d5f38613d553fc8993__[14]], null, [value], __a849996e1a1fa106b922e1e7262c25bad15f0748b05b39d5f38613d553fc8993__[12], 0),
        constructionToken
      ],
      (...args) => new CSSResult(...args)
    ], __a849996e1a1fa106b922e1e7262c25bad15f0748b05b39d5f38613d553fc8993__[12], null);
  }, null, args, __a849996e1a1fa106b922e1e7262c25bad15f0748b05b39d5f38613d553fc8993__[12]));
const textFromCSSResult = (...args) =>
  (__hook__(value => {
    if (value instanceof __hook__('m', CSSResult, [__a849996e1a1fa106b922e1e7262c25bad15f0748b05b39d5f38613d553fc8993__[13]], __a849996e1a1fa106b922e1e7262c25bad15f0748b05b39d5f38613d553fc8993__[15], null)) {
      return __hook__('#.', value, ['cssText'], __a849996e1a1fa106b922e1e7262c25bad15f0748b05b39d5f38613d553fc8993__[15]);
    } else if (typeof value === 'number') {
      return value;
    } else {
      throw __hook__($hook$.global(__hook__, __a849996e1a1fa106b922e1e7262c25bad15f0748b05b39d5f38613d553fc8993__[15], 'Error', '#get')[__a849996e1a1fa106b922e1e7262c25bad15f0748b05b39d5f38613d553fc8993__[16]], null, [`Value passed to 'css' function must be a 'css' function result: ${ value }. Use 'unsafeCSS' to pass non-literal values, but
            take care to ensure page security.`], __a849996e1a1fa106b922e1e7262c25bad15f0748b05b39d5f38613d553fc8993__[15], true);
    }
  }, null, args, __a849996e1a1fa106b922e1e7262c25bad15f0748b05b39d5f38613d553fc8993__[15]));
/**
 * Template tag which which can be used with LitElement's `style` property to
 * set element styles. For security reasons, only literal string values may be
 * used. To incorporate non-literal values `unsafeCSS` may be used inside a
 * template string part.
 */
const css = (...args) =>
  (__hook__((strings, ...values) => {
    const cssText = __hook__('#()', values, [
      'reduce',
      [
        (...args) => __hook__((acc, v, idx) => acc + __hook__(textFromCSSResult, null, [v], __a849996e1a1fa106b922e1e7262c25bad15f0748b05b39d5f38613d553fc8993__[18], 0) + __hook__('#.', strings, [idx + 1], __a849996e1a1fa106b922e1e7262c25bad15f0748b05b39d5f38613d553fc8993__[18]), null, args, __a849996e1a1fa106b922e1e7262c25bad15f0748b05b39d5f38613d553fc8993__[18]),
        __hook__('#.', strings, [0], __a849996e1a1fa106b922e1e7262c25bad15f0748b05b39d5f38613d553fc8993__[18])
      ]
    ], __a849996e1a1fa106b922e1e7262c25bad15f0748b05b39d5f38613d553fc8993__[18]);
    return __hook__('mnew', CSSResult, [
      __a849996e1a1fa106b922e1e7262c25bad15f0748b05b39d5f38613d553fc8993__[13],
      [
        cssText,
        constructionToken
      ],
      (...args) => new CSSResult(...args)
    ], __a849996e1a1fa106b922e1e7262c25bad15f0748b05b39d5f38613d553fc8993__[17], null);
  }, null, args, __a849996e1a1fa106b922e1e7262c25bad15f0748b05b39d5f38613d553fc8993__[17]));  __hook__(() => {
}, null, [
  'export',
  __a849996e1a1fa106b922e1e7262c25bad15f0748b05b39d5f38613d553fc8993__[0],
  __90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__module_namespace_5
], __a849996e1a1fa106b922e1e7262c25bad15f0748b05b39d5f38613d553fc8993__[0], NaN);

/**
 * @license
 * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
 * This code may only be used under the BSD style license found at
 * http://polymer.github.io/LICENSE.txt
 * The complete set of authors may be found at
 * http://polymer.github.io/AUTHORS.txt
 * The complete set of contributors may be found at
 * http://polymer.github.io/CONTRIBUTORS.txt
 * Code distributed by Google as part of the polymer project is also
 * subject to an additional IP rights grant found at
 * http://polymer.github.io/PATENTS.txt
 */
const __90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__ = $hook$.$(__hook__, [
  '/components/thin-hook/demo/node_modules/lit-element/lit-element.js',
  '/components/thin-hook/demo/node_modules/lit-html/lib/shady-render.js',
  '/components/thin-hook/demo/node_modules/lit-element/lib/updating-element.js',
  '/components/thin-hook/demo/node_modules/lit-element/lib/decorators.js',
  '/components/thin-hook/demo/node_modules/lit-html/lit-html.js',
  '/components/thin-hook/demo/node_modules/lit-element/lib/css-tag.js',
  'S_uNpREdiC4aB1e_window;/components/thin-hook/demo/node_modules/lit-element/lit-element.js',
  '/components/thin-hook/demo/node_modules/lit-element/lit-element.js,LitElement',
  '/components/thin-hook/demo/node_modules/lit-element/lib/updating-element.js,UpdatingElement',
  '/components/thin-hook/demo/node_modules/lit-element/lit-element.js,LitElement,static getStyles',
  '/components/thin-hook/demo/node_modules/lit-element/lit-element.js,LitElement,static _getUniqueStyles',
  'S_uNpREdiC4aB1e_JSCompiler_renameProperty;/components/thin-hook/demo/node_modules/lit-element/lit-element.js,LitElement,static _getUniqueStyles',
  '/components/thin-hook/demo/node_modules/lit-element/lit-element.js,LitElement,static _getUniqueStyles,userStyles',
  'S_uNpREdiC4aB1e_undefined;/components/thin-hook/demo/node_modules/lit-element/lit-element.js,LitElement,static _getUniqueStyles',
  'S_uNpREdiC4aB1e_Array;/components/thin-hook/demo/node_modules/lit-element/lit-element.js,LitElement,static _getUniqueStyles',
  '/components/thin-hook/demo/node_modules/lit-element/lit-element.js,LitElement,static _getUniqueStyles,addStyles',
  'S_uNpREdiC4aB1e_Array;/components/thin-hook/demo/node_modules/lit-element/lit-element.js,LitElement,static _getUniqueStyles,addStyles',
  '/components/thin-hook/demo/node_modules/lit-element/lit-element.js,LitElement,static _getUniqueStyles,set',
  'S_uNpREdiC4aB1e_Set;/components/thin-hook/demo/node_modules/lit-element/lit-element.js,LitElement,static _getUniqueStyles,set',
  '/components/thin-hook/demo/node_modules/lit-element/lit-element.js,LitElement,initialize',
  'S_uNpREdiC4aB1e_window;/components/thin-hook/demo/node_modules/lit-element/lit-element.js,LitElement,initialize',
  '/components/thin-hook/demo/node_modules/lit-element/lit-element.js,LitElement,createRenderRoot',
  '/components/thin-hook/demo/node_modules/lit-element/lit-element.js,LitElement,adoptStyles',
  '/components/thin-hook/demo/node_modules/lit-element/lit-element.js,LitElement,adoptStyles,styles',
  'S_uNpREdiC4aB1e_window;/components/thin-hook/demo/node_modules/lit-element/lit-element.js,LitElement,adoptStyles',
  'S_uNpREdiC4aB1e_undefined;/components/thin-hook/demo/node_modules/lit-element/lit-element.js,LitElement,adoptStyles',
  '/components/thin-hook/demo/node_modules/lit-element/lib/css-tag.js,supportsAdoptingStyleSheets',
  '/components/thin-hook/demo/node_modules/lit-element/lit-element.js,LitElement,connectedCallback',
  'S_uNpREdiC4aB1e_window;/components/thin-hook/demo/node_modules/lit-element/lit-element.js,LitElement,connectedCallback',
  'S_uNpREdiC4aB1e_undefined;/components/thin-hook/demo/node_modules/lit-element/lit-element.js,LitElement,connectedCallback',
  '/components/thin-hook/demo/node_modules/lit-element/lit-element.js,LitElement,update',
  '/components/thin-hook/demo/node_modules/lit-element/lit-element.js,LitElement,update,templateResult',
  '/components/thin-hook/demo/node_modules/lit-element/lit-element.js,LitElement,update,scopeName',
  '/components/thin-hook/demo/node_modules/lit-element/lit-element.js,LitElement,update,style',
  'S_uNpREdiC4aB1e_document;/components/thin-hook/demo/node_modules/lit-element/lit-element.js,LitElement,update,style',
  '/components/thin-hook/demo/node_modules/lit-element/lit-element.js,LitElement,render',
  '/components/thin-hook/demo/node_modules/lit-html/lib/shady-render.js,render'
]);
__hook__(() => {
}, null, [
  'import',
  {
    [__90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__[1]]: [
      __90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__module_namespace_1,
      'render'
    ],
    [__90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__[2]]: [
      __90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__module_namespace_2,
      'UpdatingElement'
    ],
    [__90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__[3]]: [__90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__module_namespace_3],
    [__90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__[4]]: [
      litHtmlNamespace,
      'html',
      'svg',
      'TemplateResult',
      'SVGTemplateResult'
    ],
    [__90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__[5]]: [
      __90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__module_namespace_5,
      'supportsAdoptingStyleSheets'
    ]
  }
], __90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__[0], NaN);
// IMPORTANT: do not change the property name or the assignment expression.
// This line will be used in regexes to search for LitElement usage.
// TODO(justinfagnani): inject version number at build time
__hook__('#()', __hook__('#.', $hook$.global(__hook__, __90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__[0], 'window', '#get')[__90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__[6]], ['litElementVersions'], __90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__[0]) || __hook__('#=', window, [
  'litElementVersions',
  []
], __90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__[0]), [
  'push',
  ['2.3.1']
], __90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__[0]);
/**
 * Sentinal value used to avoid calling lit-html's render function when
 * subclasses do not implement `render`
 */
const renderNotImplemented = {};
class LitElement extends __hook__('m', UpdatingElement, [__90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__[8]], __90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__[7], null) {
  /**
     * Return the array of styles to apply to the element.
     * Override this method to integrate into a style management system.
     *
     * @nocollapse
     */
  static getStyles() {
    return __hook__(() => {
      return __hook__('#.', this, ['styles'], __90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__[9]);
    }, null, arguments, __90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__[9]);
  }
  /** @nocollapse */
  static _getUniqueStyles() {
    return __hook__(() => {
      // Only gather styles once per class
      if (__hook__('#()', this, [
          'hasOwnProperty',
          [__hook__($hook$.global(__hook__, __90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__[10], 'JSCompiler_renameProperty', '#get')[__90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__[11]], null, [
              '_styles',
              this
            ], __90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__[10], 0)]
        ], __90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__[10])) {
        return;
      }
      // Take care not to call `this.getStyles()` multiple times since this
      // generates new CSSResults each time.
      // TODO(sorvell): Since we do not cache CSSResults by input, any
      // shared styles will generate new stylesheet objects, which is wasteful.
      // This should be addressed when a browser ships constructable
      // stylesheets.
      const userStyles = __hook__('#()', this, [
        'getStyles',
        []
      ], __90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__[12]);
      if (userStyles === $hook$.global(__hook__, __90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__[10], 'undefined', '#get')[__90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__[13]]) {
        __hook__('#=', this, [
          '_styles',
          []
        ], __90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__[10]);
      } else if (__hook__('#()', $hook$.global(__hook__, __90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__[10], 'Array', '#get')[__90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__[14]], [
          'isArray',
          [userStyles]
        ], __90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__[10])) {
        // De-duplicate styles preserving the _last_ instance in the set.
        // This is a performance optimization to avoid duplicated styles that can
        // occur especially when composing via subclassing.
        // The last item is kept to try to preserve the cascade order with the
        // assumption that it's most important that last added styles override
        // previous styles.
        const addStyles = (...args) => __hook__((styles, set) => __hook__('#()', styles, [
          'reduceRight',
          [
            (...args) => __hook__((set, s) => // Note: On IE set.add() does not return the set
            __hook__('#()', $hook$.global(__hook__, __90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__[15], 'Array', '#get')[__90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__[16]], [
              'isArray',
              [s]
            ], __90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__[15]) ? __hook__(addStyles, null, [
              s,
              set
            ], __90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__[15], 0) : (__hook__('#()', set, [
              'add',
              [s]
            ], __90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__[15]), set), null, args, __90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__[15]),
            set
          ]
        ], __90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__[15]), null, args, __90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__[15]);
        // Array.from does not work on Set in IE, otherwise return
        // Array.from(addStyles(userStyles, new Set<CSSResult>())).reverse()
        const set = __hook__(addStyles, null, [
          userStyles,
          __hook__($hook$.global(__hook__, __90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__[17], 'Set', '#get')[__90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__[18]], null, [], __90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__[17], true)
        ], __90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__[17], 0);
        const styles = [];
        __hook__('#()', set, [
          'forEach',
          [(...args) => __hook__(v => __hook__('#()', styles, [
              'unshift',
              [v]
            ], __90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__[10]), null, args, __90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__[10])]
        ], __90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__[10]);
        __hook__('#=', this, [
          '_styles',
          styles
        ], __90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__[10]);
      } else {
        __hook__('#=', this, [
          '_styles',
          [userStyles]
        ], __90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__[10]);
      }
    }, null, arguments, __90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__[10]);
  }
  /**
     * Performs element initialization. By default this calls `createRenderRoot`
     * to create the element `renderRoot` node and captures any pre-set values for
     * registered properties.
     */
  initialize() {
    return __hook__(() => {
      __hook__('s()', this, [
        'initialize',
        [],
        p => super[p]
      ], __90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__[19]);
      __hook__('#()', __hook__('#.', this, ['constructor'], __90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__[19]), [
        '_getUniqueStyles',
        []
      ], __90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__[19]);
      __hook__('#=', this, [
        'renderRoot',
        __hook__('#()', this, [
          'createRenderRoot',
          []
        ], __90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__[19])
      ], __90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__[19]);
      // Note, if renderRoot is not a shadowRoot, styles would/could apply to the
      // element's getRootNode(). While this could be done, we're choosing not to
      // support this now since it would require different logic around de-duping.
      if (__hook__('#.', $hook$.global(__hook__, __90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__[19], 'window', '#get')[__90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__[20]], ['ShadowRoot'], __90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__[19]) && __hook__('#.', this, ['renderRoot'], __90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__[19]) instanceof __hook__('#.', $hook$.global(__hook__, __90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__[19], 'window', '#get')[__90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__[20]], ['ShadowRoot'], __90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__[19])) {
        __hook__('#()', this, [
          'adoptStyles',
          []
        ], __90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__[19]);
      }
    }, null, arguments, __90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__[19]);
  }
  /**
     * Returns the node into which the element should render and by default
     * creates and returns an open shadowRoot. Implement to customize where the
     * element's DOM is rendered. For example, to render into the element's
     * childNodes, return `this`.
     * @returns {Element|DocumentFragment} Returns a node into which to render.
     */
  createRenderRoot() {
    return __hook__(() => {
      return __hook__('#()', this, [
        'attachShadow',
        [{ mode: 'open' }]
      ], __90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__[21]);
    }, null, arguments, __90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__[21]);
  }
  /**
     * Applies styling to the element shadowRoot using the `static get styles`
     * property. Styling will apply using `shadowRoot.adoptedStyleSheets` where
     * available and will fallback otherwise. When Shadow DOM is polyfilled,
     * ShadyCSS scopes styles and adds them to the document. When Shadow DOM
     * is available but `adoptedStyleSheets` is not, styles are appended to the
     * end of the `shadowRoot` to [mimic spec
     * behavior](https://wicg.github.io/construct-stylesheets/#using-constructed-stylesheets).
     */
  adoptStyles() {
    return __hook__(() => {
      const styles = __hook__('#.', __hook__('#.', this, ['constructor'], __90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__[23]), ['_styles'], __90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__[23]);
      if (__hook__('#.', styles, ['length'], __90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__[22]) === 0) {
        return;
      }
      // There are three separate cases here based on Shadow DOM support.
      // (1) shadowRoot polyfilled: use ShadyCSS
      // (2) shadowRoot.adoptedStyleSheets available: use it.
      // (3) shadowRoot.adoptedStyleSheets polyfilled: append styles after
      // rendering
      if (__hook__('#.', $hook$.global(__hook__, __90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__[22], 'window', '#get')[__90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__[24]], ['ShadyCSS'], __90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__[22]) !== $hook$.global(__hook__, __90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__[22], 'undefined', '#get')[__90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__[25]] && !__hook__('#.', __hook__('#.', $hook$.global(__hook__, __90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__[22], 'window', '#get')[__90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__[24]], ['ShadyCSS'], __90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__[22]), ['nativeShadow'], __90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__[22])) {
        __hook__('#()', __hook__('#.', __hook__('#.', $hook$.global(__hook__, __90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__[22], 'window', '#get')[__90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__[24]], ['ShadyCSS'], __90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__[22]), ['ScopingShim'], __90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__[22]), [
          'prepareAdoptedCssText',
          [
            __hook__('#()', styles, [
              'map',
              [(...args) => __hook__(s => __hook__('#.', s, ['cssText'], __90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__[22]), null, args, __90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__[22])]
            ], __90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__[22]),
            __hook__('#.', this, ['localName'], __90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__[22])
          ]
        ], __90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__[22]);
      } else if (__hook__('m', supportsAdoptingStyleSheets, [__90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__[26]], __90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__[22], null)) {
        __hook__('#=', __hook__('#.', this, ['renderRoot'], __90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__[22]), [
          'adoptedStyleSheets',
          __hook__('#()', styles, [
            'map',
            [(...args) => __hook__(s => __hook__('#.', s, ['styleSheet'], __90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__[22]), null, args, __90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__[22])]
          ], __90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__[22])
        ], __90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__[22]);
      } else {
        // This must be done after rendering so the actual style insertion is done
        // in `update`.
        __hook__('#=', this, [
          '_needsShimAdoptedStyleSheets',
          true
        ], __90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__[22]);
      }
    }, null, arguments, __90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__[22]);
  }
  connectedCallback() {
    return __hook__(() => {
      __hook__('s()', this, [
        'connectedCallback',
        [],
        p => super[p]
      ], __90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__[27]);
      // Note, first update/render handles styleElement so we only call this if
      // connected after first update.
      if (__hook__('#.', this, ['hasUpdated'], __90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__[27]) && __hook__('#.', $hook$.global(__hook__, __90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__[27], 'window', '#get')[__90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__[28]], ['ShadyCSS'], __90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__[27]) !== $hook$.global(__hook__, __90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__[27], 'undefined', '#get')[__90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__[29]]) {
        __hook__('#()', __hook__('#.', $hook$.global(__hook__, __90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__[27], 'window', '#get')[__90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__[28]], ['ShadyCSS'], __90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__[27]), [
          'styleElement',
          [this]
        ], __90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__[27]);
      }
    }, null, arguments, __90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__[27]);
  }
  /**
     * Updates the element. This method reflects property values to attributes
     * and calls `render` to render DOM via lit-html. Setting properties inside
     * this method will *not* trigger another update.
     * @param _changedProperties Map of changed properties with old values
     */
  update(changedProperties) {
    return __hook__(changedProperties => {
      // Setting properties in `render` should not trigger an update. Since
      // updates are allowed after super.update, it's important to call `render`
      // before that.
      const templateResult = __hook__('#()', this, [
        'render',
        []
      ], __90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__[31]);
      __hook__('s()', this, [
        'update',
        [changedProperties],
        p => super[p]
      ], __90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__[30]);
      // If render is not implemented by the component, don't call lit-html render
      if (templateResult !== renderNotImplemented) {
        __hook__('#()', __hook__('#.', this, ['constructor'], __90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__[30]), [
          'render',
          [
            templateResult,
            __hook__('#.', this, ['renderRoot'], __90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__[30]),
            {
              scopeName: __hook__('#.', this, ['localName'], __90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__[32]),
              eventContext: this
            }
          ]
        ], __90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__[30]);
      }
      // When native Shadow DOM is used but adoptedStyles are not supported,
      // insert styling after rendering to ensure adoptedStyles have highest
      // priority.
      if (__hook__('#.', this, ['_needsShimAdoptedStyleSheets'], __90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__[30])) {
        __hook__('#=', this, [
          '_needsShimAdoptedStyleSheets',
          false
        ], __90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__[30]);
        __hook__('#()', __hook__('#.', __hook__('#.', this, ['constructor'], __90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__[30]), ['_styles'], __90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__[30]), [
          'forEach',
          [(...args) =>
              (__hook__(s => {
                const style = __hook__('#()', $hook$.global(__hook__, __90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__[33], 'document', '#get')[__90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__[34]], [
                  'createElement',
                  ['style']
                ], __90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__[33]);
                __hook__('#=', style, [
                  'textContent',
                  __hook__('#.', s, ['cssText'], __90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__[30])
                ], __90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__[30]);
                __hook__('#()', __hook__('#.', this, ['renderRoot'], __90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__[30]), [
                  'appendChild',
                  [style]
                ], __90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__[30]);
              }, null, args, __90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__[30]))]
        ], __90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__[30]);
      }
    }, null, arguments, __90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__[30]);
  }
  /**
     * Invoked on each update to perform rendering tasks. This method may return
     * any value renderable by lit-html's NodePart - typically a TemplateResult.
     * Setting properties inside this method will *not* trigger the element to
     * update.
     */
  render() {
    return __hook__(() => {
      return renderNotImplemented;
    }, null, arguments, __90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__[35]);
  }
}
/**
 * Ensure this class is marked as `finalized` as an optimization ensuring
 * it will not needlessly try to `finalize`.
 *
 * Note this property name is a string to prevent breaking Closure JS Compiler
 * optimizations. See updating-element.ts for more information.
 */
__hook__('#=', __hook__('m', LitElement, [__90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__[7]], __90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__[0], null), [
  'finalized',
  true
], __90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__[0]);
/**
 * Render method used to render the value to the element's DOM.
 * @param result The value to render.
 * @param container Node into which to render.
 * @param options Element name.
 * @nocollapse
 */
__hook__('#=', __hook__('m', LitElement, [__90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__[7]], __90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__[0], null), [
  'render',
  __hook__('m', render$1, [__90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__[36]], __90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__[0], null)
], __90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__[0]);  __hook__(() => {
}, null, [
  'export',
  __90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__[0],
  __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__module_namespace_1
], __90693844b86f4d9de9bee5c9026eefe73aa20a0dcf4c48ca6c0898a0743e76a8__[0], NaN);

/**
 * @license
 * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
 * This code may only be used under the BSD style license found at
 * http://polymer.github.io/LICENSE.txt
 * The complete set of authors may be found at
 * http://polymer.github.io/AUTHORS.txt
 * The complete set of contributors may be found at
 * http://polymer.github.io/CONTRIBUTORS.txt
 * Code distributed by Google as part of the polymer project is also
 * subject to an additional IP rights grant found at
 * http://polymer.github.io/PATENTS.txt
 */
const __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__ = $hook$.$(__hook__, [
  '/components/thin-hook/demo/node_modules/lit-html/directives/repeat.js',
  '/components/thin-hook/demo/node_modules/lit-html/lit-html.js',
  '/components/thin-hook/demo/node_modules/lit-html/directives/repeat.js,createAndInsertPart',
  '/components/thin-hook/demo/node_modules/lit-html/directives/repeat.js,createAndInsertPart,container',
  '/components/thin-hook/demo/node_modules/lit-html/directives/repeat.js,createAndInsertPart,beforeNode',
  'S_uNpREdiC4aB1e_undefined;/components/thin-hook/demo/node_modules/lit-html/directives/repeat.js,createAndInsertPart,beforeNode',
  '/components/thin-hook/demo/node_modules/lit-html/directives/repeat.js,createAndInsertPart,startNode',
  '/components/thin-hook/demo/node_modules/lit-html/lit-html.js,createMarker',
  '/components/thin-hook/demo/node_modules/lit-html/directives/repeat.js,createAndInsertPart,newPart',
  '/components/thin-hook/demo/node_modules/lit-html/lit-html.js,NodePart',
  '/components/thin-hook/demo/node_modules/lit-html/directives/repeat.js,updatePart',
  '/components/thin-hook/demo/node_modules/lit-html/directives/repeat.js,insertPartBefore',
  '/components/thin-hook/demo/node_modules/lit-html/directives/repeat.js,insertPartBefore,container',
  '/components/thin-hook/demo/node_modules/lit-html/directives/repeat.js,insertPartBefore,beforeNode',
  '/components/thin-hook/demo/node_modules/lit-html/directives/repeat.js,insertPartBefore,endNode',
  '/components/thin-hook/demo/node_modules/lit-html/lit-html.js,reparentNodes',
  '/components/thin-hook/demo/node_modules/lit-html/directives/repeat.js,removePart',
  '/components/thin-hook/demo/node_modules/lit-html/lit-html.js,removeNodes',
  '/components/thin-hook/demo/node_modules/lit-html/directives/repeat.js,generateMap',
  '/components/thin-hook/demo/node_modules/lit-html/directives/repeat.js,generateMap,map',
  'S_uNpREdiC4aB1e_Map;/components/thin-hook/demo/node_modules/lit-html/directives/repeat.js,generateMap,map',
  '/components/thin-hook/demo/node_modules/lit-html/directives/repeat.js,partListCache',
  'S_uNpREdiC4aB1e_WeakMap;/components/thin-hook/demo/node_modules/lit-html/directives/repeat.js,partListCache',
  '/components/thin-hook/demo/node_modules/lit-html/directives/repeat.js,keyListCache',
  'S_uNpREdiC4aB1e_WeakMap;/components/thin-hook/demo/node_modules/lit-html/directives/repeat.js,keyListCache',
  '/components/thin-hook/demo/node_modules/lit-html/directives/repeat.js,repeat',
  '/components/thin-hook/demo/node_modules/lit-html/lit-html.js,directive',
  'S_uNpREdiC4aB1e_undefined;/components/thin-hook/demo/node_modules/lit-html/directives/repeat.js,repeat',
  'S_uNpREdiC4aB1e_Error;/components/thin-hook/demo/node_modules/lit-html/directives/repeat.js,repeat',
  '/components/thin-hook/demo/node_modules/lit-html/directives/repeat.js,repeat,oldParts',
  '/components/thin-hook/demo/node_modules/lit-html/directives/repeat.js,repeat,oldKeys',
  '/components/thin-hook/demo/node_modules/lit-html/directives/repeat.js,repeat,oldTail',
  '/components/thin-hook/demo/node_modules/lit-html/directives/repeat.js,repeat,newTail',
  '/components/thin-hook/demo/node_modules/lit-html/directives/repeat.js,repeat,oldIndex',
  '/components/thin-hook/demo/node_modules/lit-html/directives/repeat.js,repeat,oldPart',
  'S_uNpREdiC4aB1e_undefined;/components/thin-hook/demo/node_modules/lit-html/directives/repeat.js,repeat,oldPart',
  '/components/thin-hook/demo/node_modules/lit-html/directives/repeat.js,repeat,newPart'
]);
__hook__(() => {
}, null, [
  'import',
  {
    [__b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[1]]: [
      litHtmlNamespace,
      'createMarker',
      'directive',
      'NodePart',
      'removeNodes',
      'reparentNodes'
    ]
  }
], __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[0], NaN);
// Helper functions for manipulating parts
// TODO(kschaaf): Refactor into Part API?
const createAndInsertPart = (...args) =>
  (__hook__((containerPart, beforePart) => {
    const container = __hook__('#.', __hook__('#.', containerPart, ['startNode'], __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[3]), ['parentNode'], __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[3]);
    const beforeNode = beforePart === $hook$.global(__hook__, __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[4], 'undefined', '#get')[__b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[5]] ? __hook__('#.', containerPart, ['endNode'], __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[4]) : __hook__('#.', beforePart, ['startNode'], __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[4]);
    const startNode = __hook__('#()', container, [
      'insertBefore',
      [
        __hook__('m()', createMarker, [
          __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[7],
          [],
          (...args) => createMarker(...args)
        ], __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[6], null),
        beforeNode
      ]
    ], __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[6]);
    __hook__('#()', container, [
      'insertBefore',
      [
        __hook__('m()', createMarker, [
          __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[7],
          [],
          (...args) => createMarker(...args)
        ], __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[2], null),
        beforeNode
      ]
    ], __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[2]);
    const newPart = __hook__('mnew', NodePart, [
      __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[9],
      [__hook__('#.', containerPart, ['options'], __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[8])],
      (...args) => new NodePart(...args)
    ], __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[8], null);
    __hook__('#()', newPart, [
      'insertAfterNode',
      [startNode]
    ], __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[2]);
    return newPart;
  }, null, args, __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[2]));
const updatePart = (...args) =>
  (__hook__((part, value) => {
    __hook__('#()', part, [
      'setValue',
      [value]
    ], __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[10]);
    __hook__('#()', part, [
      'commit',
      []
    ], __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[10]);
    return part;
  }, null, args, __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[10]));
const insertPartBefore = (...args) =>
  (__hook__((containerPart, part, ref) => {
    const container = __hook__('#.', __hook__('#.', containerPart, ['startNode'], __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[12]), ['parentNode'], __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[12]);
    const beforeNode = ref ? __hook__('#.', ref, ['startNode'], __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[13]) : __hook__('#.', containerPart, ['endNode'], __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[13]);
    const endNode = __hook__('#.', __hook__('#.', part, ['endNode'], __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[14]), ['nextSibling'], __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[14]);
    if (endNode !== beforeNode) {
      __hook__('m()', reparentNodes, [
        __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[15],
        [
          container,
          __hook__('#.', part, ['startNode'], __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[11]),
          endNode,
          beforeNode
        ],
        (...args) => reparentNodes(...args)
      ], __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[11], null);
    }
  }, null, args, __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[11]));
const removePart = (...args) =>
  (__hook__(part => {
    __hook__('m()', removeNodes, [
      __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[17],
      [
        __hook__('#.', __hook__('#.', part, ['startNode'], __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[16]), ['parentNode'], __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[16]),
        __hook__('#.', part, ['startNode'], __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[16]),
        __hook__('#.', __hook__('#.', part, ['endNode'], __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[16]), ['nextSibling'], __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[16])
      ],
      (...args) => removeNodes(...args)
    ], __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[16], null);
  }, null, args, __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[16]));
// Helper for generating a map of array item to its index over a subset
// of an array (used to lazily generate `newKeyToIndexMap` and
// `oldKeyToIndexMap`)
const generateMap = (...args) =>
  (__hook__((list, start, end) => {
    const map = __hook__($hook$.global(__hook__, __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[19], 'Map', '#get')[__b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[20]], null, [], __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[19], true);
    for (let i = start; i <= end; i++) {
      __hook__('#()', map, [
        'set',
        [
          __hook__('#.', list, [i], __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[18]),
          i
        ]
      ], __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[18]);
    }
    return map;
  }, null, args, __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[18]));
// Stores previous ordered list of parts and map of key to index
const partListCache = __hook__($hook$.global(__hook__, __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[21], 'WeakMap', '#get')[__b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[22]], null, [], __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[21], true);
const keyListCache = __hook__($hook$.global(__hook__, __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[23], 'WeakMap', '#get')[__b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[24]], null, [], __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[23], true);
/**
 * A directive that repeats a series of values (usually `TemplateResults`)
 * generated from an iterable, and updates those items efficiently when the
 * iterable changes based on user-provided `keys` associated with each item.
 *
 * Note that if a `keyFn` is provided, strict key-to-DOM mapping is maintained,
 * meaning previous DOM for a given key is moved into the new position if
 * needed, and DOM will never be reused with values for different keys (new DOM
 * will always be created for new keys). This is generally the most efficient
 * way to use `repeat` since it performs minimum unnecessary work for insertions
 * and removals.
 *
 * IMPORTANT: If providing a `keyFn`, keys *must* be unique for all items in a
 * given call to `repeat`. The behavior when two or more items have the same key
 * is undefined.
 *
 * If no `keyFn` is provided, this directive will perform similar to mapping
 * items to values, and DOM will be reused against potentially different items.
 */
const repeat = __hook__('m()', directive, [
  __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[26],
  [(...args) =>
      (__hook__((items, keyFnOrTemplate, template) => {
        let keyFn;
        if (template === $hook$.global(__hook__, __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[25], 'undefined', '#get')[__b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[27]]) {
          template = keyFnOrTemplate;
        } else if (keyFnOrTemplate !== $hook$.global(__hook__, __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[25], 'undefined', '#get')[__b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[27]]) {
          keyFn = keyFnOrTemplate;
        }
        return (...args) =>
          (__hook__(containerPart => {
            if (!(containerPart instanceof __hook__('m', NodePart, [__b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[9]], __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[25], null))) {
              throw __hook__($hook$.global(__hook__, __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[25], 'Error', '#get')[__b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[28]], null, ['repeat can only be used in text bindings'], __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[25], true);
            }
            // Old part & key lists are retrieved from the last update
            // (associated with the part for this instance of the directive)
            const oldParts = __hook__('#()', partListCache, [
              'get',
              [containerPart]
            ], __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[29]) || [];
            const oldKeys = __hook__('#()', keyListCache, [
              'get',
              [containerPart]
            ], __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[30]) || [];
            // New part list will be built up as we go (either reused from
            // old parts or created for new keys in this update). This is
            // saved in the above cache at the end of the update.
            const newParts = [];
            // New value list is eagerly generated from items along with a
            // parallel array indicating its key.
            const newValues = [];
            const newKeys = [];
            let index = 0;
            for (const item of __hook__('#*', items, [], __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[25])) {
              __hook__('#=', newKeys, [
                index,
                keyFn ? __hook__(keyFn, null, [
                  item,
                  index
                ], __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[25], 0) : index
              ], __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[25]);
              __hook__('#=', newValues, [
                index,
                __hook__(template, null, [
                  item,
                  index
                ], __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[25], 0)
              ], __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[25]);
              index++;
            }
            // Maps from key to index for current and previous update; these
            // are generated lazily only when needed as a performance
            // optimization, since they are only required for multiple
            // non-contiguous changes in the list, which are less common.
            let newKeyToIndexMap;
            let oldKeyToIndexMap;
            // Head and tail pointers to old parts and new values
            let oldHead = 0;
            let oldTail = __hook__('#.', oldParts, ['length'], __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[31]) - 1;
            let newHead = 0;
            let newTail = __hook__('#.', newValues, ['length'], __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[32]) - 1;
            // Overview of O(n) reconciliation algorithm (general approach
            // based on ideas found in ivi, vue, snabbdom, etc.):
            //
            // * We start with the list of old parts and new values (and
            //   arrays of their respective keys), head/tail pointers into
            //   each, and we build up the new list of parts by updating
            //   (and when needed, moving) old parts or creating new ones.
            //   The initial scenario might look like this (for brevity of
            //   the diagrams, the numbers in the array reflect keys
            //   associated with the old parts or new values, although keys
            //   and parts/values are actually stored in parallel arrays
            //   indexed using the same head/tail pointers):
            //
            //      oldHead v                 v oldTail
            //   oldKeys:  [0, 1, 2, 3, 4, 5, 6]
            //   newParts: [ ,  ,  ,  ,  ,  ,  ]
            //   newKeys:  [0, 2, 1, 4, 3, 7, 6] <- reflects the user's new
            //                                      item order
            //      newHead ^                 ^ newTail
            //
            // * Iterate old & new lists from both sides, updating,
            //   swapping, or removing parts at the head/tail locations
            //   until neither head nor tail can move.
            //
            // * Example below: keys at head pointers match, so update old
            //   part 0 in-place (no need to move it) and record part 0 in
            //   the `newParts` list. The last thing we do is advance the
            //   `oldHead` and `newHead` pointers (will be reflected in the
            //   next diagram).
            //
            //      oldHead v                 v oldTail
            //   oldKeys:  [0, 1, 2, 3, 4, 5, 6]
            //   newParts: [0,  ,  ,  ,  ,  ,  ] <- heads matched: update 0
            //   newKeys:  [0, 2, 1, 4, 3, 7, 6]    and advance both oldHead
            //                                      & newHead
            //      newHead ^                 ^ newTail
            //
            // * Example below: head pointers don't match, but tail
            //   pointers do, so update part 6 in place (no need to move
            //   it), and record part 6 in the `newParts` list. Last,
            //   advance the `oldTail` and `oldHead` pointers.
            //
            //         oldHead v              v oldTail
            //   oldKeys:  [0, 1, 2, 3, 4, 5, 6]
            //   newParts: [0,  ,  ,  ,  ,  , 6] <- tails matched: update 6
            //   newKeys:  [0, 2, 1, 4, 3, 7, 6]    and advance both oldTail
            //                                      & newTail
            //         newHead ^              ^ newTail
            //
            // * If neither head nor tail match; next check if one of the
            //   old head/tail items was removed. We first need to generate
            //   the reverse map of new keys to index (`newKeyToIndexMap`),
            //   which is done once lazily as a performance optimization,
            //   since we only hit this case if multiple non-contiguous
            //   changes were made. Note that for contiguous removal
            //   anywhere in the list, the head and tails would advance
            //   from either end and pass each other before we get to this
            //   case and removals would be handled in the final while loop
            //   without needing to generate the map.
            //
            // * Example below: The key at `oldTail` was removed (no longer
            //   in the `newKeyToIndexMap`), so remove that part from the
            //   DOM and advance just the `oldTail` pointer.
            //
            //         oldHead v           v oldTail
            //   oldKeys:  [0, 1, 2, 3, 4, 5, 6]
            //   newParts: [0,  ,  ,  ,  ,  , 6] <- 5 not in new map: remove
            //   newKeys:  [0, 2, 1, 4, 3, 7, 6]    5 and advance oldTail
            //         newHead ^           ^ newTail
            //
            // * Once head and tail cannot move, any mismatches are due to
            //   either new or moved items; if a new key is in the previous
            //   "old key to old index" map, move the old part to the new
            //   location, otherwise create and insert a new part. Note
            //   that when moving an old part we null its position in the
            //   oldParts array if it lies between the head and tail so we
            //   know to skip it when the pointers get there.
            //
            // * Example below: neither head nor tail match, and neither
            //   were removed; so find the `newHead` key in the
            //   `oldKeyToIndexMap`, and move that old part's DOM into the
            //   next head position (before `oldParts[oldHead]`). Last,
            //   null the part in the `oldPart` array since it was
            //   somewhere in the remaining oldParts still to be scanned
            //   (between the head and tail pointers) so that we know to
            //   skip that old part on future iterations.
            //
            //         oldHead v        v oldTail
            //   oldKeys:  [0, 1, -, 3, 4, 5, 6]
            //   newParts: [0, 2,  ,  ,  ,  , 6] <- stuck: update & move 2
            //   newKeys:  [0, 2, 1, 4, 3, 7, 6]    into place and advance
            //                                      newHead
            //         newHead ^           ^ newTail
            //
            // * Note that for moves/insertions like the one above, a part
            //   inserted at the head pointer is inserted before the
            //   current `oldParts[oldHead]`, and a part inserted at the
            //   tail pointer is inserted before `newParts[newTail+1]`. The
            //   seeming asymmetry lies in the fact that new parts are
            //   moved into place outside in, so to the right of the head
            //   pointer are old parts, and to the right of the tail
            //   pointer are new parts.
            //
            // * We always restart back from the top of the algorithm,
            //   allowing matching and simple updates in place to
            //   continue...
            //
            // * Example below: the head pointers once again match, so
            //   simply update part 1 and record it in the `newParts`
            //   array.  Last, advance both head pointers.
            //
            //         oldHead v        v oldTail
            //   oldKeys:  [0, 1, -, 3, 4, 5, 6]
            //   newParts: [0, 2, 1,  ,  ,  , 6] <- heads matched: update 1
            //   newKeys:  [0, 2, 1, 4, 3, 7, 6]    and advance both oldHead
            //                                      & newHead
            //            newHead ^        ^ newTail
            //
            // * As mentioned above, items that were moved as a result of
            //   being stuck (the final else clause in the code below) are
            //   marked with null, so we always advance old pointers over
            //   these so we're comparing the next actual old value on
            //   either end.
            //
            // * Example below: `oldHead` is null (already placed in
            //   newParts), so advance `oldHead`.
            //
            //            oldHead v     v oldTail
            //   oldKeys:  [0, 1, -, 3, 4, 5, 6] <- old head already used:
            //   newParts: [0, 2, 1,  ,  ,  , 6]    advance oldHead
            //   newKeys:  [0, 2, 1, 4, 3, 7, 6]
            //               newHead ^     ^ newTail
            //
            // * Note it's not critical to mark old parts as null when they
            //   are moved from head to tail or tail to head, since they
            //   will be outside the pointer range and never visited again.
            //
            // * Example below: Here the old tail key matches the new head
            //   key, so the part at the `oldTail` position and move its
            //   DOM to the new head position (before `oldParts[oldHead]`).
            //   Last, advance `oldTail` and `newHead` pointers.
            //
            //               oldHead v  v oldTail
            //   oldKeys:  [0, 1, -, 3, 4, 5, 6]
            //   newParts: [0, 2, 1, 4,  ,  , 6] <- old tail matches new
            //   newKeys:  [0, 2, 1, 4, 3, 7, 6]   head: update & move 4,
            //                                     advance oldTail & newHead
            //               newHead ^     ^ newTail
            //
            // * Example below: Old and new head keys match, so update the
            //   old head part in place, and advance the `oldHead` and
            //   `newHead` pointers.
            //
            //               oldHead v oldTail
            //   oldKeys:  [0, 1, -, 3, 4, 5, 6]
            //   newParts: [0, 2, 1, 4, 3,   ,6] <- heads match: update 3
            //   newKeys:  [0, 2, 1, 4, 3, 7, 6]    and advance oldHead &
            //                                      newHead
            //                  newHead ^  ^ newTail
            //
            // * Once the new or old pointers move past each other then all
            //   we have left is additions (if old list exhausted) or
            //   removals (if new list exhausted). Those are handled in the
            //   final while loops at the end.
            //
            // * Example below: `oldHead` exceeded `oldTail`, so we're done
            //   with the main loop.  Create the remaining part and insert
            //   it at the new head position, and the update is complete.
            //
            //                   (oldHead > oldTail)
            //   oldKeys:  [0, 1, -, 3, 4, 5, 6]
            //   newParts: [0, 2, 1, 4, 3, 7 ,6] <- create and insert 7
            //   newKeys:  [0, 2, 1, 4, 3, 7, 6]
            //                     newHead ^ newTail
            //
            // * Note that the order of the if/else clauses is not
            //   important to the algorithm, as long as the null checks
            //   come first (to ensure we're always working on valid old
            //   parts) and that the final else clause comes last (since
            //   that's where the expensive moves occur). The order of
            //   remaining clauses is is just a simple guess at which cases
            //   will be most common.
            //
            // * TODO(kschaaf) Note, we could calculate the longest
            //   increasing subsequence (LIS) of old items in new position,
            //   and only move those not in the LIS set. However that costs
            //   O(nlogn) time and adds a bit more code, and only helps
            //   make rare types of mutations require fewer moves. The
            //   above handles removes, adds, reversal, swaps, and single
            //   moves of contiguous items in linear time, in the minimum
            //   number of moves. As the number of multiple moves where LIS
            //   might help approaches a random shuffle, the LIS
            //   optimization becomes less helpful, so it seems not worth
            //   the code at this point. Could reconsider if a compelling
            //   case arises.
            while (oldHead <= oldTail && newHead <= newTail) {
              if (__hook__('#.', oldParts, [oldHead], __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[25]) === null) {
                // `null` means old part at head has already been used
                // below; skip
                oldHead++;
              } else if (__hook__('#.', oldParts, [oldTail], __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[25]) === null) {
                // `null` means old part at tail has already been used
                // below; skip
                oldTail--;
              } else if (__hook__('#.', oldKeys, [oldHead], __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[25]) === __hook__('#.', newKeys, [newHead], __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[25])) {
                // Old head matches new head; update in place
                __hook__('#=', newParts, [
                  newHead,
                  __hook__(updatePart, null, [
                    __hook__('#.', oldParts, [oldHead], __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[25]),
                    __hook__('#.', newValues, [newHead], __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[25])
                  ], __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[25], 0)
                ], __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[25]);
                oldHead++;
                newHead++;
              } else if (__hook__('#.', oldKeys, [oldTail], __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[25]) === __hook__('#.', newKeys, [newTail], __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[25])) {
                // Old tail matches new tail; update in place
                __hook__('#=', newParts, [
                  newTail,
                  __hook__(updatePart, null, [
                    __hook__('#.', oldParts, [oldTail], __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[25]),
                    __hook__('#.', newValues, [newTail], __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[25])
                  ], __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[25], 0)
                ], __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[25]);
                oldTail--;
                newTail--;
              } else if (__hook__('#.', oldKeys, [oldHead], __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[25]) === __hook__('#.', newKeys, [newTail], __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[25])) {
                // Old head matches new tail; update and move to new tail
                __hook__('#=', newParts, [
                  newTail,
                  __hook__(updatePart, null, [
                    __hook__('#.', oldParts, [oldHead], __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[25]),
                    __hook__('#.', newValues, [newTail], __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[25])
                  ], __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[25], 0)
                ], __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[25]);
                __hook__(insertPartBefore, null, [
                  containerPart,
                  __hook__('#.', oldParts, [oldHead], __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[25]),
                  __hook__('#.', newParts, [newTail + 1], __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[25])
                ], __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[25], 0);
                oldHead++;
                newTail--;
              } else if (__hook__('#.', oldKeys, [oldTail], __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[25]) === __hook__('#.', newKeys, [newHead], __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[25])) {
                // Old tail matches new head; update and move to new head
                __hook__('#=', newParts, [
                  newHead,
                  __hook__(updatePart, null, [
                    __hook__('#.', oldParts, [oldTail], __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[25]),
                    __hook__('#.', newValues, [newHead], __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[25])
                  ], __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[25], 0)
                ], __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[25]);
                __hook__(insertPartBefore, null, [
                  containerPart,
                  __hook__('#.', oldParts, [oldTail], __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[25]),
                  __hook__('#.', oldParts, [oldHead], __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[25])
                ], __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[25], 0);
                oldTail--;
                newHead++;
              } else {
                if (newKeyToIndexMap === $hook$.global(__hook__, __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[25], 'undefined', '#get')[__b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[27]]) {
                  // Lazily generate key-to-index maps, used for removals &
                  // moves below
                  newKeyToIndexMap = __hook__(generateMap, null, [
                    newKeys,
                    newHead,
                    newTail
                  ], __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[25], 0);
                  oldKeyToIndexMap = __hook__(generateMap, null, [
                    oldKeys,
                    oldHead,
                    oldTail
                  ], __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[25], 0);
                }
                if (!__hook__('#()', newKeyToIndexMap, [
                    'has',
                    [__hook__('#.', oldKeys, [oldHead], __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[25])]
                  ], __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[25])) {
                  // Old head is no longer in new list; remove
                  __hook__(removePart, null, [__hook__('#.', oldParts, [oldHead], __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[25])], __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[25], 0);
                  oldHead++;
                } else if (!__hook__('#()', newKeyToIndexMap, [
                    'has',
                    [__hook__('#.', oldKeys, [oldTail], __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[25])]
                  ], __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[25])) {
                  // Old tail is no longer in new list; remove
                  __hook__(removePart, null, [__hook__('#.', oldParts, [oldTail], __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[25])], __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[25], 0);
                  oldTail--;
                } else {
                  // Any mismatches at this point are due to additions or
                  // moves; see if we have an old part we can reuse and move
                  // into place
                  const oldIndex = __hook__('#()', oldKeyToIndexMap, [
                    'get',
                    [__hook__('#.', newKeys, [newHead], __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[33])]
                  ], __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[33]);
                  const oldPart = oldIndex !== $hook$.global(__hook__, __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[34], 'undefined', '#get')[__b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[35]] ? __hook__('#.', oldParts, [oldIndex], __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[34]) : null;
                  if (oldPart === null) {
                    // No old part for this value; create a new one and
                    // insert it
                    const newPart = __hook__(createAndInsertPart, null, [
                      containerPart,
                      __hook__('#.', oldParts, [oldHead], __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[36])
                    ], __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[36], 0);
                    __hook__(updatePart, null, [
                      newPart,
                      __hook__('#.', newValues, [newHead], __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[25])
                    ], __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[25], 0);
                    __hook__('#=', newParts, [
                      newHead,
                      newPart
                    ], __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[25]);
                  } else {
                    // Reuse old part
                    __hook__('#=', newParts, [
                      newHead,
                      __hook__(updatePart, null, [
                        oldPart,
                        __hook__('#.', newValues, [newHead], __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[25])
                      ], __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[25], 0)
                    ], __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[25]);
                    __hook__(insertPartBefore, null, [
                      containerPart,
                      oldPart,
                      __hook__('#.', oldParts, [oldHead], __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[25])
                    ], __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[25], 0);
                    // This marks the old part as having been used, so that
                    // it will be skipped in the first two checks above
                    __hook__('#=', oldParts, [
                      oldIndex,
                      null
                    ], __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[25]);
                  }
                  newHead++;
                }
              }
            }
            // Add parts for any remaining new values
            while (newHead <= newTail) {
              // For all remaining additions, we insert before last new
              // tail, since old pointers are no longer valid
              const newPart = __hook__(createAndInsertPart, null, [
                containerPart,
                __hook__('#.', newParts, [newTail + 1], __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[36])
              ], __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[36], 0);
              __hook__(updatePart, null, [
                newPart,
                __hook__('#.', newValues, [newHead], __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[25])
              ], __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[25], 0);
              __hook__('#=', newParts, [
                newHead++,
                newPart
              ], __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[25]);
            }
            // Remove any remaining unused old parts
            while (oldHead <= oldTail) {
              const oldPart = __hook__('#.', oldParts, [oldHead++], __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[34]);
              if (oldPart !== null) {
                __hook__(removePart, null, [oldPart], __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[25], 0);
              }
            }
            // Save order of new parts for next round
            __hook__('#()', partListCache, [
              'set',
              [
                containerPart,
                newParts
              ]
            ], __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[25]);
            __hook__('#()', keyListCache, [
              'set',
              [
                containerPart,
                newKeys
              ]
            ], __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[25]);
          }, null, args, __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[25]));
      }, null, args, __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[25]))],
  (...args) => directive(...args)
], __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[25], null);  __hook__(() => {
}, null, [
  'export',
  __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[0],
  __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__module_namespace_2
], __b15b4641592e06cb6bd58e2388a36a7686fd420263ed87c79d1810ba30d7006d__[0], NaN);

const __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__ = $hook$.$(__hook__, [
  '/components/thin-hook/demo/modules/module2.js',
  '/components/thin-hook/demo/modules/module2.js,inaccessibleSymbol',
  'S_uNpREdiC4aB1e_Symbol;/components/thin-hook/demo/modules/module2.js,inaccessibleSymbol',
  '/components/thin-hook/demo/modules/module2.js,inaccessibleUndefined',
  'S_uNpREdiC4aB1e_undefined;/components/thin-hook/demo/modules/module2.js,inaccessibleUndefined',
  '/components/thin-hook/demo/modules/module2.js,inaccessibleBigInt',
  'S_uNpREdiC4aB1e_BigInt;/components/thin-hook/demo/modules/module2.js,inaccessibleBigInt',
  '/components/thin-hook/demo/modules/module2.js,inaccessibleFunction,inaccessibleFunction',
  '/components/thin-hook/demo/modules/module2.js,ExportedClass,constructor',
  '/components/thin-hook/demo/modules/module2.js,ExportedClass,static callableStaticMethod',
  '/components/thin-hook/demo/modules/module2.js,ExportedClass,callableMethod',
  '/components/thin-hook/demo/modules/module2.js,exportedName',
  'S_uNpREdiC4aB1e_chai;/components/thin-hook/demo/modules/module2.js',
  '/components/thin-hook/demo/modules/module2.js,inaccessibleString',
  '/components/thin-hook/demo/modules/module2.js,inaccessibleNumber',
  '/components/thin-hook/demo/modules/module2.js,inaccessibleBoolean',
  '/components/thin-hook/demo/modules/module2.js,inaccessibleNull',
  '/components/thin-hook/demo/modules/module2.js,inaccessibleFunction',
  '/components/thin-hook/demo/modules/module2.js,inaccessibleObject'
]);
let exportedName = 'exportedNameOriginalValue';
// writable only in module2
let exportedName2 = 'exportedName2Value';
// exported but inaccessible
let inaccessibleString = 'inaccessible string value';
let inaccessibleNumber = -1;
let inaccessibleBoolean = false;
let inaccessibleSymbol = __hook__($hook$.global(__hook__, __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[1], 'Symbol', '#get')[__491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[2]], null, ['inaccessible'], __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[1], 0);
let inaccessibleNull = null;
let inaccessibleUndefined = $hook$.global(__hook__, __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[3], 'undefined', '#get')[__491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[4]];
let inaccessibleBigInt = __hook__($hook$.global(__hook__, __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[5], 'BigInt', '#get')[__491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[6]], null, ['1000000000000000000000000000000000000000'], __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[5], 0);
let inaccessibleFunction = function inaccessibleFunction() {
  return __hook__(() => {
  }, null, arguments, __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[7]);
};
let inaccessibleObject = { inaccessible: true };
class ExportedClass {
  constructor() {
    return __hook__(() => {
      __hook__('#=', this, [
        'readableProperty',
        'readable'
      ], __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[8]);
      __hook__('#=', this, [
        'unreadableProperty',
        'unreadable'
      ], __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[8]);
    }, null, arguments, __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[8]);
  }
  static callableStaticMethod() {
    return __hook__(() => {
      return 'called';
    }, null, arguments, __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[9]);
  }
  callableMethod(x) {
    return __hook__(x => {
      return typeof x;
    }, null, arguments, __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[10]);
  }
}
// write
__hook__('m=', exportedName, [
  __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[11],
  'exportedNameValue',
  v => exportedName = v
], __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0], null);
__hook__('#()', __hook__('#.', $hook$.global(__hook__, __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0], 'chai', '#get')[__491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[12]], ['assert'], __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0]), [
  'throws',
  [
    (...args) =>
      (__hook__(() => {
        __hook__('m()', exportedName, [
          __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[11],
          [],
          (...args) => exportedName(...args)
        ], __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0], null);
      }, null, args, __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0])),
    /^Permission Denied:/
  ]
], __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0]);
// read
__hook__('#()', __hook__('#.', $hook$.global(__hook__, __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0], 'chai', '#get')[__491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[12]], ['assert'], __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0]), [
  'throws',
  [
    (...args) =>
      (__hook__(() => {
        __hook__('m', inaccessibleString, [__491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[13]], __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0], null);
      }, null, args, __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0])),
    /^Permission Denied:/
  ]
], __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0]);
__hook__('#()', __hook__('#.', $hook$.global(__hook__, __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0], 'chai', '#get')[__491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[12]], ['assert'], __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0]), [
  'throws',
  [
    (...args) =>
      (__hook__(() => {
        __hook__('m', inaccessibleNumber, [__491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[14]], __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0], null);
      }, null, args, __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0])),
    /^Permission Denied:/
  ]
], __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0]);
__hook__('#()', __hook__('#.', $hook$.global(__hook__, __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0], 'chai', '#get')[__491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[12]], ['assert'], __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0]), [
  'throws',
  [
    (...args) =>
      (__hook__(() => {
        __hook__('m', inaccessibleBoolean, [__491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[15]], __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0], null);
      }, null, args, __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0])),
    /^Permission Denied:/
  ]
], __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0]);
__hook__('#()', __hook__('#.', $hook$.global(__hook__, __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0], 'chai', '#get')[__491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[12]], ['assert'], __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0]), [
  'throws',
  [
    (...args) =>
      (__hook__(() => {
        __hook__('m', inaccessibleSymbol, [__491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[1]], __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0], null);
      }, null, args, __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0])),
    /^Permission Denied:/
  ]
], __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0]);
__hook__('#()', __hook__('#.', $hook$.global(__hook__, __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0], 'chai', '#get')[__491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[12]], ['assert'], __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0]), [
  'throws',
  [
    (...args) =>
      (__hook__(() => {
        __hook__('m', inaccessibleNull, [__491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[16]], __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0], null);
      }, null, args, __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0])),
    /^Permission Denied:/
  ]
], __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0]);
__hook__('#()', __hook__('#.', $hook$.global(__hook__, __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0], 'chai', '#get')[__491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[12]], ['assert'], __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0]), [
  'throws',
  [
    (...args) =>
      (__hook__(() => {
        __hook__('m', inaccessibleUndefined, [__491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[3]], __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0], null);
      }, null, args, __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0])),
    /^Permission Denied:/
  ]
], __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0]);
__hook__('#()', __hook__('#.', $hook$.global(__hook__, __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0], 'chai', '#get')[__491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[12]], ['assert'], __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0]), [
  'throws',
  [
    (...args) =>
      (__hook__(() => {
        __hook__('m', inaccessibleBigInt, [__491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[5]], __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0], null);
      }, null, args, __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0])),
    /^Permission Denied:/
  ]
], __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0]);
__hook__('#()', __hook__('#.', $hook$.global(__hook__, __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0], 'chai', '#get')[__491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[12]], ['assert'], __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0]), [
  'throws',
  [
    (...args) =>
      (__hook__(() => {
        __hook__('m', inaccessibleFunction, [__491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[17]], __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0], null);
      }, null, args, __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0])),
    /^Permission Denied:/
  ]
], __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0]);
__hook__('#()', __hook__('#.', $hook$.global(__hook__, __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0], 'chai', '#get')[__491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[12]], ['assert'], __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0]), [
  'throws',
  [
    (...args) =>
      (__hook__(() => {
        __hook__('m', inaccessibleObject, [__491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[18]], __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0], null);
      }, null, args, __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0])),
    /^Permission Denied:/
  ]
], __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0]);
// read via unary operator
__hook__('#()', __hook__('#.', $hook$.global(__hook__, __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0], 'chai', '#get')[__491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[12]], ['assert'], __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0]), [
  'throws',
  [
    (...args) =>
      (__hook__(() => {
        __hook__('mtypeof', inaccessibleString, [
          __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[13],
          () => typeof inaccessibleString
        ], __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0], null);
      }, null, args, __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0])),
    /^Permission Denied:/
  ]
], __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0]);
__hook__('#()', __hook__('#.', $hook$.global(__hook__, __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0], 'chai', '#get')[__491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[12]], ['assert'], __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0]), [
  'throws',
  [
    (...args) =>
      (__hook__(() => {
        __hook__('mtypeof', inaccessibleNumber, [
          __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[14],
          () => typeof inaccessibleNumber
        ], __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0], null);
      }, null, args, __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0])),
    /^Permission Denied:/
  ]
], __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0]);
__hook__('#()', __hook__('#.', $hook$.global(__hook__, __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0], 'chai', '#get')[__491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[12]], ['assert'], __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0]), [
  'throws',
  [
    (...args) =>
      (__hook__(() => {
        __hook__('mtypeof', inaccessibleBoolean, [
          __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[15],
          () => typeof inaccessibleBoolean
        ], __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0], null);
      }, null, args, __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0])),
    /^Permission Denied:/
  ]
], __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0]);
__hook__('#()', __hook__('#.', $hook$.global(__hook__, __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0], 'chai', '#get')[__491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[12]], ['assert'], __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0]), [
  'throws',
  [
    (...args) =>
      (__hook__(() => {
        __hook__('mtypeof', inaccessibleSymbol, [
          __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[1],
          () => typeof inaccessibleSymbol
        ], __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0], null);
      }, null, args, __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0])),
    /^Permission Denied:/
  ]
], __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0]);
__hook__('#()', __hook__('#.', $hook$.global(__hook__, __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0], 'chai', '#get')[__491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[12]], ['assert'], __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0]), [
  'throws',
  [
    (...args) =>
      (__hook__(() => {
        __hook__('mtypeof', inaccessibleNull, [
          __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[16],
          () => typeof inaccessibleNull
        ], __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0], null);
      }, null, args, __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0])),
    /^Permission Denied:/
  ]
], __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0]);
__hook__('#()', __hook__('#.', $hook$.global(__hook__, __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0], 'chai', '#get')[__491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[12]], ['assert'], __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0]), [
  'throws',
  [
    (...args) =>
      (__hook__(() => {
        __hook__('mtypeof', inaccessibleUndefined, [
          __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[3],
          () => typeof inaccessibleUndefined
        ], __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0], null);
      }, null, args, __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0])),
    /^Permission Denied:/
  ]
], __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0]);
__hook__('#()', __hook__('#.', $hook$.global(__hook__, __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0], 'chai', '#get')[__491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[12]], ['assert'], __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0]), [
  'throws',
  [
    (...args) =>
      (__hook__(() => {
        __hook__('mtypeof', inaccessibleBigInt, [
          __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[5],
          () => typeof inaccessibleBigInt
        ], __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0], null);
      }, null, args, __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0])),
    /^Permission Denied:/
  ]
], __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0]);
__hook__('#()', __hook__('#.', $hook$.global(__hook__, __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0], 'chai', '#get')[__491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[12]], ['assert'], __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0]), [
  'throws',
  [
    (...args) =>
      (__hook__(() => {
        __hook__('mtypeof', inaccessibleFunction, [
          __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[17],
          () => typeof inaccessibleFunction
        ], __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0], null);
      }, null, args, __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0])),
    /^Permission Denied:/
  ]
], __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0]);
__hook__('#()', __hook__('#.', $hook$.global(__hook__, __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0], 'chai', '#get')[__491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[12]], ['assert'], __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0]), [
  'throws',
  [
    (...args) =>
      (__hook__(() => {
        __hook__('mtypeof', inaccessibleObject, [
          __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[18],
          () => typeof inaccessibleObject
        ], __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0], null);
      }, null, args, __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0])),
    /^Permission Denied:/
  ]
], __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0]);
/*
// update operator (throws before operations)
chai.assert.throws(() => { inaccessibleString++; }, /^Permission Denied:/);
chai.assert.throws(() => { inaccessibleNumber++; }, /^Permission Denied:/);
chai.assert.throws(() => { inaccessibleBoolean++; }, /^Permission Denied:/);
chai.assert.throws(() => { inaccessibleSymbol++; }, /^Permission Denied:/);
chai.assert.throws(() => { inaccessibleNull++; }, /^Permission Denied:/);
chai.assert.throws(() => { inaccessibleUndefined++; }, /^Permission Denied:/);
chai.assert.throws(() => { inaccessibleBigInt++; }, /^Permission Denied:/);
chai.assert.throws(() => { inaccessibleFunction++; }, /^Permission Denied:/);
chai.assert.throws(() => { inaccessibleObject++; }, /^Permission Denied:/);
*/
// call operator (throws before operations)
__hook__('#()', __hook__('#.', $hook$.global(__hook__, __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0], 'chai', '#get')[__491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[12]], ['assert'], __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0]), [
  'throws',
  [
    (...args) =>
      (__hook__(() => {
        __hook__('m()', inaccessibleString, [
          __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[13],
          [],
          (...args) => inaccessibleString(...args)
        ], __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0], null);
      }, null, args, __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0])),
    /^Permission Denied:/
  ]
], __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0]);
__hook__('#()', __hook__('#.', $hook$.global(__hook__, __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0], 'chai', '#get')[__491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[12]], ['assert'], __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0]), [
  'throws',
  [
    (...args) =>
      (__hook__(() => {
        __hook__('m()', inaccessibleNumber, [
          __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[14],
          [],
          (...args) => inaccessibleNumber(...args)
        ], __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0], null);
      }, null, args, __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0])),
    /^Permission Denied:/
  ]
], __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0]);
__hook__('#()', __hook__('#.', $hook$.global(__hook__, __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0], 'chai', '#get')[__491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[12]], ['assert'], __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0]), [
  'throws',
  [
    (...args) =>
      (__hook__(() => {
        __hook__('m()', inaccessibleBoolean, [
          __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[15],
          [],
          (...args) => inaccessibleBoolean(...args)
        ], __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0], null);
      }, null, args, __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0])),
    /^Permission Denied:/
  ]
], __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0]);
__hook__('#()', __hook__('#.', $hook$.global(__hook__, __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0], 'chai', '#get')[__491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[12]], ['assert'], __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0]), [
  'throws',
  [
    (...args) =>
      (__hook__(() => {
        __hook__('m()', inaccessibleSymbol, [
          __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[1],
          [],
          (...args) => inaccessibleSymbol(...args)
        ], __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0], null);
      }, null, args, __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0])),
    /^Permission Denied:/
  ]
], __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0]);
__hook__('#()', __hook__('#.', $hook$.global(__hook__, __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0], 'chai', '#get')[__491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[12]], ['assert'], __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0]), [
  'throws',
  [
    (...args) =>
      (__hook__(() => {
        __hook__('m()', inaccessibleNull, [
          __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[16],
          [],
          (...args) => inaccessibleNull(...args)
        ], __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0], null);
      }, null, args, __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0])),
    /^Permission Denied:/
  ]
], __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0]);
__hook__('#()', __hook__('#.', $hook$.global(__hook__, __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0], 'chai', '#get')[__491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[12]], ['assert'], __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0]), [
  'throws',
  [
    (...args) =>
      (__hook__(() => {
        __hook__('m()', inaccessibleUndefined, [
          __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[3],
          [],
          (...args) => inaccessibleUndefined(...args)
        ], __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0], null);
      }, null, args, __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0])),
    /^Permission Denied:/
  ]
], __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0]);
__hook__('#()', __hook__('#.', $hook$.global(__hook__, __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0], 'chai', '#get')[__491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[12]], ['assert'], __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0]), [
  'throws',
  [
    (...args) =>
      (__hook__(() => {
        __hook__('m()', inaccessibleBigInt, [
          __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[5],
          [],
          (...args) => inaccessibleBigInt(...args)
        ], __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0], null);
      }, null, args, __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0])),
    /^Permission Denied:/
  ]
], __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0]);
__hook__('#()', __hook__('#.', $hook$.global(__hook__, __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0], 'chai', '#get')[__491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[12]], ['assert'], __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0]), [
  'throws',
  [
    (...args) =>
      (__hook__(() => {
        __hook__('m()', inaccessibleFunction, [
          __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[17],
          [],
          (...args) => inaccessibleFunction(...args)
        ], __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0], null);
      }, null, args, __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0])),
    /^Permission Denied:/
  ]
], __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0]);
__hook__('#()', __hook__('#.', $hook$.global(__hook__, __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0], 'chai', '#get')[__491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[12]], ['assert'], __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0]), [
  'throws',
  [
    (...args) =>
      (__hook__(() => {
        __hook__('m()', inaccessibleObject, [
          __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[18],
          [],
          (...args) => inaccessibleObject(...args)
        ], __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0], null);
      }, null, args, __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0])),
    /^Permission Denied:/
  ]
], __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0]);
// new operator (throws before operations)
__hook__('#()', __hook__('#.', $hook$.global(__hook__, __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0], 'chai', '#get')[__491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[12]], ['assert'], __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0]), [
  'throws',
  [
    (...args) =>
      (__hook__(() => {
        __hook__('mnew', inaccessibleString, [
          __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[13],
          [],
          (...args) => new inaccessibleString(...args)
        ], __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0], null);
      }, null, args, __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0])),
    /^Permission Denied:/
  ]
], __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0]);
__hook__('#()', __hook__('#.', $hook$.global(__hook__, __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0], 'chai', '#get')[__491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[12]], ['assert'], __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0]), [
  'throws',
  [
    (...args) =>
      (__hook__(() => {
        __hook__('mnew', inaccessibleNumber, [
          __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[14],
          [],
          (...args) => new inaccessibleNumber(...args)
        ], __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0], null);
      }, null, args, __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0])),
    /^Permission Denied:/
  ]
], __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0]);
__hook__('#()', __hook__('#.', $hook$.global(__hook__, __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0], 'chai', '#get')[__491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[12]], ['assert'], __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0]), [
  'throws',
  [
    (...args) =>
      (__hook__(() => {
        __hook__('mnew', inaccessibleBoolean, [
          __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[15],
          [],
          (...args) => new inaccessibleBoolean(...args)
        ], __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0], null);
      }, null, args, __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0])),
    /^Permission Denied:/
  ]
], __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0]);
__hook__('#()', __hook__('#.', $hook$.global(__hook__, __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0], 'chai', '#get')[__491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[12]], ['assert'], __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0]), [
  'throws',
  [
    (...args) =>
      (__hook__(() => {
        __hook__('mnew', inaccessibleSymbol, [
          __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[1],
          [],
          (...args) => new inaccessibleSymbol(...args)
        ], __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0], null);
      }, null, args, __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0])),
    /^Permission Denied:/
  ]
], __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0]);
__hook__('#()', __hook__('#.', $hook$.global(__hook__, __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0], 'chai', '#get')[__491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[12]], ['assert'], __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0]), [
  'throws',
  [
    (...args) =>
      (__hook__(() => {
        __hook__('mnew', inaccessibleNull, [
          __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[16],
          [],
          (...args) => new inaccessibleNull(...args)
        ], __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0], null);
      }, null, args, __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0])),
    /^Permission Denied:/
  ]
], __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0]);
__hook__('#()', __hook__('#.', $hook$.global(__hook__, __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0], 'chai', '#get')[__491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[12]], ['assert'], __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0]), [
  'throws',
  [
    (...args) =>
      (__hook__(() => {
        __hook__('mnew', inaccessibleUndefined, [
          __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[3],
          [],
          (...args) => new inaccessibleUndefined(...args)
        ], __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0], null);
      }, null, args, __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0])),
    /^Permission Denied:/
  ]
], __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0]);
__hook__('#()', __hook__('#.', $hook$.global(__hook__, __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0], 'chai', '#get')[__491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[12]], ['assert'], __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0]), [
  'throws',
  [
    (...args) =>
      (__hook__(() => {
        __hook__('mnew', inaccessibleBigInt, [
          __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[5],
          [],
          (...args) => new inaccessibleBigInt(...args)
        ], __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0], null);
      }, null, args, __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0])),
    /^Permission Denied:/
  ]
], __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0]);
__hook__('#()', __hook__('#.', $hook$.global(__hook__, __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0], 'chai', '#get')[__491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[12]], ['assert'], __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0]), [
  'throws',
  [
    (...args) =>
      (__hook__(() => {
        __hook__('mnew', inaccessibleFunction, [
          __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[17],
          [],
          (...args) => new inaccessibleFunction(...args)
        ], __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0], null);
      }, null, args, __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0])),
    /^Permission Denied:/
  ]
], __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0]);
__hook__('#()', __hook__('#.', $hook$.global(__hook__, __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0], 'chai', '#get')[__491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[12]], ['assert'], __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0]), [
  'throws',
  [
    (...args) =>
      (__hook__(() => {
        __hook__('mnew', inaccessibleObject, [
          __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[18],
          [],
          (...args) => new inaccessibleObject(...args)
        ], __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0], null);
      }, null, args, __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0])),
    /^Permission Denied:/
  ]
], __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0]);  /*
// assignment operators
chai.assert.throws(() => { inaccessibleString = 'abc'; }, /^Permission Denied:/);
chai.assert.throws(() => { inaccessibleNumber = 1; }, /^Permission Denied:/);
chai.assert.throws(() => { inaccessibleBoolean = true; }, /^Permission Denied:/);
chai.assert.throws(() => { inaccessibleSymbol = Symbol('new value'); }, /^Permission Denied:/);
chai.assert.throws(() => { inaccessibleNull = null; }, /^Permission Denied:/);
chai.assert.throws(() => { inaccessibleUndefined = undefined; }, /^Permission Denied:/);
chai.assert.throws(() => { inaccessibleBigInt = BigInt(1); }, /^Permission Denied:/);
chai.assert.throws(() => { inaccessibleFunction = function () {}; }, /^Permission Denied:/);
chai.assert.throws(() => { inaccessibleObject = {}; }, /^Permission Denied:/);
// LHS values
chai.assert.throws(() => { [ inaccessibleString ] = [ 'abc' ]; }, /^Permission Denied:/);
chai.assert.throws(() => { [ inaccessibleNumber ] = [ 1 ]; }, /^Permission Denied:/);
chai.assert.throws(() => { [ inaccessibleBoolean ] = [ true ]; }, /^Permission Denied:/);
chai.assert.throws(() => { [ inaccessibleSymbol ] = [ Symbol('new value') ]; }, /^Permission Denied:/);
chai.assert.throws(() => { [ inaccessibleNull ] = [ null ]; }, /^Permission Denied:/);
chai.assert.throws(() => { [ inaccessibleUndefined ] = [ undefined ]; }, /^Permission Denied:/);
chai.assert.throws(() => { [ inaccessibleBigInt ] = [ BigInt(1) ]; }, /^Permission Denied:/);
chai.assert.throws(() => { [ inaccessibleFunction ] = [ function () {} ]; }, /^Permission Denied:/);
chai.assert.throws(() => { [ inaccessibleObject ] = [ {} ]; }, /^Permission Denied:/);
*/
__hook__(() => {
}, null, [
  'export',
  __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0],
  __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__module_namespace_4
], __491e31de2616ac0145a809589586fc0160c0b689ee16153a78fbeda89cc694ae__[0], NaN);

const __18162bfcb1bfb2b35a54939b0389bcbd177ab61c4857d39d01603dd868b249c2__ = $hook$.$(__hook__, [
  '/components/thin-hook/demo/modules/module3.js',
  '/components/thin-hook/demo/modules/module3.js,UnspecifiedExport,get property'
]);
class UnspecifiedExport {
  get property() {
    return __hook__(() => {
      return 'property value';
    }, null, arguments, __18162bfcb1bfb2b35a54939b0389bcbd177ab61c4857d39d01603dd868b249c2__[1]);
  }
}
__hook__(() => {
}, null, [
  'export',
  __18162bfcb1bfb2b35a54939b0389bcbd177ab61c4857d39d01603dd868b249c2__[0],
  __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__module_namespace_5
], __18162bfcb1bfb2b35a54939b0389bcbd177ab61c4857d39d01603dd868b249c2__[0], NaN);

const __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__ = $hook$.$(__hook__, [
  '/components/thin-hook/demo/modules/module1.js',
  '/components/thin-hook/demo/node_modules/lit-element/lit-element.js',
  '/components/thin-hook/demo/node_modules/lit-html/directives/repeat.js',
  '/components/thin-hook/demo/node_modules/lit-html/lit-html.js',
  '/components/thin-hook/demo/modules/module2.js',
  '/components/thin-hook/demo/modules/module3.js',
  'S_uNpREdiC4aB1e_console;/components/thin-hook/demo/modules/module1.js',
  'S_uNpREdiC4aB1e_chai;/components/thin-hook/demo/modules/module1.js',
  '/components/thin-hook/demo/modules/module1.js,HelloWorld',
  '/components/thin-hook/demo/node_modules/lit-element/lit-element.js,LitElement',
  '/components/thin-hook/demo/modules/module1.js,HelloWorld,render',
  '/components/thin-hook/demo/node_modules/lit-element/lit-element.js,html',
  'S_uNpREdiC4aB1e_customElements;/components/thin-hook/demo/modules/module1.js',
  '/components/thin-hook/demo/modules/module3.js,UnspecifiedExport',
  '/components/thin-hook/demo/modules/module1.js,unspecifiedExportObject',
  '/components/thin-hook/demo/modules/module2.js,exportedName',
  '/components/thin-hook/demo/modules/module2.js,exportedName2',
  '/components/thin-hook/demo/modules/module1.js,exportedClassObject',
  '/components/thin-hook/demo/modules/module2.js,ExportedClass',
  '/components/thin-hook/demo/modules/module2.js,inaccessibleString',
  '/components/thin-hook/demo/modules/module2.js,inaccessibleNumber',
  '/components/thin-hook/demo/modules/module2.js,inaccessibleBoolean',
  '/components/thin-hook/demo/modules/module2.js,inaccessibleSymbol',
  '/components/thin-hook/demo/modules/module2.js,inaccessibleNull',
  '/components/thin-hook/demo/modules/module2.js,inaccessibleUndefined',
  '/components/thin-hook/demo/modules/module2.js,inaccessibleBigInt',
  '/components/thin-hook/demo/modules/module2.js,inaccessibleFunction',
  '/components/thin-hook/demo/modules/module2.js,inaccessibleObject'
]);
__hook__(() => {
}, null, [
  'import',
  {
    [__cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[1]]: [
      __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__module_namespace_1,
      'LitElement',
      'html'
    ],
    [__cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[2]]: [
      __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__module_namespace_2,
      'repeat'
    ],
    [__cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[3]]: [
      litHtmlNamespace,
      '*'
    ],
    [__cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[4]]: [
      __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__module_namespace_4,
      'exportedName',
      'exportedName2',
      'ExportedClass',
      'inaccessibleString',
      'inaccessibleNumber',
      'inaccessibleBoolean',
      'inaccessibleSymbol',
      'inaccessibleNull',
      'inaccessibleUndefined',
      'inaccessibleBigInt',
      'inaccessibleFunction',
      'inaccessibleObject'
    ],
    [__cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[5]]: [
      __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__module_namespace_5,
      'UnspecifiedExport'
    ]
  }
], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0], NaN);
__hook__('#()', __hook__((Import, ImportSpecifier) => import(ImportSpecifier), null, [
  'import()',
  'lit-html',
  { url: '/components/thin-hook/demo/modules/module1.js' }
], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0], NaN), [
  'then',
  [(...args) =>
      (__hook__(dynamicModule => {
        if (__hook__('#()', __hook__('#.', __hook__(() => import.meta, null, ['import.meta'], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0], NaN), ['url'], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0]), [
            'indexOf',
            ['rollup']
          ], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0]) >= 0) {
          __hook__('#()', $hook$.global(__hook__, __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0], 'console', '#get')[__cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[6]], [
            'warn',
            [
              'dynamically imported "lit-html" module may conflict with that in this bundle ',
              __hook__('#.', __hook__(() => import.meta, null, ['import.meta'], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0], NaN), ['url'], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0])
            ]
          ], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0]);
        } else {
          __hook__('#()', __hook__('#.', $hook$.global(__hook__, __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0], 'chai', '#get')[__cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[7]], ['assert'], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0]), [
            'equal',
            [
              dynamicModule,
              __hook__('m', litHtmlNamespace, [__cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[3]], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0], null),
              'dynamically imported module matches with that from static import'
            ]
          ], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0]);
        }
      }, null, args, __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0]))]
], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0]);
/*
import defaultImportLocalName from "./module2.js";
export { ExportedClass_local1 as ExportedClass_local1_renamedExport1 }; // export comes before import
export { ExportedClass_local1 as ExportedClass_local1_renamedExport2 };
import { ExportedClass as ExportedClass_local1, ExportedClass as ExportedClass_local2 } from "./module2.js";
export { ExportedClass as ExportedClass_renamedExport1 };
export { ExportedClass as ExportedClass_renamedExport2 };
export { ExportedClass_local2 as ExportedClass_local2_renamedExport1 };
export { ExportedClass_local2 as ExportedClass_local2_renamedExport2 };
import "./module4.js"; // no imported variables
import * as module2Namesapce from "./module2.js";
export * from "./module5.js";
export { module2Namesapce };
export { ExportedClass as ReexportedClass };
export default ExportedClass;
//export default class DefaultExport {};
//export { DefaultExport as default };
class LaterExportedClass {}
export { LaterExportedClass as RenamedLaterExportedClass };
export { PreExportedClass as RenamedPreExportedClass };
class PreExportedClass {}
class MultiplyExportedClass {}
export { MultiplyExportedClass as MultiplyExportedClass_renamed1, MultiplyExportedClass as MultiplyExportedClass_renamed2 };
*/
class HelloWorld extends __hook__('m', LitElement, [__cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[9]], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[8], null) {
  render() {
    return __hook__(() => {
      return __hook__(__hook__('m', html, [__cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[11]], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[10], null), null, [((s, r) => {
          s.raw = r;
          return s;
        })(['<div>Hello, World!</div>'], ['<div>Hello, World!</div>'])], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[10], 0);
    }, null, arguments, __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[10]);
  }
}
if (!__hook__('#()', $hook$.global(__hook__, __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0], 'customElements', '#get')[__cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[12]], [
    'get',
    ['hello-world']
  ], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0])) {
  __hook__('#()', $hook$.global(__hook__, __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0], 'customElements', '#get')[__cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[12]], [
    'define',
    [
      'hello-world',
      __hook__('m', HelloWorld, [__cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[8]], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0], null)
    ]
  ], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0]);
} else {
  __hook__('#()', $hook$.global(__hook__, __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0], 'console', '#get')[__cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[6]], [
    'warn',
    [
      'skipping registration of "hello-world" custom element as it has already been defined',
      __hook__('#.', __hook__(() => import.meta, null, ['import.meta'], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0], NaN), ['url'], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0])
    ]
  ], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0]);
}
__hook__('#()', __hook__('#.', $hook$.global(__hook__, __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0], 'chai', '#get')[__cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[7]], ['assert'], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0]), [
  'equal',
  [
    __hook__('mtypeof', UnspecifiedExport, [
      __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[13],
      () => typeof UnspecifiedExport
    ], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0], null),
    'function',
    'typeof UnspecifiedExport'
  ]
], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0]);
// readable
let unspecifiedExportObject = __hook__('mnew', UnspecifiedExport, [
  __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[13],
  [],
  (...args) => new UnspecifiedExport(...args)
], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[14], null);
// callable
__hook__('#()', __hook__('#.', $hook$.global(__hook__, __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0], 'chai', '#get')[__cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[7]], ['assert'], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0]), [
  'equal',
  [
    __hook__('#.', unspecifiedExportObject, ['property'], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0]),
    'property value',
    'UnspecifiedExport.property'
  ]
], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0]);
// readable
__hook__('#()', __hook__('#.', $hook$.global(__hook__, __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0], 'chai', '#get')[__cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[7]], ['assert'], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0]), [
  'throws',
  [
    (...args) =>
      (__hook__(() => {
        __hook__('#=', __hook__('m', UnspecifiedExport, [__cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[13]], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0], null), [
          'nonwritable',
          true
        ], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0]);
      }, null, args, __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0])),
    /^Permission Denied:/
  ]
], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0]);
// not writable via Policy.globalAcl()
__hook__('#()', __hook__('#.', $hook$.global(__hook__, __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0], 'chai', '#get')[__cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[7]], ['assert'], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0]), [
  'equal',
  [
    __hook__('m', exportedName, [__cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[15]], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0], null) + 'concatenated',
    'exportedNameValueconcatenated',
    'exported readable string value'
  ]
], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0]);
// readable
__hook__('#()', __hook__('#.', $hook$.global(__hook__, __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0], 'chai', '#get')[__cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[7]], ['assert'], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0]), [
  'equal',
  [
    __hook__('mtypeof', exportedName, [
      __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[15],
      () => typeof exportedName
    ], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0], null),
    'string',
    'typeof exported string value'
  ]
], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0]);
// readable
//chai.assert.throws(() => { exportedName = 'new value'; }, /^Permission Denied:/); // not writable
__hook__('#()', __hook__('#.', $hook$.global(__hook__, __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0], 'chai', '#get')[__cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[7]], ['assert'], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0]), [
  'throws',
  [
    (...args) =>
      (__hook__(() => {
        __hook__('m()', exportedName, [
          __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[15],
          [],
          (...args) => exportedName(...args)
        ], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0], null);
      }, null, args, __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0])),
    /^Permission Denied:/
  ]
], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0]);
// not callable
__hook__('#()', __hook__('#.', $hook$.global(__hook__, __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0], 'chai', '#get')[__cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[7]], ['assert'], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0]), [
  'throws',
  [
    (...args) =>
      (__hook__(() => {
        __hook__('m', exportedName2, [__cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[16]], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0], null);
      }, null, args, __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0])),
    /^Permission Denied:/
  ]
], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0]);
// not readable
// call
let exportedClassObject = __hook__('mnew', ExportedClass, [
  __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[18],
  [],
  (...args) => new ExportedClass(...args)
], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[17], null);
__hook__('#()', __hook__('#.', $hook$.global(__hook__, __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0], 'chai', '#get')[__cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[7]], ['assert'], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0]), [
  'equal',
  [
    __hook__('#.', exportedClassObject, ['readableProperty'], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0]),
    'readable',
    'readable object property'
  ]
], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0]);
__hook__('#()', __hook__('#.', $hook$.global(__hook__, __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0], 'chai', '#get')[__cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[7]], ['assert'], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0]), [
  'throws',
  [
    (...args) =>
      (__hook__(() => {
        __hook__('#()', exportedClassObject, [
          'readableProperty',
          []
        ], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0]);
      }, null, args, __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0])),
    /^Permission Denied:/
  ]
], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0]);
// not callable
__hook__('#()', __hook__('#.', $hook$.global(__hook__, __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0], 'chai', '#get')[__cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[7]], ['assert'], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0]), [
  'throws',
  [
    (...args) =>
      (__hook__(() => {
        __hook__('#.', exportedClassObject, ['unreadableProperty'], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0]);
      }, null, args, __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0])),
    /^Permission Denied:/
  ]
], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0]);
__hook__('#()', __hook__('#.', $hook$.global(__hook__, __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0], 'chai', '#get')[__cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[7]], ['assert'], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0]), [
  'equal',
  [
    __hook__('#()', __hook__('m', ExportedClass, [__cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[18]], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0], null), [
      'callableStaticMethod',
      []
    ], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0]),
    'called',
    'callable static method'
  ]
], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0]);
__hook__('#()', __hook__('#.', $hook$.global(__hook__, __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0], 'chai', '#get')[__cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[7]], ['assert'], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0]), [
  'throws',
  [
    (...args) =>
      (__hook__(() => {
        __hook__('#.', __hook__('m', ExportedClass, [__cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[18]], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0], null), ['callableStaticMethod'], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0]);
      }, null, args, __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0])),
    /^Permission Denied:/
  ]
], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0]);
__hook__('#()', __hook__('#.', $hook$.global(__hook__, __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0], 'chai', '#get')[__cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[7]], ['assert'], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0]), [
  'equal',
  [
    __hook__('#()', exportedClassObject, [
      'callableMethod',
      ['abc']
    ], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0]),
    'string',
    'callable method'
  ]
], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0]);
__hook__('#()', __hook__('#.', $hook$.global(__hook__, __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0], 'chai', '#get')[__cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[7]], ['assert'], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0]), [
  'throws',
  [
    (...args) =>
      (__hook__(() => {
        __hook__('#.', exportedClassObject, ['callableMethod'], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0]);
      }, null, args, __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0])),
    /^Permission Denied:/
  ]
], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0]);
// read
__hook__('#()', __hook__('#.', $hook$.global(__hook__, __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0], 'chai', '#get')[__cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[7]], ['assert'], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0]), [
  'throws',
  [
    (...args) =>
      (__hook__(() => {
        __hook__('m', inaccessibleString, [__cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[19]], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0], null);
      }, null, args, __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0])),
    /^Permission Denied:/
  ]
], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0]);
__hook__('#()', __hook__('#.', $hook$.global(__hook__, __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0], 'chai', '#get')[__cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[7]], ['assert'], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0]), [
  'throws',
  [
    (...args) =>
      (__hook__(() => {
        __hook__('m', inaccessibleNumber, [__cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[20]], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0], null);
      }, null, args, __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0])),
    /^Permission Denied:/
  ]
], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0]);
__hook__('#()', __hook__('#.', $hook$.global(__hook__, __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0], 'chai', '#get')[__cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[7]], ['assert'], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0]), [
  'throws',
  [
    (...args) =>
      (__hook__(() => {
        __hook__('m', inaccessibleBoolean, [__cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[21]], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0], null);
      }, null, args, __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0])),
    /^Permission Denied:/
  ]
], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0]);
__hook__('#()', __hook__('#.', $hook$.global(__hook__, __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0], 'chai', '#get')[__cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[7]], ['assert'], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0]), [
  'throws',
  [
    (...args) =>
      (__hook__(() => {
        __hook__('m', inaccessibleSymbol, [__cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[22]], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0], null);
      }, null, args, __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0])),
    /^Permission Denied:/
  ]
], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0]);
__hook__('#()', __hook__('#.', $hook$.global(__hook__, __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0], 'chai', '#get')[__cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[7]], ['assert'], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0]), [
  'throws',
  [
    (...args) =>
      (__hook__(() => {
        __hook__('m', inaccessibleNull, [__cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[23]], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0], null);
      }, null, args, __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0])),
    /^Permission Denied:/
  ]
], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0]);
__hook__('#()', __hook__('#.', $hook$.global(__hook__, __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0], 'chai', '#get')[__cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[7]], ['assert'], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0]), [
  'throws',
  [
    (...args) =>
      (__hook__(() => {
        __hook__('m', inaccessibleUndefined, [__cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[24]], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0], null);
      }, null, args, __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0])),
    /^Permission Denied:/
  ]
], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0]);
__hook__('#()', __hook__('#.', $hook$.global(__hook__, __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0], 'chai', '#get')[__cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[7]], ['assert'], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0]), [
  'throws',
  [
    (...args) =>
      (__hook__(() => {
        __hook__('m', inaccessibleBigInt, [__cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[25]], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0], null);
      }, null, args, __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0])),
    /^Permission Denied:/
  ]
], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0]);
__hook__('#()', __hook__('#.', $hook$.global(__hook__, __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0], 'chai', '#get')[__cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[7]], ['assert'], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0]), [
  'throws',
  [
    (...args) =>
      (__hook__(() => {
        __hook__('m', inaccessibleFunction, [__cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[26]], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0], null);
      }, null, args, __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0])),
    /^Permission Denied:/
  ]
], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0]);
__hook__('#()', __hook__('#.', $hook$.global(__hook__, __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0], 'chai', '#get')[__cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[7]], ['assert'], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0]), [
  'throws',
  [
    (...args) =>
      (__hook__(() => {
        __hook__('m', inaccessibleObject, [__cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[27]], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0], null);
      }, null, args, __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0])),
    /^Permission Denied:/
  ]
], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0]);
// read via unary operator
__hook__('#()', __hook__('#.', $hook$.global(__hook__, __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0], 'chai', '#get')[__cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[7]], ['assert'], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0]), [
  'throws',
  [
    (...args) =>
      (__hook__(() => {
        __hook__('mtypeof', inaccessibleString, [
          __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[19],
          () => typeof inaccessibleString
        ], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0], null);
      }, null, args, __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0])),
    /^Permission Denied:/
  ]
], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0]);
__hook__('#()', __hook__('#.', $hook$.global(__hook__, __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0], 'chai', '#get')[__cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[7]], ['assert'], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0]), [
  'throws',
  [
    (...args) =>
      (__hook__(() => {
        __hook__('mtypeof', inaccessibleNumber, [
          __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[20],
          () => typeof inaccessibleNumber
        ], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0], null);
      }, null, args, __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0])),
    /^Permission Denied:/
  ]
], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0]);
__hook__('#()', __hook__('#.', $hook$.global(__hook__, __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0], 'chai', '#get')[__cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[7]], ['assert'], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0]), [
  'throws',
  [
    (...args) =>
      (__hook__(() => {
        __hook__('mtypeof', inaccessibleBoolean, [
          __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[21],
          () => typeof inaccessibleBoolean
        ], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0], null);
      }, null, args, __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0])),
    /^Permission Denied:/
  ]
], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0]);
__hook__('#()', __hook__('#.', $hook$.global(__hook__, __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0], 'chai', '#get')[__cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[7]], ['assert'], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0]), [
  'throws',
  [
    (...args) =>
      (__hook__(() => {
        __hook__('mtypeof', inaccessibleSymbol, [
          __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[22],
          () => typeof inaccessibleSymbol
        ], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0], null);
      }, null, args, __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0])),
    /^Permission Denied:/
  ]
], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0]);
__hook__('#()', __hook__('#.', $hook$.global(__hook__, __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0], 'chai', '#get')[__cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[7]], ['assert'], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0]), [
  'throws',
  [
    (...args) =>
      (__hook__(() => {
        __hook__('mtypeof', inaccessibleNull, [
          __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[23],
          () => typeof inaccessibleNull
        ], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0], null);
      }, null, args, __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0])),
    /^Permission Denied:/
  ]
], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0]);
__hook__('#()', __hook__('#.', $hook$.global(__hook__, __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0], 'chai', '#get')[__cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[7]], ['assert'], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0]), [
  'throws',
  [
    (...args) =>
      (__hook__(() => {
        __hook__('mtypeof', inaccessibleUndefined, [
          __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[24],
          () => typeof inaccessibleUndefined
        ], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0], null);
      }, null, args, __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0])),
    /^Permission Denied:/
  ]
], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0]);
__hook__('#()', __hook__('#.', $hook$.global(__hook__, __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0], 'chai', '#get')[__cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[7]], ['assert'], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0]), [
  'throws',
  [
    (...args) =>
      (__hook__(() => {
        __hook__('mtypeof', inaccessibleBigInt, [
          __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[25],
          () => typeof inaccessibleBigInt
        ], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0], null);
      }, null, args, __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0])),
    /^Permission Denied:/
  ]
], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0]);
__hook__('#()', __hook__('#.', $hook$.global(__hook__, __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0], 'chai', '#get')[__cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[7]], ['assert'], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0]), [
  'throws',
  [
    (...args) =>
      (__hook__(() => {
        __hook__('mtypeof', inaccessibleFunction, [
          __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[26],
          () => typeof inaccessibleFunction
        ], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0], null);
      }, null, args, __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0])),
    /^Permission Denied:/
  ]
], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0]);
__hook__('#()', __hook__('#.', $hook$.global(__hook__, __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0], 'chai', '#get')[__cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[7]], ['assert'], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0]), [
  'throws',
  [
    (...args) =>
      (__hook__(() => {
        __hook__('mtypeof', inaccessibleObject, [
          __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[27],
          () => typeof inaccessibleObject
        ], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0], null);
      }, null, args, __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0])),
    /^Permission Denied:/
  ]
], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0]);
/*
// update operator (throws before operations)
chai.assert.throws(() => { inaccessibleString++; }, /^Permission Denied:/);
chai.assert.throws(() => { inaccessibleNumber++; }, /^Permission Denied:/);
chai.assert.throws(() => { inaccessibleBoolean++; }, /^Permission Denied:/);
chai.assert.throws(() => { inaccessibleSymbol++; }, /^Permission Denied:/);
chai.assert.throws(() => { inaccessibleNull++; }, /^Permission Denied:/);
chai.assert.throws(() => { inaccessibleUndefined++; }, /^Permission Denied:/);
chai.assert.throws(() => { inaccessibleBigInt++; }, /^Permission Denied:/);
chai.assert.throws(() => { inaccessibleFunction++; }, /^Permission Denied:/);
chai.assert.throws(() => { inaccessibleObject++; }, /^Permission Denied:/);
*/
// call operator (throws before operations)
__hook__('#()', __hook__('#.', $hook$.global(__hook__, __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0], 'chai', '#get')[__cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[7]], ['assert'], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0]), [
  'throws',
  [
    (...args) =>
      (__hook__(() => {
        __hook__('m()', inaccessibleString, [
          __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[19],
          [],
          (...args) => inaccessibleString(...args)
        ], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0], null);
      }, null, args, __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0])),
    /^Permission Denied:/
  ]
], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0]);
__hook__('#()', __hook__('#.', $hook$.global(__hook__, __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0], 'chai', '#get')[__cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[7]], ['assert'], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0]), [
  'throws',
  [
    (...args) =>
      (__hook__(() => {
        __hook__('m()', inaccessibleNumber, [
          __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[20],
          [],
          (...args) => inaccessibleNumber(...args)
        ], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0], null);
      }, null, args, __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0])),
    /^Permission Denied:/
  ]
], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0]);
__hook__('#()', __hook__('#.', $hook$.global(__hook__, __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0], 'chai', '#get')[__cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[7]], ['assert'], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0]), [
  'throws',
  [
    (...args) =>
      (__hook__(() => {
        __hook__('m()', inaccessibleBoolean, [
          __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[21],
          [],
          (...args) => inaccessibleBoolean(...args)
        ], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0], null);
      }, null, args, __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0])),
    /^Permission Denied:/
  ]
], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0]);
__hook__('#()', __hook__('#.', $hook$.global(__hook__, __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0], 'chai', '#get')[__cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[7]], ['assert'], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0]), [
  'throws',
  [
    (...args) =>
      (__hook__(() => {
        __hook__('m()', inaccessibleSymbol, [
          __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[22],
          [],
          (...args) => inaccessibleSymbol(...args)
        ], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0], null);
      }, null, args, __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0])),
    /^Permission Denied:/
  ]
], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0]);
__hook__('#()', __hook__('#.', $hook$.global(__hook__, __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0], 'chai', '#get')[__cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[7]], ['assert'], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0]), [
  'throws',
  [
    (...args) =>
      (__hook__(() => {
        __hook__('m()', inaccessibleNull, [
          __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[23],
          [],
          (...args) => inaccessibleNull(...args)
        ], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0], null);
      }, null, args, __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0])),
    /^Permission Denied:/
  ]
], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0]);
__hook__('#()', __hook__('#.', $hook$.global(__hook__, __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0], 'chai', '#get')[__cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[7]], ['assert'], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0]), [
  'throws',
  [
    (...args) =>
      (__hook__(() => {
        __hook__('m()', inaccessibleUndefined, [
          __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[24],
          [],
          (...args) => inaccessibleUndefined(...args)
        ], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0], null);
      }, null, args, __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0])),
    /^Permission Denied:/
  ]
], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0]);
__hook__('#()', __hook__('#.', $hook$.global(__hook__, __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0], 'chai', '#get')[__cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[7]], ['assert'], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0]), [
  'throws',
  [
    (...args) =>
      (__hook__(() => {
        __hook__('m()', inaccessibleBigInt, [
          __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[25],
          [],
          (...args) => inaccessibleBigInt(...args)
        ], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0], null);
      }, null, args, __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0])),
    /^Permission Denied:/
  ]
], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0]);
__hook__('#()', __hook__('#.', $hook$.global(__hook__, __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0], 'chai', '#get')[__cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[7]], ['assert'], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0]), [
  'throws',
  [
    (...args) =>
      (__hook__(() => {
        __hook__('m()', inaccessibleFunction, [
          __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[26],
          [],
          (...args) => inaccessibleFunction(...args)
        ], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0], null);
      }, null, args, __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0])),
    /^Permission Denied:/
  ]
], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0]);
__hook__('#()', __hook__('#.', $hook$.global(__hook__, __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0], 'chai', '#get')[__cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[7]], ['assert'], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0]), [
  'throws',
  [
    (...args) =>
      (__hook__(() => {
        __hook__('m()', inaccessibleObject, [
          __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[27],
          [],
          (...args) => inaccessibleObject(...args)
        ], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0], null);
      }, null, args, __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0])),
    /^Permission Denied:/
  ]
], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0]);
// new operator (throws before operations)
__hook__('#()', __hook__('#.', $hook$.global(__hook__, __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0], 'chai', '#get')[__cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[7]], ['assert'], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0]), [
  'throws',
  [
    (...args) =>
      (__hook__(() => {
        __hook__('mnew', inaccessibleString, [
          __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[19],
          [],
          (...args) => new inaccessibleString(...args)
        ], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0], null);
      }, null, args, __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0])),
    /^Permission Denied:/
  ]
], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0]);
__hook__('#()', __hook__('#.', $hook$.global(__hook__, __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0], 'chai', '#get')[__cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[7]], ['assert'], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0]), [
  'throws',
  [
    (...args) =>
      (__hook__(() => {
        __hook__('mnew', inaccessibleNumber, [
          __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[20],
          [],
          (...args) => new inaccessibleNumber(...args)
        ], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0], null);
      }, null, args, __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0])),
    /^Permission Denied:/
  ]
], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0]);
__hook__('#()', __hook__('#.', $hook$.global(__hook__, __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0], 'chai', '#get')[__cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[7]], ['assert'], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0]), [
  'throws',
  [
    (...args) =>
      (__hook__(() => {
        __hook__('mnew', inaccessibleBoolean, [
          __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[21],
          [],
          (...args) => new inaccessibleBoolean(...args)
        ], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0], null);
      }, null, args, __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0])),
    /^Permission Denied:/
  ]
], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0]);
__hook__('#()', __hook__('#.', $hook$.global(__hook__, __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0], 'chai', '#get')[__cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[7]], ['assert'], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0]), [
  'throws',
  [
    (...args) =>
      (__hook__(() => {
        __hook__('mnew', inaccessibleSymbol, [
          __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[22],
          [],
          (...args) => new inaccessibleSymbol(...args)
        ], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0], null);
      }, null, args, __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0])),
    /^Permission Denied:/
  ]
], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0]);
__hook__('#()', __hook__('#.', $hook$.global(__hook__, __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0], 'chai', '#get')[__cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[7]], ['assert'], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0]), [
  'throws',
  [
    (...args) =>
      (__hook__(() => {
        __hook__('mnew', inaccessibleNull, [
          __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[23],
          [],
          (...args) => new inaccessibleNull(...args)
        ], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0], null);
      }, null, args, __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0])),
    /^Permission Denied:/
  ]
], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0]);
__hook__('#()', __hook__('#.', $hook$.global(__hook__, __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0], 'chai', '#get')[__cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[7]], ['assert'], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0]), [
  'throws',
  [
    (...args) =>
      (__hook__(() => {
        __hook__('mnew', inaccessibleUndefined, [
          __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[24],
          [],
          (...args) => new inaccessibleUndefined(...args)
        ], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0], null);
      }, null, args, __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0])),
    /^Permission Denied:/
  ]
], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0]);
__hook__('#()', __hook__('#.', $hook$.global(__hook__, __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0], 'chai', '#get')[__cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[7]], ['assert'], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0]), [
  'throws',
  [
    (...args) =>
      (__hook__(() => {
        __hook__('mnew', inaccessibleBigInt, [
          __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[25],
          [],
          (...args) => new inaccessibleBigInt(...args)
        ], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0], null);
      }, null, args, __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0])),
    /^Permission Denied:/
  ]
], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0]);
__hook__('#()', __hook__('#.', $hook$.global(__hook__, __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0], 'chai', '#get')[__cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[7]], ['assert'], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0]), [
  'throws',
  [
    (...args) =>
      (__hook__(() => {
        __hook__('mnew', inaccessibleFunction, [
          __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[26],
          [],
          (...args) => new inaccessibleFunction(...args)
        ], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0], null);
      }, null, args, __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0])),
    /^Permission Denied:/
  ]
], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0]);
__hook__('#()', __hook__('#.', $hook$.global(__hook__, __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0], 'chai', '#get')[__cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[7]], ['assert'], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0]), [
  'throws',
  [
    (...args) =>
      (__hook__(() => {
        __hook__('mnew', inaccessibleObject, [
          __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[27],
          [],
          (...args) => new inaccessibleObject(...args)
        ], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0], null);
      }, null, args, __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0])),
    /^Permission Denied:/
  ]
], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0]);  /*
// assignment operators
chai.assert.throws(() => { inaccessibleString = 'abc'; }, /^Permission Denied:/);
chai.assert.throws(() => { inaccessibleNumber = 1; }, /^Permission Denied:/);
chai.assert.throws(() => { inaccessibleBoolean = true; }, /^Permission Denied:/);
chai.assert.throws(() => { inaccessibleSymbol = Symbol('new value'); }, /^Permission Denied:/);
chai.assert.throws(() => { inaccessibleNull = null; }, /^Permission Denied:/);
chai.assert.throws(() => { inaccessibleUndefined = undefined; }, /^Permission Denied:/);
chai.assert.throws(() => { inaccessibleBigInt = BigInt(1); }, /^Permission Denied:/);
chai.assert.throws(() => { inaccessibleFunction = function () {}; }, /^Permission Denied:/);
chai.assert.throws(() => { inaccessibleObject = {}; }, /^Permission Denied:/);
// LHS values
chai.assert.throws(() => { [ inaccessibleString ] = [ 'abc' ]; }, /^Permission Denied:/);
chai.assert.throws(() => { [ inaccessibleNumber ] = [ 1 ]; }, /^Permission Denied:/);
chai.assert.throws(() => { [ inaccessibleBoolean ] = [ true ]; }, /^Permission Denied:/);
chai.assert.throws(() => { [ inaccessibleSymbol ] = [ Symbol('new value') ]; }, /^Permission Denied:/);
chai.assert.throws(() => { [ inaccessibleNull ] = [ null ]; }, /^Permission Denied:/);
chai.assert.throws(() => { [ inaccessibleUndefined ] = [ undefined ]; }, /^Permission Denied:/);
chai.assert.throws(() => { [ inaccessibleBigInt ] = [ BigInt(1) ]; }, /^Permission Denied:/);
chai.assert.throws(() => { [ inaccessibleFunction ] = [ function () {} ]; }, /^Permission Denied:/);
chai.assert.throws(() => { [ inaccessibleObject ] = [ {} ]; }, /^Permission Denied:/);
*/
__hook__(() => {
}, null, [
  'export',
  __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0],
  __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__module_namespace_0
], __cfcfda9327d73ae8cd35ace82f8631af3d385194a6912cc32c7db6005f5d05d3__[0], NaN);

export { HelloWorld };
